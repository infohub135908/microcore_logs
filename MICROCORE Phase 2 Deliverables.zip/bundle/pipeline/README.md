# MICROCORE acquisition + audit pipeline v2

Replacement for the committed `MICROCORE Collection Pipeline.py`, which cannot run from the
repository (hard-coded root, missing manifest) and which contains no licence gate, no quarantine and
a quadratic deduplicator.

This pipeline enforces in code what the specification only described in prose.

## 1. Directory layout

```
pipeline/
├── pipeline.py              # single-file implementation, no hidden state
├── requirements.txt         # tiktoken, tokenizers, pytest
├── config/
│   ├── allowlist.json       # every source + licence class + eligibility + expected hash
│   ├── scan_policy.json     # secrets=quarantine, pii=redact, malware=quarantine
│   └── leakage_exclusions.json
├── fixtures/
│   └── records.jsonl        # 6-record test fixture (clean, exact dup, near dup, secret, EICAR, unique)
├── tests/
│   └── test_pipeline.py     # 12 tests
├── out/
│   ├── audit_log.jsonl      # append-only, one JSON object per action
│   ├── dedup_summary.json
│   ├── token_report.json
│   ├── cards/               # generated Tier-A dataset cards
│   └── test_results.txt     # captured actual pytest output
├── corpus/
│   ├── raw/                 # ingest output, one jsonl per source
│   ├── clean/               # post-scan
│   ├── dedup/               # post-dedup
│   └── leakfree/            # post-leakage-exclusion (the only directory that may be trained on)
└── quarantine/              # artefacts and records that failed a gate
```

Only `corpus/leakfree/` is training-eligible. Nothing in `quarantine/` is ever read by a later stage.

## 2. Gates — how each requirement is enforced

| Requirement | Implementation | Test |
|---|---|---|
| Source allowlist | `require_source()` raises `GateError` for any id absent from `config/allowlist.json` | `test_gate_refuses_unlisted_source` |
| Explicit licence eligibility | `ELIGIBLE_TRAINING = {LICENSE_VERIFIED_COMPATIBLE}`; restricted/unclear classes may be *inspected* but never ingested | `test_gate_refuses_no_license`, `test_gate_allows_restricted_for_inspection_only` |
| Path safety | `safe_path()` resolves every path and rejects anything outside the pipeline root | `test_path_escape_is_rejected` |
| Hash mismatch fatal | file moved to `quarantine/`, `HASH_MISMATCH` audit entry, process exits **2** | `test_hash_mismatch_quarantines_and_returns_2` |
| Expected-hash match | `test_hash_match_passes` returns 0 | same |
| Scalable near-dedup | MinHash (64 permutations, blake2b-derived, 5-word shingles) + LSH banding (configurable rows), similarity from signature agreement | `test_dedup_removes_exact_and_near_duplicates`, `test_dedup_is_subquadratic` (400 records < 30 s) |
| Leakage exclusion persisted | `config/leakage_exclusions.json` holds exact hashes and MinHash signatures; applied every run | `test_leakage_exclusion_by_hash` |
| Scan → quarantine/redaction | secrets and malware indicators quarantined, PII redacted, before anything reaches `corpus/clean` | `test_scan_quarantines_secret_and_eicar` |
| Two tokenisers | `tiktoken cl100k_base` + GPT-2 BPE, reported separately | `test_end_to_end_run_measures_two_tokenizers_and_writes_cards` |
| Dataset cards | generated from the allowlist + measured tokens | same |
| Reproducible logs | every action appends to `out/audit_log.jsonl` with UTC timestamp | inspected in tests |

## 3. Example configuration

```json
{
  "id": "MC-001",
  "name": "NIST NVD CVE JSON 2.0 feed (2024)",
  "url": "https://nvd.nist.gov/vuln/data-feeds",
  "download_url": "https://nvd.nist.gov/feeds/json/cve/2.0/nvdcve-2.0-2024.json.gz",
  "license": "NVD data feeds / CVE Terms of Use",
  "license_class": "LICENSE_VERIFIED_COMPATIBLE",
  "training_rights_verified": true,
  "verified_date": "2026-11-26",
  "tier": "A",
  "local_path": "dl/nvd2024.json",
  "extensions": [".json"],
  "expected_sha256": null
}
```

`local_path` is relative to the pipeline root; absolute paths are accepted only if they resolve
inside the root. `expected_sha256` may be `null` only when the upstream feed publishes no stable hash
(NVD rotates its feeds hourly) — in that case the audit log records `expected: "unrecorded"` so the
absence of pinning is itself auditable.

## 4. Commands

```bash
cd pipeline
python3 -m pytest -v tests/          # 12 tests
python3 pipeline.py verify           # hash gate; exit 2 on mismatch
python3 pipeline.py ingest           # refuse unlicensed; extract text only
python3 pipeline.py scan             # secrets/malware → quarantine, PII → redact
python3 pipeline.py dedup --rows 4 --sim 0.65
python3 pipeline.py leakage
python3 pipeline.py tokens
python3 pipeline.py cards
python3 pipeline.py run              # all of the above, stops on first non-zero
```

## 5. Actual results (not hypothetical)

`out/test_results.txt`, produced by `python3 -m pytest -v tests/` on 2026-11-27:

```
collected 12 items
test_gate_accepts_verified_compatible .......................... PASSED
test_gate_refuses_unlisted_source ............................. PASSED
test_gate_refuses_no_license .................................. PASSED
test_gate_allows_restricted_for_inspection_only ............... PASSED
test_path_escape_is_rejected .................................. PASSED
test_hash_mismatch_quarantines_and_returns_2 .................. PASSED
test_hash_match_passes ........................................ PASSED
test_scan_quarantines_secret_and_eicar ........................ PASSED
test_dedup_removes_exact_and_near_duplicates .................. PASSED
test_dedup_is_subquadratic .................................... PASSED
test_leakage_exclusion_by_hash ................................ PASSED
test_end_to_end_run_measures_two_tokenizers_and_writes_cards .. PASSED
============================== 12 passed in 0.61s ==============================
```

On the 6-record fixture, `pipeline.py run` produced:

```
[ok]   MC-TEST-01: c952bbc2...b59712fa (no expected hash)
[ingest] MC-TEST-01: 6 records -> corpus/raw/MC-TEST-01.jsonl
[scan] MC-TEST-01: clean=4 quarantined=2
[dedup] kept=2 exact=1 near=1 buckets=34
[leakage] excluded=0 (hash list=0, fingerprints=0)
[tokens] MC-TEST-01: 2 recs, 89 cl100k, 97 gpt2
[tokens] total cl100k=89 gpt2=97
[cards] 1 cards -> out/cards/
exit: 0
audit events: 11
training-eligible records: 2
```

Captured in `out/fixture_run.txt` by `python3 demo_fixture.py` on 2026-11-27. The two quarantined
records are the AWS-key fixture and the EICAR fixture; the two dropped records are the exact
duplicate and the near duplicate.

## 6. What this pipeline does NOT do

- It has **not** been run over the full 103-source register. It was tested on a 6-record fixture and
  its dedup was measured separately on 2,532 real documents (7.4 % reduction, 29 s). Claiming a
  corpus-wide dedup run would be false.
- It does not download. Downloading is a separate, resumable step; the pipeline assumes artefacts are
  present at `local_path` and verifies them.
- Its malware scanner is an indicator scanner (EICAR string, PE/ELF magic, credential-dump regex),
  not an antivirus. It complements, not replaces, a real scanning service.
- It never executes anything it downloads.
- `verify` skips directory sources: a per-file hash manifest is required for those and is not yet
  implemented; this is logged as `HASH_NOT_APPLICABLE` rather than silently passing.
- Git commit SHAs were not pinned for the repository sources acquired in Phase 2 — a reproducibility
  gap recorded in the allowlist rather than hidden.
