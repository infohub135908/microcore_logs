"""Reproducible demo: run the full pipeline on the 6-record fixture in a temp root."""
import json, sys, tempfile, shutil
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import pipeline as P

root = Path(tempfile.mkdtemp(prefix="microcore-fixture-"))
(root/"config").mkdir(); (root/"data").mkdir()
shutil.copy(Path(__file__).parent/"fixtures"/"records.jsonl", root/"data"/"sample.jsonl")
allow = {"schema":"demo","sources":[{
  "id":"MC-TEST-01","name":"Fixture source","publisher":"MICROCORE","url":"file://fixture",
  "download_url":"file://fixture","license":"test","license_class":"LICENSE_VERIFIED_COMPATIBLE",
  "license_url":"n/a","obligations":"none","training_rights_verified":True,"verified_date":"2026-11-27",
  "tier":"A","local_path":"data/sample.jsonl","extensions":[".jsonl"],"expected_sha256":None}]}
(root/"config"/"allowlist.json").write_text(json.dumps(allow))
(root/"config"/"scan_policy.json").write_text(json.dumps({"secrets":"quarantine","pii":"redact","malware_indicators":"quarantine","never_execute":True}))
(root/"config"/"leakage_exclusions.json").write_text(json.dumps({"sha256":[],"minhash":[],"source_ids":[]}))
for n,v in [("ROOT",root),("OUT",root/"out"),("WORK",root/"work"),("QUAR",root/"quarantine"),("CORPUS",root/"corpus")]:
    setattr(P,n,v)
P.CONFIG = root/"config"
rc = P.main(["run"])
print("exit:",rc)
print("audit events:", sum(1 for _ in open(root/"out"/"audit_log.jsonl")))
print("training-eligible records:", sum(1 for _ in open(root/"corpus"/"leakfree"/"MC-TEST-01.jsonl")))
shutil.rmtree(root)
