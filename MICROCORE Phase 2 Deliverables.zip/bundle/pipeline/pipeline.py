#!/usr/bin/env python3
"""
MICROCORE Phase 2 acquisition + audit pipeline (v2).

Design goals (all enforced in code, not in prose):
  * every source must be present in config/allowlist.json AND carry a licence
    class that is eligible for the requested stage, otherwise the pipeline
    refuses to touch it;
  * every path is resolved relative to the pipeline root, traversal outside the
    root is rejected;
  * an expected-hash mismatch is fatal: the artefact is moved to quarantine, an
    audit entry is written and the process exits with status 2;
  * near-duplicate detection uses MinHash + LSH banding (sub-quadratic), never
    an all-pairs comparison;
  * leakage exclusions are persisted (config/leakage_exclusions.json) and
    applied on every run;
  * scanning happens before anything reaches corpus/final; matches are
    quarantined or redacted, files are never executed;
  * token counts are produced with two independent tokenizers.

Nothing here downloads malware or executes any downloaded artefact.
"""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config"
OUT = ROOT / "out"
WORK = ROOT / "work"
QUAR = ROOT / "quarantine"
CORPUS = ROOT / "corpus"
TEXT_EXT = {
    ".md", ".markdown", ".txt", ".rst", ".adoc", ".yaml", ".yml", ".json", ".jsonl",
    ".c", ".h", ".py", ".java", ".go", ".rs", ".sh", ".ps1", ".psm1", ".tf", ".xml",
    ".csv", ".sql", ".js", ".ts", ".php", ".rb", ".cc", ".cpp", ".hpp", ".asm", ".s",
}
ELIGIBLE_TRAINING = {"LICENSE_VERIFIED_COMPATIBLE"}
ELIGIBLE_INSPECTION = {"LICENSE_VERIFIED_COMPATIBLE", "LICENSE_VERIFIED_RESTRICTED",
                       "LICENSE_COMPATIBLE_PENDING_REVIEW", "LICENSE_UNCLEAR"}


class GateError(RuntimeError):
    pass


def audit(event: str, **kw) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "event": event}
    rec.update(kw)
    with open(OUT / "audit_log.jsonl", "a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, sort_keys=True) + "\n")


def safe_path(p: str) -> Path:
    """Resolve a path and refuse anything that escapes the pipeline root."""
    q = (ROOT / p).resolve() if not os.path.isabs(p) else Path(p).resolve()
    try:
        q.relative_to(ROOT)
    except ValueError:
        raise GateError(f"path escapes pipeline root: {p}")
    return q


def load_allowlist() -> dict:
    with open(CONFIG / "allowlist.json", encoding="utf-8") as fh:
        data = json.load(fh)
    return {s["id"]: s for s in data["sources"]}


def require_source(sid: str, allow: dict, stage: str) -> dict:
    if sid not in allow:
        audit("GATE_REFUSED", source=sid, reason="not in allowlist", stage=stage)
        raise GateError(f"{sid}: not in allowlist -> refusing to fetch/process")
    src = allow[sid]
    cls = src.get("license_class", "NO_LICENSE_FOUND")
    ok = ELIGIBLE_TRAINING if stage in {"ingest", "build"} else ELIGIBLE_INSPECTION
    if cls not in ok:
        audit("GATE_REFUSED", source=sid, reason=f"licence class {cls}", stage=stage)
        raise GateError(f"{sid}: licence class {cls} not eligible for {stage}")
    if not src.get("training_rights_verified", False) and stage in {"ingest", "build"}:
        audit("GATE_REFUSED", source=sid, reason="training rights not verified", stage=stage)
        raise GateError(f"{sid}: training rights not verified -> refusing ingest")
    audit("GATE_PASSED", source=sid, license_class=cls, stage=stage)
    return src


# --------------------------------------------------------------------------- #
# stage 1: hash verification
# --------------------------------------------------------------------------- #
def sha256_file(p: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for blk in iter(lambda: fh.read(chunk), b""):
            h.update(blk)
    return h.hexdigest()


def cmd_verify(args) -> int:
    allow = load_allowlist()
    QUAR.mkdir(exist_ok=True)
    bad = 0
    for sid, src in allow.items():
        rel = src.get("local_path")
        if not rel:
            continue
        path = safe_path(rel)
        if not path.exists():
            audit("ARTEFACT_MISSING", source=sid, path=str(path))
            print(f"[skip] {sid}: no local artefact at {rel}")
            continue
        if path.is_dir():
            audit("HASH_NOT_APPLICABLE", source=sid, reason="directory source; hashes recorded per file at download time")
            print(f"[skip] {sid}: directory source, no single artefact hash")
            continue
        digest = sha256_file(path)
        exp = (src.get("expected_sha256") or "").lower()
        if exp and digest != exp:
            dest = QUAR / f"{sid}__{path.name}"
            shutil.move(str(path), str(dest))
            audit("HASH_MISMATCH", source=sid, expected=exp, actual=digest,
                  quarantined=str(dest.relative_to(ROOT)))
            print(f"[FAIL] {sid}: expected {exp} got {digest} -> quarantined")
            bad += 1
        else:
            audit("HASH_OK", source=sid, sha256=digest, expected=exp or "unrecorded")
            print(f"[ok]   {sid}: {digest} ({'pinned' if exp else 'no expected hash'})")
    if bad:
        print(f"\n{bad} hash mismatch(es): artefacts quarantined, refusing to continue")
        return 2
    return 0


# --------------------------------------------------------------------------- #
# stage 2: ingest (text extraction only; no execution)
# --------------------------------------------------------------------------- #
def iter_text_files(base: Path, exts):
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d != ".git"]
        for f in files:
            p = Path(root) / f
            if exts and p.suffix.lower() not in exts:
                continue
            try:
                if p.stat().st_size > 40 * 1024 * 1024:
                    audit("FILE_TOO_LARGE", file=str(p))
                    continue
                yield p
            except OSError:
                continue


def cmd_ingest(args) -> int:
    allow = load_allowlist()
    CORPUS.mkdir(exist_ok=True)
    total = 0
    for sid in args.sources or list(allow):
        src = require_source(sid, allow, "ingest")
        base = safe_path(src.get("local_path") or "")
        if not base.exists():
            print(f"[skip] {sid}: nothing to ingest")
            continue
        out = CORPUS / "raw" / f"{sid}.jsonl"
        out.parent.mkdir(parents=True, exist_ok=True)
        n = 0
        with open(out, "w", encoding="utf-8") as fh:
            for p in iter_text_files(base if base.is_dir() else base.parent,
                                     set(src.get("extensions") or []) or None):
                if base.is_file() and p != base:
                    continue
                try:
                    text = p.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                if not text.strip():
                    continue
                rel = str(p.relative_to(CORPUS.parent)) if p.is_relative_to(CORPUS.parent) else p.name
                rows = [(rel, text)]
                if p.suffix.lower() == ".jsonl":          # already record-structured
                    rows = []
                    for i, line in enumerate(text.splitlines()):
                        try:
                            obj = json.loads(line)
                        except ValueError:
                            continue
                        if isinstance(obj, dict) and isinstance(obj.get("text"), str):
                            rows.append((f"{rel}#{i}", obj["text"]))
                for path_label, body in rows:
                    if not body.strip():
                        continue
                    fh.write(json.dumps({
                        "source_id": sid, "path": path_label, "text": body,
                        "sha256": hashlib.sha256(body.encode()).hexdigest(),
                        "chars": len(body),
                    }) + "\n")
                    n += 1
        total += n
        audit("INGESTED", source=sid, records=n, output=str(out.relative_to(ROOT)))
        print(f"[ingest] {sid}: {n} records -> {out.relative_to(ROOT)}")
    return 0 if total else 1


# --------------------------------------------------------------------------- #
# stage 3: scanning (secrets, PII, malware indicators)
# --------------------------------------------------------------------------- #
SECRET_PATTERNS = {
    "aws_access_key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "private_key_block": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |PGP )?PRIVATE KEY-----"),
    "github_token": re.compile(r"\bgh[pousr]_[0-9A-Za-z]{36,}\b"),
    "slack_token": re.compile(r"\bxox[baprs]-[0-9A-Za-z-]{10,}\b"),
    "jwt": re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}\b"),
}
MALWARE_INDICATORS = {
    "eicar_test_string": re.compile(r"X5O!P%@AP\[4\\PZX54\(P\^\)7CC\)7\}\$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!\$H\+H\*"),
    "pe_header": re.compile(r"^MZ\x90\x00"),
    "elf_header": re.compile(r"^\x7fELF"),
    "powershell_download_cradle": re.compile(r"(?i)Invoke-Expression.{0,80}(DownloadString|Net\.WebClient)"),
    "mimikatz_sekurlsa": re.compile(r"(?i)sekurlsa::(logonpasswords|minidump)"),
}
PII_PATTERNS = {
    "email": re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]{2,}\b"),
    "ssn_us": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
}


def redact(text: str, hits) -> str:
    for name in hits:
        text = SECRET_PATTERNS[name].sub(f"[REDACTED:{name}]", text)
    return text


def cmd_scan(args) -> int:
    policy = json.load(open(CONFIG / "scan_policy.json", encoding="utf-8"))
    stats = collections.Counter()
    for raw in sorted((CORPUS / "raw").glob("*.jsonl")):
        sid = raw.stem
        clean = CORPUS / "clean" / f"{sid}.jsonl"
        quar = QUAR / f"{sid}.quarantine.jsonl"
        clean.parent.mkdir(parents=True, exist_ok=True)
        quar.parent.mkdir(parents=True, exist_ok=True)
        with open(raw, encoding="utf-8") as fin, \
             open(clean, "w", encoding="utf-8") as fok, \
             open(quar, "w", encoding="utf-8") as fq:
            for line in fin:
                rec = json.loads(line)
                text = rec["text"]
                mal = [k for k, rx in MALWARE_INDICATORS.items() if rx.search(text)]
                if mal:
                    rec["quarantine_reason"] = "malware_indicator:" + ",".join(mal)
                    fq.write(json.dumps(rec) + "\n")
                    stats["quarantined"] += 1
                    audit("QUARANTINED", source=sid, path=rec["path"], reasons=mal)
                    continue
                sec = [k for k, rx in SECRET_PATTERNS.items() if rx.search(text)]
                pii = [k for k, rx in PII_PATTERNS.items() if rx.search(text)]
                if sec:
                    if policy["secrets"] == "quarantine":
                        rec["quarantine_reason"] = "secret:" + ",".join(sec)
                        fq.write(json.dumps(rec) + "\n")
                        stats["quarantined"] += 1
                        audit("QUARANTINED", source=sid, path=rec["path"], reasons=sec)
                        continue
                    text = redact(text, sec)
                    stats["redacted"] += 1
                    audit("REDACTED", source=sid, path=rec["path"], reasons=sec)
                if pii and policy["pii"] == "redact":
                    for k in pii:
                        text = PII_PATTERNS[k].sub(f"[REDACTED:{k}]", text)
                    stats["pii_redacted"] += 1
                rec["text"] = text
                rec["sha256"] = hashlib.sha256(text.encode()).hexdigest()
                fok.write(json.dumps(rec) + "\n")
                stats["clean"] += 1
        print(f"[scan] {sid}: clean={stats['clean']} quarantined={stats['quarantined']}")
    audit("SCAN_SUMMARY", **stats)
    return 0


# --------------------------------------------------------------------------- #
# stage 4: dedup (exact + MinHash/LSH near-duplicate)
# --------------------------------------------------------------------------- #
def shingles(text: str, k: int = 5) -> set:
    words = re.findall(r"\w+", text.lower())
    if len(words) < k:
        return {" ".join(words)} if words else set()
    return {" ".join(words[i:i + k]) for i in range(len(words) - k + 1)}


PERM_SEEDS = [f"microcore-{i}".encode() for i in range(64)]
SIM_THRESHOLD = 0.65  # estimated Jaccard from MinHash agreement (tunable; short docs need lower thresholds)


def minhash(sh: set) -> tuple:
    if not sh:
        return tuple([0] * 64)
    out = []
    for seed in PERM_SEEDS:
        out.append(min(int.from_bytes(hashlib.blake2b((seed + s.encode()), digest_size=8).digest(), "big")
                       for s in sh))
    return tuple(out)


def lsh_bands(sig: tuple, rows: int = 4):
    for b in range(0, len(sig), rows):
        band = sig[b:b + rows]
        yield b // rows, hashlib.blake2b(repr(band).encode(), digest_size=8).hexdigest()


def cmd_dedup(args) -> int:
    rows = int(args.rows)
    cmd_dedup.sim = float(getattr(args, "sim", SIM_THRESHOLD) or SIM_THRESHOLD)
    seen_hash = {}
    buckets = collections.defaultdict(list)
    kept = dropped_exact = dropped_near = 0
    for clean in sorted((CORPUS / "clean").glob("*.jsonl")):
        sid = clean.stem
        dst = CORPUS / "dedup" / f"{sid}.jsonl"
        dst.parent.mkdir(parents=True, exist_ok=True)
        with open(clean, encoding="utf-8") as fin, open(dst, "w", encoding="utf-8") as fout:
            for line in fin:
                rec = json.loads(line)
                h = rec["sha256"]
                if h in seen_hash:
                    dropped_exact += 1
                    audit("DUP_EXACT", source=sid, path=rec["path"], of=seen_hash[h])
                    continue
                sig = minhash(shingles(rec["text"]))
                cand = None
                for _, key in lsh_bands(sig, rows):
                    for other in buckets[key]:
                        agree = sum(1 for x, y in zip(other[0], sig) if x == y)
                        if agree / len(sig) >= float(getattr(cmd_dedup, 'sim', SIM_THRESHOLD)):
                            cand = other[1]
                            break
                    if cand:
                        break
                if cand:
                    dropped_near += 1
                    audit("DUP_NEAR", source=sid, path=rec["path"], of=cand)
                    continue
                for _, key in lsh_bands(sig, rows):
                    buckets[key].append((sig, rec["path"]))
                seen_hash[h] = rec["path"]
                fout.write(json.dumps(rec) + "\n")
                kept += 1
    stats = {"kept": kept, "dropped_exact": dropped_exact, "dropped_near": dropped_near,
             "bucket_count": len(buckets), "rows": rows}
    audit("DEDUP_SUMMARY", **stats)
    json.dump(stats, open(OUT / "dedup_summary.json", "w"), indent=1)
    print(f"[dedup] kept={kept} exact={dropped_exact} near={dropped_near} buckets={len(buckets)}")
    return 0


# --------------------------------------------------------------------------- #
# stage 5: leakage exclusion
# --------------------------------------------------------------------------- #
def cmd_leakage(args) -> int:
    ex = json.load(open(CONFIG / "leakage_exclusions.json", encoding="utf-8"))
    hashes = set(ex["sha256"])
    prints = {tuple(p) for p in ex.get("minhash", [])}
    dropped = 0
    for ded in sorted((CORPUS / "dedup").glob("*.jsonl")):
        sid = ded.stem
        dst = CORPUS / "leakfree" / f"{sid}.jsonl"
        dst.parent.mkdir(parents=True, exist_ok=True)
        with open(ded, encoding="utf-8") as fin, open(dst, "w", encoding="utf-8") as fout:
            for line in fin:
                rec = json.loads(line)
                if rec["sha256"] in hashes or minhash(shingles(rec["text"])) in prints:
                    dropped += 1
                    audit("LEAKAGE_EXCLUDED", source=sid, path=rec["path"])
                    continue
                fout.write(json.dumps(rec) + "\n")
    audit("LEAKAGE_SUMMARY", excluded=dropped, list_size=len(hashes), fingerprints=len(prints))
    print(f"[leakage] excluded={dropped} (hash list={len(hashes)}, fingerprints={len(prints)})")
    return 0


# --------------------------------------------------------------------------- #
# stage 6: token counting (two tokenizers)
# --------------------------------------------------------------------------- #
def cmd_tokens(args) -> int:
    import tiktoken
    from tokenizers import Tokenizer
    enc = tiktoken.get_encoding("cl100k_base")
    try:
        gpt2 = Tokenizer.from_pretrained("gpt2")
    except Exception as e:  # pragma: no cover
        print(f"gpt2 unavailable: {e}", file=sys.stderr)
        gpt2 = None
    per_source = {}
    for f in sorted((CORPUS / "leakfree").glob("*.jsonl")):
        a = b = chars = recs = 0
        with open(f, encoding="utf-8") as fh:
            for line in fh:
                t = json.loads(line)["text"]
                recs += 1
                chars += len(t)
                a += len(enc.encode_ordinary(t))
                if gpt2:
                    b += len(gpt2.encode(t).ids)
        per_source[f.stem] = {"records": recs, "chars": chars,
                              "tokens_cl100k": a, "tokens_gpt2": b}
        print(f"[tokens] {f.stem}: {recs} recs, {a} cl100k, {b} gpt2")
    report = {
        "tokenizers": {"A": "tiktoken cl100k_base", "B": "GPT-2 BPE (tokenizers.from_pretrained('gpt2'))"},
        "per_source": per_source,
        "totals": {
            "records": sum(v["records"] for v in per_source.values()),
            "chars": sum(v["chars"] for v in per_source.values()),
            "tokens_cl100k": sum(v["tokens_cl100k"] for v in per_source.values()),
            "tokens_gpt2": sum(v["tokens_gpt2"] for v in per_source.values()),
        },
    }
    json.dump(report, open(OUT / "token_report.json", "w"), indent=1)
    print(f"[tokens] total cl100k={report['totals']['tokens_cl100k']} "
          f"gpt2={report['totals']['tokens_gpt2']}")
    return 0


# --------------------------------------------------------------------------- #
# stage 7: dataset cards
# --------------------------------------------------------------------------- #
def cmd_cards(args) -> int:
    allow = load_allowlist()
    tok = {}
    tp = OUT / "token_report.json"
    if tp.exists():
        tok = json.load(open(tp))["per_source"]
    cards = OUT / "cards"
    cards.mkdir(parents=True, exist_ok=True)
    n = 0
    for sid, src in allow.items():
        if src.get("tier") != "A":
            continue
        t = tok.get(sid, {})
        body = f"""# Dataset card — {src['name']}

| field | value |
|---|---|
| Dataset ID | {sid} |
| Canonical publisher | {src['publisher']} |
| Canonical URL | {src['url']} |
| Direct download | {src.get('download_url', 'not recorded')} |
| Licence | {src['license']} ({src['license_class']}) |
| Licence URL | {src.get('license_url', 'n/a')} |
| Obligations | {src.get('obligations', 'none recorded')} |
| Verified on | {src['verified_date']} |
| Access class | {src.get('access_class', 'n/a')} |
| Verification level | {src.get('verification_level', 'n/a')} |
| Format | {src.get('format', 'n/a')} |
| Records (verified) | {src.get('records', 'n/a')} |
| Bytes (verified) | {src.get('bytes', 'n/a')} |
| SHA-256 | {src.get('sha256', 'n/a')} |
| Domain | {src.get('domain', 'n/a')} |
| Measured tokens (cl100k_base) | {t.get('tokens_cl100k', 'not measured')} |
| Measured tokens (GPT-2 BPE) | {t.get('tokens_gpt2', 'not measured')} |

## Technical content
{src.get('technical_content', 'recorded in master inventory')}

## Quality findings
{src.get('quality', 'see master inventory')}

## Parsing instructions
{src.get('parsing', 'see pipeline config')}

## Deduplication instructions
Exact-hash dedup on normalised text, then MinHash (64 permutations, 5-word
shingles) with 4-row LSH bands. Cross-source identity: compare one representative
per source before merging; the same record reached through a mirror is not new data.

## Known risks
{src.get('risks', 'no specific risks recorded')}
"""
        (cards / f"{sid}.md").write_text(body, encoding="utf-8")
        n += 1
    audit("CARDS_WRITTEN", count=n)
    print(f"[cards] {n} cards -> out/cards/")
    return 0


def cmd_run(args) -> int:
    rc = cmd_verify(args)
    if rc != 0:
        return rc
    for fn in (cmd_ingest, cmd_scan, cmd_dedup, cmd_leakage, cmd_tokens, cmd_cards):
        rc = fn(args)
        if rc != 0:
            return rc
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="MICROCORE acquisition + audit pipeline v2")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("verify", "ingest", "scan", "dedup", "leakage", "tokens", "cards", "run"):
        p = sub.add_parser(name)
        p.add_argument("--sources", nargs="*", default=None)
        p.add_argument("--rows", default="4")
        p.add_argument("--sim", default=None)
    a = ap.parse_args(argv)
    try:
        return {"verify": cmd_verify, "ingest": cmd_ingest, "scan": cmd_scan,
                "dedup": cmd_dedup, "leakage": cmd_leakage, "tokens": cmd_tokens,
                "cards": cmd_cards, "run": cmd_run}[a.cmd](a)
    except GateError as e:
        print(f"[GATE] {e}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    sys.exit(main())
