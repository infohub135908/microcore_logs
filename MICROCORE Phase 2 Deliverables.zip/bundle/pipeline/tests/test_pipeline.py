"""Tests for the MICROCORE pipeline v2. Run: python -m pytest -v tests/"""
import json
import shutil
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
PKG = HERE.parent
sys.path.insert(0, str(PKG))
import pipeline as P  # noqa: E402

FIXTURE = PKG / "fixtures" / "records.jsonl"


def make_root(tmp_path, license_class="LICENSE_VERIFIED_COMPATIBLE", training=True,
              expected=None, with_file=True, local_path="data/sample.jsonl"):
    """Build a disposable pipeline root and repoint the module globals at it."""
    root = tmp_path / "root"
    (root / "config").mkdir(parents=True)
    allow = {"schema": "test", "sources": [{
        "id": "MC-TEST-01", "name": "Test source", "publisher": "test",
        "url": "https://example.invalid", "download_url": "https://example.invalid/x",
        "license": "test licence", "license_class": license_class,
        "license_url": "https://example.invalid/l", "obligations": "none",
        "training_rights_verified": training, "verified_date": "2026-11-27",
        "tier": "A", "local_path": local_path, "extensions": [".jsonl"],
        "expected_sha256": expected,
    }]}
    (root / "config" / "allowlist.json").write_text(json.dumps(allow))
    (root / "config" / "scan_policy.json").write_text(json.dumps(
        {"secrets": "quarantine", "pii": "redact", "malware_indicators": "quarantine",
         "never_execute": True}))
    (root / "config" / "leakage_exclusions.json").write_text(json.dumps(
        {"sha256": [], "minhash": [], "source_ids": []}))
    if with_file:
        d = root / local_path
        d.parent.mkdir(parents=True, exist_ok=True)
        d.write_text(FIXTURE.read_text() if d.suffix == ".jsonl" else "x")
    setattr(P, "ROOT", root)
    setattr(P, "OUT", root / "out")
    setattr(P, "WORK", root / "work")
    setattr(P, "QUAR", root / "quarantine")
    setattr(P, "CORPUS", root / "corpus")
    P.CONFIG = root / "config"
    return root


def seed_corpus(root, recs=None):
    raw = root / "corpus" / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    text = FIXTURE.read_text() if recs is None else "\n".join(json.dumps(r) for r in recs) + "\n"
    (raw / "MC-TEST-01.jsonl").write_text(text)


# ---------------------------------------------------------------- gates
def test_gate_accepts_verified_compatible(tmp_path):
    make_root(tmp_path)
    assert P.require_source("MC-TEST-01", P.load_allowlist(), "ingest")["id"] == "MC-TEST-01"


def test_gate_refuses_unlisted_source(tmp_path):
    make_root(tmp_path)
    with pytest.raises(P.GateError):
        P.require_source("MC-999", P.load_allowlist(), "ingest")


def test_gate_refuses_no_license(tmp_path):
    make_root(tmp_path, license_class="NO_LICENSE_FOUND", training=False)
    with pytest.raises(P.GateError):
        P.require_source("MC-TEST-01", P.load_allowlist(), "ingest")


def test_gate_allows_restricted_for_inspection_only(tmp_path):
    make_root(tmp_path, license_class="LICENSE_VERIFIED_RESTRICTED", training=False)
    P.require_source("MC-TEST-01", P.load_allowlist(), "scan")
    with pytest.raises(P.GateError):
        P.require_source("MC-TEST-01", P.load_allowlist(), "ingest")


def test_path_escape_is_rejected(tmp_path):
    make_root(tmp_path)
    with pytest.raises(P.GateError):
        P.safe_path("../../etc/passwd")


# ---------------------------------------------------------------- hashes
def test_hash_mismatch_quarantines_and_returns_2(tmp_path):
    root = make_root(tmp_path, expected="0" * 64)
    rc = P.main(["verify"])
    dest = list((root / "quarantine").glob("MC-TEST-01__*"))
    assert rc == 2 and dest, "mismatch must quarantine and exit non-zero"
    log = [json.loads(l) for l in (root / "out" / "audit_log.jsonl").read_text().splitlines()]
    assert any(e["event"] == "HASH_MISMATCH" for e in log)


def test_hash_match_passes(tmp_path):
    import hashlib
    root = make_root(tmp_path, with_file=False, local_path="data/sample.bin")
    f = root / "data" / "sample.bin"
    f.parent.mkdir(parents=True)
    f.write_bytes(b"hello")
    allow = json.loads((root / "config" / "allowlist.json").read_text())
    allow["sources"][0]["expected_sha256"] = hashlib.sha256(b"hello").hexdigest()
    (root / "config" / "allowlist.json").write_text(json.dumps(allow))
    assert P.main(["verify"]) == 0


# ---------------------------------------------------------------- scanning
def test_scan_quarantines_secret_and_eicar(tmp_path):
    root = make_root(tmp_path)
    seed_corpus(root)
    assert P.main(["scan"]) == 0
    clean = [json.loads(l) for l in (root / "corpus" / "clean" / "MC-TEST-01.jsonl").read_text().splitlines()]
    quar = [json.loads(l) for l in (root / "quarantine" / "MC-TEST-01.quarantine.jsonl").read_text().splitlines()]
    paths = {r["path"] for r in clean}
    assert "a.md" in paths and "c_secret.md" not in paths and "d_eicar.md" not in paths
    reasons = " ".join(r["quarantine_reason"] for r in quar)
    assert "secret:aws_access_key" in reasons and "eicar_test_string" in reasons


# ---------------------------------------------------------------- dedup
def test_dedup_removes_exact_and_near_duplicates(tmp_path):
    root = make_root(tmp_path)
    seed_corpus(root)
    P.main(["scan"])
    assert P.main(["dedup"]) == 0
    kept = [json.loads(l) for l in (root / "corpus" / "dedup" / "MC-TEST-01.jsonl").read_text().splitlines()]
    paths = [r["path"] for r in kept]
    assert "a_copy.md" not in paths, "exact duplicate must be dropped"
    assert "b_near.md" not in paths, "near duplicate must be dropped by LSH"
    assert "a.md" in paths and "e_unique.md" in paths
    summary = json.loads((root / "out" / "dedup_summary.json").read_text())
    assert summary["dropped_exact"] == 1 and summary["dropped_near"] >= 1


def test_dedup_is_subquadratic(tmp_path):
    """Cost must grow with buckets, not with record pairs."""
    import time
    root = make_root(tmp_path)
    recs = []
    for i in range(400):
        t = f"unique record {i} about topic {i*7919} covering artefact {i}"
        recs.append({"source_id": "MC-TEST-01", "path": f"r{i}.md", "text": t,
                     "sha256": __import__("hashlib").sha256(t.encode()).hexdigest(), "chars": len(t)})
    seed_corpus(root, recs)
    P.main(["scan"])
    t0 = time.time()
    P.main(["dedup"])
    elapsed = time.time() - t0
    summary = json.loads((root / "out" / "dedup_summary.json").read_text())
    assert summary["kept"] == 400
    assert elapsed < 30, f"dedup too slow for 400 records: {elapsed:.1f}s"


# ---------------------------------------------------------------- leakage
def test_leakage_exclusion_by_hash(tmp_path):
    root = make_root(tmp_path)
    seed_corpus(root)
    P.main(["scan"])
    P.main(["dedup"])
    target = (root / "corpus" / "dedup" / "MC-TEST-01.jsonl").read_text().splitlines()[0]
    h = json.loads(target)["sha256"]
    (root / "config" / "leakage_exclusions.json").write_text(json.dumps({"sha256": [h], "minhash": []}))
    assert P.main(["leakage"]) == 0
    left = [json.loads(l) for l in (root / "corpus" / "leakfree" / "MC-TEST-01.jsonl").read_text().splitlines()]
    assert h not in {r["sha256"] for r in left}


# ---------------------------------------------------------------- tokens + cards
def test_end_to_end_run_measures_two_tokenizers_and_writes_cards(tmp_path):
    root = make_root(tmp_path)
    seed_corpus(root)
    rc = P.main(["run"])
    assert rc == 0
    rep = json.loads((root / "out" / "token_report.json").read_text())
    s = rep["per_source"]["MC-TEST-01"]
    assert s["tokens_cl100k"] > 0 and s["tokens_gpt2"] > 0
    assert s["tokens_gpt2"] != s["tokens_cl100k"]
    cards = list((root / "out" / "cards").glob("*.md"))
    assert cards, "a Tier-A source must produce a card"
