#!/usr/bin/env python3
import csv, glob, json, os
from collections import OrderedDict
import records

# measurement files -> dataset id
MEAS = {
 "MC-201": "data/m_nginx.json", "MC-202": "data/m_MC-202.json", "MC-203": "data/m_MC-203.json",
 "MC-204": "data/m_MC-204.json", "MC-205": "data/m_MC-205.json", "MC-206": "data/m_MC-206.json",
 "MC-207": "data/m_MC-207.json", "MC-208": "data/m_MC-208.json", "MC-209": "data/m_MC-209.json",
 "MC-210": "data/m_MC-210.json", "MC-211": "data/m_MC-211.json", "MC-212": "data/m_MC-212.json",
 "MC-213": "data/m_MC-213.json", "MC-214": "data/m_MC-214.json", "MC-215": "data/m_MC-215.json",
 "MC-216": "data/m_MC-216.json", "MC-217": "data/m_MC-217.json", "MC-218": "data/m_MC-218.json",
 "MC-219": "data/m_MC-219.json", "MC-220": "data/m_MC-220.json",
 "MC-222": "data/a_MC-222.json", "MC-223": "data/a_MC-223.json", "MC-224": "data/a_MC-224.json",
 "MC-225": "data/a_MC-225.json",
}

def load():
    out = {}
    for did, path in MEAS.items():
        if not os.path.exists(path):
            continue
        d = json.load(open(path))
        cl = d.get("cl100k", d.get("cl100k_eligible"))
        g2 = d.get("gpt2", d.get("gpt2_eligible"))
        out[did] = {"cl100k": cl, "gpt2": g2,
                    "files": d.get("files_selected"),
                    "bytes": d.get("bytes_selected", d.get("bytes_eligible")),
                    "bad_spdx": d.get("files_bad_spdx", 0),
                    "restricted_cl": d.get("cl100k_restricted", 0),
                    "pending_cl": d.get("cl100k_pending", 0),
                    "elapsed": d.get("elapsed_s")}
    # MC-225 (Vulnrichment): the raw stream is JSON boilerplate. Replace the
    # raw count with the measured content-only, shingle-deduplicated figure and
    # keep the raw numbers alongside so nothing is hidden.
    if "MC-225" in out and os.path.exists("data/vuln_content.json"):
        vc = json.load(open("data/vuln_content.json"))
        sh = json.load(open("data/vuln_shingle.json"))
        adj = round(vc["content_cl100k"] * sh["unique_shingle_ratio"])
        out["MC-225"]["raw_cl100k"] = out["MC-225"]["cl100k"]
        out["MC-225"]["raw_gpt2"] = out["MC-225"]["gpt2"]
        out["MC-225"]["content_cl100k"] = vc["content_cl100k"]
        out["MC-225"]["cl100k"] = adj
        out["MC-225"]["gpt2"] = None   # content-only GPT-2 not measured
    return out

COLS = ["Dataset ID","Name","Publisher","Canonical URL","Direct Download","Domain","Subdomain",
        "Description","Format","Verified Size","Verified Record Count","Version","Publication Date",
        "Last Update","Licence Name","Licence Version","Licence URL","Training Rights Assessment",
        "Commercial Use Status","Attribution Obligations","Access Classification","HTTP Status",
        "File Inspection Level","Verification Evidence","SHA-256","Duplicate Relationship","Data Quality",
        "Privacy/Secret Risks","Estimated Usable Tokens","Tokenizer","Technical Score","Tier",
        "Conditions","Recommended Action","Audit Date","License Class"]

def build():
    meas = load()
    rows = []
    for r in records.R:
        m = meas.get(r["id"], {})
        cl = m.get("cl100k")
        size = f"{m['bytes']/1e6:.1f} MB text-bearing" if m.get("bytes") else "not downloaded"
        rec = {
            "Dataset ID": r["id"], "Name": r["name"], "Publisher": r["pub"], "Canonical URL": r["url"],
            "Direct Download": r["dl"], "Domain": r["dom"], "Subdomain": r["sub"], "Description": r["desc"],
            "Format": r["fmt"], "Verified Size": size,
            "Verified Record Count": (f"{m['files']:,} files" if m.get("files") else "not counted"),
            "Version": "HEAD as of 2026-11-26", "Publication Date": "continuous",
            "Last Update": "2026-11-25/26 (upstream push)",
            "Licence Name": r["lic"], "Licence Version": r["lv"], "Licence URL": r["licurl"],
            "Training Rights Assessment": ("permits training and redistribution of derived corpus"
                if r["cls"]=="LICENSE_VERIFIED_COMPATIBLE" else
                "restricted: legal review required before any use" if r["cls"]=="LICENSE_VERIFIED_RESTRICTED" else
                "pending: rights not yet established"),
            "Commercial Use Status": r["comm"], "Attribution Obligations": r["attr"],
            "Access Classification": r["acc"], "HTTP Status": "200" if r["acc"]=="VERIFIED_ACCESSIBLE" else "n/a",
            "File Inspection Level": r["level"],
            "Verification Evidence": (f"streamed and tokenized: {m['files']:,} files, {m['bytes']/1e6:.1f} MB, two tokenizers"
                if m.get("files") else "licence file fetched and hashed; content not streamed"),
            "SHA-256": "see data/license_files*.json for licence-file digests",
            "Duplicate Relationship": ("independent" if r["id"] not in ("MC-216","MC-217","MC-218","MC-219","MC-220")
                else "sibling Microsoft Learn repos; overlap not yet measured"),
            "Data Quality": "high" if r["score"]>=85 else "medium" if r["score"]>=70 else "low",
            "Privacy/Secret Risks": ("payload/credential strings possible; scan before ingest" if r["id"] in ("MC-223","MC-222")
                else "no personal data expected"), "Estimated Usable Tokens": cl if cl else "",
            "Tokenizer": "tiktoken cl100k_base" if cl else "", "Technical Score": r["score"], "Tier": r["tier"],
            "Conditions": r["cond"], "Recommended Action": r["act"], "Audit Date": "2026-11-26",
            "License Class": r["cls"]}
        rows.append(rec)
    OVR = {
      "MC-221": {"Verified Size": "531.6 MB (Dataverse file 8083462)",
                 "Verified Record Count": "2,000,002 rows (2-file sample); 3,000,003 rows (3-file sample)",
                 "Verification Evidence": "downloaded and parsed: 84,852,864 raw cl100k at 0.061 % unique tuples; session aggregation gives 253,279 cl100k",
                 "Estimated Usable Tokens": ""},
      "MC-224": {"Verified Size": "not retained", "Verified Record Count": "not tokenized",
                 "Verification Evidence": "licence file verified (CC BY 4.0); ~300k small JSON files exceeded the phase time window, measurement aborted",
                 "Estimated Usable Tokens": ""},
      "MC-235": {"Verified Size": "streamed, not retained",
                 "Verified Record Count": "15,183 files seen, 12,197 classified LICENSE_UNCLEAR",
                 "Verification Evidence": "streamed and classified: 21,304,004 cl100k pending review, 0 eligible",
                 "Estimated Usable Tokens": ""},
    }
    rows = [dict(r, **OVR[r["Dataset ID"]]) if r["Dataset ID"] in OVR else r for r in rows]
    os.makedirs("out", exist_ok=True)
    with open("out/p3_inventory.csv","w",newline="",encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLS); w.writeheader(); w.writerows(rows)
    json.dump(rows, open("out/p3_inventory.json","w"), indent=1)

    # token yield
    ty = []
    tot_cl = tot_g2 = 0
    for did, m in meas.items():
        ty.append({"dataset_id": did, "cl100k": m["cl100k"], "gpt2": m["gpt2"],
                   "files": m["files"], "mb": round((m["bytes"] or 0)/1e6,1),
                   "tokens_per_mb": round(m["cl100k"]/(m["bytes"]/1e6),0) if m.get("bytes") else 0})
        tot_cl += m["cl100k"]; tot_g2 += m["gpt2"] or 0
    with open("out/token_yield_p3.csv","w",newline="",encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["dataset_id","cl100k","gpt2","files","mb","tokens_per_mb"])
        w.writeheader(); w.writerows(sorted(ty,key=lambda x:-x["cl100k"]))
    p2 = json.load(open("../p2/out/token_summary.json"))
    labtot = json.load(open("labs/lab_stats.json"))["total_cl100k"]
    base = p2["verified_cl100k_training_eligible"] + tot_cl + labtot
    summary = {
        "phase2_baseline_cl100k": p2["verified_cl100k_training_eligible"],
        "p3_measured_cl100k": tot_cl, "p3_measured_gpt2": tot_g2,
        "p3_sources_measured": len(meas),
        "combined_cl100k": base,
        "labs_cl100k_included": labtot,
        "target": 5_000_000_000,
        "remaining": 5_000_000_000 - base,
        "pct": round(100*base/5e9, 2),
        "vulnrichment_raw_cl100k": json.load(open("data/a_MC-225.json"))["cl100k_eligible"],
        "vulnrichment_content_cl100k": json.load(open("data/vuln_content.json"))["content_cl100k"],
        "vulnrichment_shingle_ratio": json.load(open("data/vuln_shingle.json"))["unique_shingle_ratio"],
        "vulnrichment_counted_cl100k": meas["MC-225"]["cl100k"],
        "metasploit_pending_cl100k": json.load(open("data/a_MC-226.json"))["cl100k_pending"],
        "labs_cl100k": json.load(open("labs/lab_stats.json"))["total_cl100k"],
        "telemetry_rows_cl100k": json.load(open("data/m_MC-221.json"))["cl100k"],
        "telemetry_unique_cl100k": json.load(open("data/m_MC-221b.json"))["cl100k_unique"],
    }
    json.dump(summary, open("out/p3_summary.json","w"), indent=1)
    print(json.dumps(summary, indent=1))
    print("rows:", len(rows))

if __name__ == "__main__":
    build()
