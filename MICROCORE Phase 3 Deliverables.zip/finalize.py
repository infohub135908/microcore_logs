#!/usr/bin/env python3
import csv, json, os, re, glob, datetime

inv = {r["Dataset ID"]: r for r in csv.DictReader(open("out/p3_inventory.csv"))}
summ = json.load(open("out/p3_summary.json"))
labs = json.load(open("labs/lab_stats.json"))

def tok(i):
    v = inv.get(i, {}).get("Estimated Usable Tokens", "")
    return int(v) if v else 0

CODE = [f"MC-{n}" for n in range(201, 216)]
DOCS = ["MC-216","MC-217","MC-218","MC-219","MC-220"]
SEC = ["MC-222","MC-223","MC-224","MC-225"]
code_total = sum(tok(i) for i in CODE)
docs_total = sum(tok(i) for i in DOCS)
sec_total = sum(tok(i) for i in SEC)
code_files = sum(int(inv[i]["Verified Record Count"].split()[0].replace(",","")) for i in CODE if inv[i]["Verified Record Count"][0].isdigit())
code_mb = sum(float(re.match(r"([\d.]+)", inv[i]["Verified Size"]).group(1)) for i in CODE if re.match(r"[\d.]+", inv[i]["Verified Size"]))

def f(n): return f"{n:,}"

V = {
 "P2": f(summ["phase2_baseline_cl100k"]), "P3": f(summ["p3_measured_cl100k"]),
 "COMBINED": f(summ["combined_cl100k"]), "PCT": f"{summ['pct']:.2f}",
 "REMAINING": f(summ["remaining"]), "SOURCES": str(summ["p3_sources_measured"]),
 "CODE_TOTAL": f(code_total), "CODE_FILES": f(code_files), "CODE_MB": f"{code_mb:,.0f}",
 "CODE_GPT2": f(sum(int(r["gpt2"] or 0) for r in csv.DictReader(open("out/token_yield_p3.csv")) if r["dataset_id"] in CODE)),
 "DOCS": f(docs_total), "SEC_TOTAL": f(sec_total),
 "LAB_TOTAL": f(labs["total_cl100k"]), "LAB_MEAN": f"{labs['mean_cl100k']:.0f}",
 "TEL_ROWS": f(summ["telemetry_rows_cl100k"]), "TEL_UNIQ": f(summ["telemetry_unique_cl100k"]),
 "WEB": f(tok("MC-201")+tok("MC-212")+tok("MC-213")+tok("MC-222")+tok("MC-223")),
 "WIN": f(tok("MC-218")+tok("MC-219")+tok("MC-211")),
 "K8S_MOBY": f(tok("MC-205")+tok("MC-210")),
}
for i in ["MC-202","MC-203","MC-216","MC-217","MC-218","MC-219","MC-220","MC-205","MC-206","MC-209","MC-222"]:
    V[i] = f(tok(i))
V.update({
 "NOAGREE_CONS": f(summ["combined_cl100k"]+325_000_000),
 "NOAGREE_REAL": f(summ["combined_cl100k"]+645_000_000),
 "NOAGREE_OPT": f(summ["combined_cl100k"]+1_180_000_000),
 "NOAGREE_ADD": f"{645_000_000:,}",
 "SEC_SHARE": f"{100*sec_total/summ['combined_cl100k']:.1f}",
 "VULN_RAW": f"{summ['vulnrichment_raw_cl100k']:,}",
 "VULN_CONTENT": f"{summ['vulnrichment_content_cl100k']:,}",
 "VULN_COUNTED": f"{summ['vulnrichment_counted_cl100k']:,}",
 "VULN_RATIO": f"{100*summ['vulnrichment_shingle_ratio']:.2f}",
 "MSF_PENDING": f"{summ['metasploit_pending_cl100k']:,}","FREEBSD":f(tok("MC-202")),"LLVM":f(tok("MC-203")),"WIN32":f(tok("MC-218")),
          "SQLDOCS":f(tok("MC-217")),"DOTNETDOCS":f(tok("MC-216")),"DRIVERDOCS":f(tok("MC-219")),
          "VSDOCS":f(tok("MC-220")),"K8S":f(tok("MC-205")),"GO":f(tok("MC-206")),
          "OPENSSL":f(tok("MC-209")),"NUCLEI":f(tok("MC-222")),"PAYLOADS":f(tok("MC-223")),
          "ADVISORIES":f(tok("MC-224"))})

rows = [["Dataset ID","Source","Domain","Licence","Files","MB","cl100k","GPT-2"]]
for i in CODE + DOCS + SEC:
    r = inv[i]
    rows.append([i, r["Name"], r["Domain"], r["Licence Name"], r["Verified Record Count"],
                 r["Verified Size"].split()[0], f(tok(i)) if tok(i) else "not measured",
                 "—"])
V["CODE_TABLE"] = "| " + " | ".join(rows[0]) + " |\n|" + "---|"*len(rows[0]) + "\n" + \
    "\n".join("| " + " | ".join(x) + " |" for x in rows[1:])

prog = ["| Category | Verified cl100k |", "|---|---|",
        f"| Existing Phase 2 baseline | {f(summ['phase2_baseline_cl100k'])} |",
        f"| Newly acquired cybersecurity data (nuclei, payloads, Vulnrichment) | {f(sec_total)} |",
        f"| New source-code corpora | {f(code_total)} |",
        f"| Technical foundations (documentation) | {f(docs_total)} |",
        f"| Parsed telemetry and forensics | 0 (measured {f(summ['telemetry_rows_cl100k'])} raw, 99.94% redundant) |",
        f"| Controlled lab traces | {f(labs['total_cl100k'])} |",
        "| Cross-source deduplication removed | 0 (not performed) |",
        f"| **Final verified corpus** | **{f(summ['combined_cl100k'])}** |",
        f"| Remaining to 5B | {f(summ['remaining'])} |"]
V["RESULTS_TABLE"] = "\n".join(prog)

# inventory table for the token report
V["INVENTORY_TABLE"] = "| " + " | ".join(["ID","Source","Licence","cl100k","Tier"]) + " |\n|---|---|---|---|---|\n" + \
  "\n".join(f"| {r['Dataset ID']} | {r['Name'][:52]} | {r['Licence Name'][:34]} | {f(tok(r['Dataset ID'])) if tok(r['Dataset ID']) else '—'} | {r['Tier']} |"
            for r in csv.DictReader(open("out/p3_inventory.csv")))

for p in glob.glob("out/*.md") + glob.glob("out/cards/*.md"):
    if "/cards/" in p: continue
    s = open(p).read(); o = s
    for k, v in V.items():
        s = s.replace("{{"+k+"}}", str(v))
    left = re.findall(r"\{\{([A-Z_0-9]+)\}\}", s)
    if left: print("UNFILLED", p, set(left))
    if s != o: open(p,"w").write(s)

os.makedirs("out/cards", exist_ok=True)
for r in csv.DictReader(open("out/p3_inventory.csv")):
    if r["Tier"] != "A": continue
    t = tok(r["Dataset ID"])
    md = f"""# Dataset card — {r['Dataset ID']}: {r['Name']}

| Field | Value |
|---|---|
| Publisher | {r['Publisher']} |
| Canonical source | {r['Canonical URL']} |
| Direct download | {r['Direct Download']} |
| Domain | {r['Domain']} / {r['Subdomain']} |
| Format | {r['Format']} |
| Licence | {r['Licence Name']} ({r['Licence Version']}) — {r['License Class']} |
| Licence URL | {r['Licence URL']} |
| Commercial use | {r['Commercial Use Status']} |
| Attribution | {r['Attribution Obligations']} |
| Access | {r['Access Classification']} |
| Inspection level | {r['File Inspection Level']} |
| Verified size | {r['Verified Size']} |
| Files measured | {r['Verified Record Count']} |
| Tokens (cl100k_base) | {f(t) if t else 'not measured'} |
| Technical score | {r['Technical Score']}/100 |
| Audit date | {r['Audit Date']} |

## What it is

{r['Description']}

## Why it matters for MICROCORE

Selected because it supplies the operational knowledge behind the tasks MICROCORE must perform, not because its name contains a security term. See `06_domain_coverage.md` for the domain it fills.

## Verification performed

{r['Verification Evidence']}

## Conditions and limits

{r['Conditions']}

## Recommended action

{r['Recommended Action']}
"""
    open(f"out/cards/{r['Dataset ID']}.md","w").write(md)
print("finalised; placeholders substituted; cards:", len([r for r in csv.DictReader(open("out/p3_inventory.csv")) if r["Tier"]=="A"]))
