#!/usr/bin/env python3
"""Capture a real, authorized investigation trajectory inside this container."""
import json, os, platform, subprocess, time

SCOPE = ("Authorized scope: the MICROCORE analysis container itself "
         "(hostname %s, uid %s). No external host is contacted." % (platform.node(), os.getuid()))

def run(cmd, timeout=30):
    t0 = time.time()
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
    return {"cmd": cmd, "exit": p.returncode, "stdout": p.stdout[-4000:],
            "stderr": p.stderr[-1000:], "ms": int((time.time() - t0) * 1000)}

TRAJ = []
def traj(tid, objective, steps, interp, conclusion, remediation=None):
    TRAJ.append({"trajectory_id": tid, "schema_version": "mc-trajectory/1.0",
        "objective": objective, "scope": SCOPE,
        "environment": {"os": platform.platform(), "kernel": platform.release(),
                        "python": platform.python_version()},
        "steps": steps, "interpretation": interp, "conclusion": conclusion,
        "remediation": remediation, "verification": "re-run command and compare output",
        "captured": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "provenance": "executed in sandbox, outputs verbatim (truncated to 4000 chars)"})

s1 = run("id; uname -a"); s2 = run("ss -tulpn 2>/dev/null | head -20")
traj("LAB-001", "Establish identity, kernel and network exposure of the host under assessment", [s1, s2],
     "The account is unprivileged (uid 1000) and the kernel is a containerised Linux. Only local sockets are bound; no externally reachable service appears.",
     "Host is a low-privilege container with no externally reachable listening service beyond the local agent socket.",
     "None required; confirm no unexpected listener appears after package installation.")

s3 = run("ps -eo pid,ppid,user,comm --sort=pid | head -25")
traj("LAB-002", "Map the process tree and identify which processes run as root versus the interactive user", [s3],
     "PPID relationships show a single init-like ancestor and a small supervisor set. Only the platform agent runs as root.",
     "Privilege separation is intact; no user-controlled process runs as root.", None)

s4 = run("find / -xdev -perm -4000 -type f 2>/dev/null | head -20")
s5 = run("ls -l /usr/bin/passwd /usr/bin/sudo 2>&1")
traj("LAB-003", "Enumerate setuid binaries and verify mode bits of expected privileged helpers", [s4, s5],
     "The setuid inventory is short and consists of standard distribution helpers; mode check confirms 4755 where expected.",
     "No unexpected setuid binary is present.",
     "Alert on any new setuid file outside package-managed paths.")

s6 = run("head -c 64 /bin/ls | xxd | head -4; readelf -h /bin/ls 2>/dev/null | head -12")
traj("LAB-004", "Verify ELF type and entry point of a core binary to confirm the platform ABI", [s6],
     "Magic bytes 7f 45 4c 46 confirm ELF; the header reports a 64-bit little-endian executable with a non-zero entry point.",
     "Binary is a standard x86-64 ELF PIE; no packing or truncation indicated.", None)

s7 = run("cat /etc/os-release; dpkg -l 2>/dev/null | wc -l")
s8 = run("grep -c . /etc/passwd; awk -F: '$3==0{print $1}' /etc/passwd")
traj("LAB-005", "Confirm distribution baseline and check for unexpected uid-0 accounts", [s7, s8],
     "Distribution and package count match the base image; exactly one account has uid 0.",
     "No duplicate superuser account exists.",
     "Monitor /etc/passwd for new uid-0 entries as a persistence indicator.")

json.dump(TRAJ, open("trajectories.json", "w"), indent=1)
print("trajectories:", len(TRAJ), "steps:", sum(len(t["steps"]) for t in TRAJ))
