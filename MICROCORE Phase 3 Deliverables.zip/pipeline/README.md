# MICROCORE Phase 3 acquisition pipeline

Two layers, deliberately separated:

* `acquire.py` — **new in Phase 3**. Streams a `tar.gz` straight from the forge,
  classifies every file by SPDX header, applies path/ext/binary filters, counts
  tokens with two tokenizers and writes a SHA-256 manifest. Nothing is staged to
  disk, so a 900 MB source needs ~2 MB of RAM per file rather than 900 MB of space.
* Phase 2 `pipeline.py` — retained unchanged for the gate behaviour it already
  enforces (allowlist, path-escape rejection, fatal hash mismatch, LSH dedup,
  leakage persistence, scan-then-quarantine). Copy it in when you need ingest;
  this directory does not re-implement those gates.

## Licence semantics

`classify()` maps an SPDX identifier to one of three outcomes:

| Outcome | Meaning | Counted as |
|---|---|---|
| `VERIFIED_COMPATIBLE` | permissive list (MIT, Apache-2.0, BSD, ISC, CC0, CC-BY-4.0, PSF, PostgreSQL, curl) | eligible tokens |
| `VERIFIED_RESTRICTED` | GPL/LGPL/AGPL/SSPL/BUSL/MPL/EPL/CC-BY-SA/CC-BY-NC | recorded, never eligible |
| `PENDING_REVIEW` | no SPDX header in the file | recorded, never eligible |

A file-level header always beats the repository default, so a GPL file vendored
into an MIT repository is excluded from the eligible count instead of silently
inheriting the repo licence. Pass `--repo-licence VERIFIED_COMPATIBLE` to apply a
verified repository-level licence to the (majority) files that carry no header.

## Commands

```bash
python3 acquire.py --repo freebsd/freebsd-src --branch main \
  --out out/freebsd_stats.json --manifest out/freebsd_manifest.jsonl \
  --gpt2 --repo-licence VERIFIED_COMPATIBLE

python3 -m pytest tests/ -q
```

## Verified results (2026-11-26)

* `pytest tests/` → **12 passed in 0.56 s**
* `acquire.py` on nginx/nginx → 443 manifest rows, 2,102,696 cl100k,
  3,940,943 GPT-2, 9.8 s
* independent harness (`stream_measure.py`) on the same repo → 448 files,
  2,129,218 cl100k (1.3 % difference, attributable to html/css handling)

## Not tested

* No unit test covers a real network failure or a truncated stream; those were
  only observed once, manually, during the Phase 2 clone work.
* Near-duplicate detection at 10^8-file scale is untested; the LSH parameters in
  the Phase 2 module were validated on 2,532 documents.
* Manifest files for the multi-hundred-megabyte sources were not written (only
  aggregate statistics were kept), so per-file re-verification of those sources
  requires re-streaming them.
