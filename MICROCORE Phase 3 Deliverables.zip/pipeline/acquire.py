#!/usr/bin/env python3
"""MICROCORE Phase 3 acquisition layer.

Adds to the Phase 2 gate set:
  * file-level SPDX licence classification, so a permissive repository that
    vendors a GPL file does not silently poison the corpus;
  * streaming acquisition directly from a tar.gz response (no staging copy);
  * deterministic per-file manifest rows with SHA-256 for provenance;
  * dual-tokenizer counting (cl100k_base + GPT-2 BPE) on accepted files only.

Design rule: a file with no detectable licence is counted separately as
PENDING and never added to the eligible total.
"""
from __future__ import annotations
import hashlib, io, json, re, tarfile, time
from dataclasses import dataclass, field

PERMISSIVE = {
    "MIT", "MIT-0", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause", "BSD-4-Clause",
    "ISC", "0BSD", "Unlicense", "CC0-1.0", "PostgreSQL", "PSF-2.0", "Python-2.0",
    "X11", "Zlib", "BSL-1.0", "NCSA", "WTFPL", "CC-BY-4.0", "AML", "curl",
}
COPYLEFT = {"GPL-2.0", "GPL-2.0-only", "GPL-2.0-or-later", "GPL-3.0", "GPL-3.0-only",
            "GPL-3.0-or-later", "LGPL-2.1", "LGPL-3.0", "AGPL-3.0", "AGPL-3.0-only",
            "SSPL-1.0", "BUSL-1.1", "EUPL-1.2", "MPL-2.0", "CDDL-1.0", "EPL-2.0",
            "CC-BY-SA-4.0", "CC-BY-NC-4.0", "ODbL-1.0"}
EXT = {".c": "code", ".h": "code", ".cc": "code", ".cpp": "code", ".hpp": "code",
       ".py": "code", ".go": "code", ".rs": "code", ".java": "code", ".js": "code",
       ".ts": "code", ".tsx": "code", ".jsx": "code", ".rb": "code", ".php": "code",
       ".cs": "code", ".sh": "code", ".bash": "code", ".ps1": "code", ".sql": "code",
       ".asm": "code", ".s": "code", ".S": "code", ".lua": "code", ".kt": "code",
       ".swift": "code", ".scala": "code", ".pl": "code", ".pm": "code", ".m": "code",
       ".mm": "code", ".proto": "code", ".cmake": "code", ".mk": "code", ".dts": "code",
       ".md": "doc", ".rst": "doc", ".txt": "doc", ".adoc": "doc", ".tex": "doc",
       ".html": "doc", ".yaml": "config", ".yml": "config", ".toml": "config",
       ".json": "config", ".ini": "config", ".conf": "config", ".xml": "config",
       ".nix": "config", ".service": "config"}
SKIP_DIR = re.compile(r"(^|/)(\.git|vendor|third_party|third-party|3rdparty|node_modules|"
                      r"external|deps|bower_components|dist|build|generated|gen|"
                      r"__pycache__)(/|$)", re.I)
SKIP_FILE = re.compile(r"(_generated\.|\.generated\.|\.pb\.(go|cc|h)$|_pb2(_grpc)?\.py$|"
                       r"\.min\.(js|css)$|package-lock\.json$|yarn\.lock$|\.map$|\.svg$)", re.I)
SPDX = re.compile(r"SPDX-License-Identifier:\s*([A-Za-z0-9\.\-\+]+)")


class LicenceGateError(RuntimeError):
    pass


def classify(spdx: str | None) -> str:
    if not spdx:
        return "PENDING_REVIEW"
    base = spdx.split(" WITH ")[0].strip()
    if base in PERMISSIVE:
        return "VERIFIED_COMPATIBLE"
    if base in COPYLEFT:
        return "VERIFIED_RESTRICTED"
    return "UNCLEAR"


@dataclass
class Stats:
    files_seen: int = 0
    files_selected: int = 0
    files_excluded_path: int = 0
    files_excluded_ext: int = 0
    files_binary: int = 0
    files_too_big: int = 0
    bytes_eligible: int = 0
    bytes_restricted: int = 0
    cl100k_eligible: int = 0
    cl100k_restricted: int = 0
    cl100k_pending: int = 0
    gpt2_eligible: int = 0
    by_class: dict = field(default_factory=dict)
    by_category: dict = field(default_factory=dict)
    spdx_seen: dict = field(default_factory=dict)
    manifest: list = field(default_factory=list)

    def as_dict(self):
        d = {k: v for k, v in self.__dict__.items() if k != "manifest"}
        d["manifest_rows"] = len(self.manifest)
        return d


def _is_text(b: bytes) -> bool:
    if b"\x00" in b[:4096]:
        return False
    try:
        s = b.decode("utf-8")
    except UnicodeDecodeError:
        return False
    head = s[:4096]
    if not head:
        return False
    ok = sum(1 for c in head if c.isprintable() or c in "\n\r\t")
    return ok / len(head) > 0.92


def measure_tar(fileobj, enc, tok2=None, maxfile: int = 2_000_000,
                keep_manifest: bool = True, limit: int = 0,
                repo_class: str | None = None) -> Stats:
    """Stream a (possibly gzipped) tar and count tokens per licence class.

    repo_class: licence class of the enclosing repository, applied only to files
    with no SPDX header of their own (the normal case for prose docs). A file
    header always wins, so a vendored GPL file inside an MIT repo is excluded.
    """
    st = Stats()
    tf = tarfile.open(fileobj=fileobj, mode="r|gz")
    for m in tf:
        if not m.isfile():
            continue
        st.files_seen += 1
        name = m.name.split("/", 1)[-1]
        short = name.rsplit("/", 1)[-1]
        ext = "." + short.rsplit(".", 1)[-1] if "." in short else ""
        cat = EXT.get(ext)
        if cat is None:
            st.files_excluded_ext += 1
            continue
        if SKIP_DIR.search("/" + name) or SKIP_FILE.search(short):
            st.files_excluded_path += 1
            continue
        if m.size > maxfile:
            st.files_too_big += 1
            continue
        fh = tf.extractfile(m)
        if fh is None:
            continue
        b = fh.read()
        if not _is_text(b):
            st.files_binary += 1
            continue
        s = b.decode("utf-8")
        mm = SPDX.search(s[:4000])
        spdx = mm.group(1) if mm else None
        cls = classify(spdx) if spdx else (repo_class or "PENDING_REVIEW")
        st.spdx_seen[spdx or "none"] = st.spdx_seen.get(spdx or "none", 0) + 1
        n = len(enc.encode_ordinary(s))
        if cls == "VERIFIED_COMPATIBLE":
            st.files_selected += 1
            st.bytes_eligible += len(b)
            st.cl100k_eligible += n
            if tok2 is not None:
                st.gpt2_eligible += len(tok2.encode(s).ids)
            c = st.by_category.setdefault(cat, {"files": 0, "cl100k": 0})
            c["files"] += 1
            c["cl100k"] += n
            if keep_manifest:
                st.manifest.append({"path": name, "bytes": len(b), "cl100k": n,
                                    "spdx": spdx or "repo-default",
                                    "sha256": hashlib.sha256(b).hexdigest()})
        elif cls == "VERIFIED_RESTRICTED":
            st.bytes_restricted += len(b)
            st.cl100k_restricted += n
        else:
            st.cl100k_pending += n
        st.by_class[cls] = st.by_class.get(cls, 0) + 1
        if limit and st.files_selected >= limit:
            break
    return st


def require_eligible(licence_class: str) -> None:
    if licence_class != "LICENSE_VERIFIED_COMPATIBLE":
        raise LicenceGateError(f"refusing ingestion: licence class {licence_class}")


def write_manifest(st: Stats, path, meta: dict):
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(json.dumps({"type": "header", **meta,
                             "written": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}) + "\n")
        for row in st.manifest:
            fh.write(json.dumps({"type": "file", **row}) + "\n")
    return len(st.manifest)


def main(argv=None):
    import argparse, urllib.request
    import tiktoken
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--branch", default="master")
    ap.add_argument("--out", required=True)
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--gpt2", action="store_true")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--repo-licence", default=None, help="licence class inherited by files without an SPDX header")
    a = ap.parse_args(argv)
    url = f"https://codeload.github.com/{a.repo}/tar.gz/refs/heads/{a.branch}"
    enc = tiktoken.get_encoding("cl100k_base")
    tok2 = None
    if a.gpt2:
        from tokenizers import Tokenizer
        tok2 = Tokenizer.from_pretrained("gpt2")
    t0 = time.time()
    req = urllib.request.Request(url, headers={"User-Agent": "micore-audit"})
    with urllib.request.urlopen(req, timeout=120) as r:
        st = measure_tar(r, enc, tok2, limit=a.limit, repo_class=a.repo_licence)
    out = st.as_dict()
    out.update({"repo": a.repo, "branch": a.branch, "url": url,
                "elapsed_s": round(time.time() - t0, 1),
                "checked": time.strftime("%Y-%m-%d", time.gmtime())})
    json.dump(out, open(a.out, "w"), indent=1)
    if a.manifest:
        out["manifest_rows"] = write_manifest(st, a.manifest, {"repo": a.repo, "url": url})
    print(json.dumps(out, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
