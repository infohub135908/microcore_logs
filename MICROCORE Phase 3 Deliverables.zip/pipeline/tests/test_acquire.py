import io, json, os, sys, tarfile, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest, tiktoken
import acquire

ENC = tiktoken.get_encoding("cl100k_base")


def make_tar(files):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        for name, data in files.items():
            b = data if isinstance(data, bytes) else data.encode()
            ti = tarfile.TarInfo("repo-HEAD/" + name)
            ti.size = len(b)
            tf.addfile(ti, io.BytesIO(b))
    buf.seek(0)
    return buf


def test_classify_permissive():
    assert acquire.classify("MIT") == "VERIFIED_COMPATIBLE"
    assert acquire.classify("Apache-2.0") == "VERIFIED_COMPATIBLE"
    assert acquire.classify("BSD-3-Clause") == "VERIFIED_COMPATIBLE"


def test_classify_copyleft():
    assert acquire.classify("GPL-2.0-only") == "VERIFIED_RESTRICTED"
    assert acquire.classify("AGPL-3.0") == "VERIFIED_RESTRICTED"
    assert acquire.classify("BUSL-1.1") == "VERIFIED_RESTRICTED"


def test_classify_unknown_is_pending_not_compatible():
    assert acquire.classify(None) == "PENDING_REVIEW"
    assert acquire.classify("Proprietary-Thing") == "UNCLEAR"
    assert acquire.classify(None) != "VERIFIED_COMPATIBLE"


def test_vendor_and_generated_paths_excluded():
    buf = make_tar({"vendor/x.py": "// SPDX-License-Identifier: MIT\nprint(1)",
                    "src/y.py": "// SPDX-License-Identifier: MIT\nprint(2)",
                    "a/b.pb.go": "package x", "ok.c": "// SPDX-License-Identifier: MIT\nint main(){}"})
    st = acquire.measure_tar(buf, ENC)
    assert st.files_excluded_path == 2
    assert st.files_selected == 2


def test_binary_rejected():
    buf = make_tar({"blob.py": b"\x00\x01\x02", "x.py": "// SPDX-License-Identifier: MIT\nprint(1)"})
    st = acquire.measure_tar(buf, ENC)
    assert st.files_binary == 1
    assert st.files_selected == 1


def test_gpl_file_excluded_from_eligible_but_counted():
    buf = make_tar({"a.c": "// SPDX-License-Identifier: GPL-3.0\nint main(){}",
                    "b.c": "// SPDX-License-Identifier: MIT\nint main(){}"})
    st = acquire.measure_tar(buf, ENC)
    assert st.files_selected == 1
    assert st.cl100k_restricted > 0
    assert st.cl100k_eligible > 0
    assert st.by_class == {"VERIFIED_RESTRICTED": 1, "VERIFIED_COMPATIBLE": 1}


def test_missing_spdx_goes_to_pending():
    buf = make_tar({"a.py": "print('no header')"})
    st = acquire.measure_tar(buf, ENC)
    assert st.files_selected == 0
    assert st.cl100k_pending > 0


def test_manifest_hashes_stable():
    buf = make_tar({"a.py": "// SPDX-License-Identifier: MIT\nprint(1)"})
    s1 = acquire.measure_tar(buf, ENC)
    buf2 = make_tar({"a.py": "// SPDX-License-Identifier: MIT\nprint(1)"})
    s2 = acquire.measure_tar(buf2, ENC)
    assert s1.manifest[0]["sha256"] == s2.manifest[0]["sha256"]
    assert len(s1.manifest[0]["sha256"]) == 64


def test_limit_stops_early():
    files = {f"f{i}.py": "// SPDX-License-Identifier: MIT\nprint(1)" for i in range(20)}
    st = acquire.measure_tar(make_tar(files), ENC, limit=5)
    assert st.files_selected == 5


def test_require_eligible_rejects_restricted():
    with pytest.raises(acquire.LicenceGateError):
        acquire.require_eligible("LICENSE_VERIFIED_RESTRICTED")
    acquire.require_eligible("LICENSE_VERIFIED_COMPATIBLE")


def test_dual_tokenizers_differ():
    from tokenizers import Tokenizer
    t2 = Tokenizer.from_pretrained("gpt2")
    buf = make_tar({"a.py": "// SPDX-License-Identifier: MIT\n" + "def f(x): return x*2\n" * 50})
    st = acquire.measure_tar(buf, ENC, t2)
    assert st.cl100k_eligible > 0 and st.gpt2_eligible > 0
    assert st.cl100k_eligible != st.gpt2_eligible


def test_write_manifest_roundtrip(tmp_path):
    buf = make_tar({"a.py": "// SPDX-License-Identifier: MIT\nprint(1)"})
    st = acquire.measure_tar(buf, ENC)
    p = tmp_path / "m.jsonl"
    n = acquire.write_manifest(st, p, {"repo": "x"})
    rows = [json.loads(l) for l in p.read_text().splitlines()]
    assert n == 1 and rows[0]["type"] == "header" and rows[1]["type"] == "file"
