# Phase 3 discovery + measurement register (metadata only; tokens injected from data/*.json)
# tier: A=eligible & high value, B=conditional, C=low value, R=restricted, G=gated, X=rejected
R = []
def add(**kw): R.append(kw)

# ---------- measured code (Pillar B) ----------
add(id="MC-201", name="nginx source tree", pub="nginx.org / F5", url="https://github.com/nginx/nginx", dl="https://codeload.github.com/nginx/nginx/tar.gz/refs/heads/master",
    dom="Networking", sub="HTTP server / reverse proxy", fmt="C source, headers, docs",
    desc="Full nginx web-server and reverse-proxy source: HTTP/2, TLS, stream proxy, event loop, module ABI. Core artifact for understanding the server MICROCORE will most often assess.",
    lic="BSD-2-Clause", lv="2-Clause", licurl="https://github.com/nginx/nginx/blob/master/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=88, tier="A", comm="Permitted", attr="Retain copyright notice", cond="None", act="Ingest")
add(id="MC-202", name="FreeBSD src", pub="The FreeBSD Project", url="https://github.com/freebsd/freebsd-src", dl="https://codeload.github.com/freebsd/freebsd-src/tar.gz/refs/heads/main",
    dom="Operating systems", sub="BSD kernel, libc, userland, drivers", fmt="C/C++/asm source, man pages, configs",
    desc="Complete FreeBSD operating-system source: kernel (UFS/ZFS, netinet, CAM, MAC), libc, OpenSSH/OpenSSL forks, jails, bhyve, pf, auditd, 9k+ man pages. The largest permissively licensed OS codebase measured in this phase.",
    lic="BSD-2-Clause", lv="2-Clause", licurl="https://github.com/freebsd/freebsd-src/blob/main/COPYRIGHT", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=96, tier="A", comm="Permitted", attr="Retain copyright notice", cond="Exclude per-file GPL/other-licence headers (measured)", act="Ingest")
add(id="MC-203", name="LLVM project", pub="LLVM Foundation", url="https://github.com/llvm/llvm-project", dl="https://codeload.github.com/llvm/llvm-project/tar.gz/refs/heads/main",
    dom="Compilers / RE", sub="Compiler, disassembler, debugger, sanitizers", fmt="C++ source, TableGen, docs",
    desc="Clang, LLVM IR, MC disassembler, lldb, compiler-rt sanitizers, libFuzzer. Teaches instruction selection, object formats and the disassembly semantics used by reverse-engineering tooling.",
    lic="Apache-2.0 WITH LLVM-exception", lv="2.0", licurl="https://github.com/llvm/llvm-project/blob/main/LICENSE.TXT", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=93, tier="A", comm="Permitted", attr="NOTICE file", cond="Exclude generated .inc/.td output via path filter", act="Ingest")
add(id="MC-204", name="rust-lang/rust", pub="Rust Project", url="https://github.com/rust-lang/rust", dl="https://codeload.github.com/rust-lang/rust/tar.gz/refs/heads/main",
    dom="Programming languages", sub="Compiler, std, borrow checker", fmt="Rust source, docs",
    desc="rustc, standard library, MIR/borrowck, LLVM bindings. Memory-safety reasoning is directly relevant to vulnerability classes MICROCORE must recognise.",
    lic="MIT OR Apache-2.0", lv="2.0", licurl="https://github.com/rust-lang/rust/blob/main/LICENSE-APACHE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=86, tier="A", comm="Permitted", attr="Retain notices", cond="Exclude vendored submodules", act="Ingest")
add(id="MC-205", name="kubernetes/kubernetes", pub="CNCF", url="https://github.com/kubernetes/kubernetes", dl="https://codeload.github.com/kubernetes/kubernetes/tar.gz/refs/heads/master",
    dom="Containers / Cloud", sub="Orchestrator, apiserver, kubelet, RBAC", fmt="Go source, YAML, docs",
    desc="Control plane and node agent source: authentication, authorization (RBAC/ABAC), admission control, pod security, network policy, CSI/CNI interfaces.",
    lic="Apache-2.0", lv="2.0", licurl="https://github.com/kubernetes/kubernetes/blob/master/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=91, tier="A", comm="Permitted", attr="NOTICE", cond="Exclude vendor/ (measured)", act="Ingest")
add(id="MC-206", name="Go standard library and toolchain", pub="Google / Go project", url="https://github.com/golang/go", dl="https://codeload.github.com/golang/go/tar.gz/refs/heads/master",
    dom="Programming languages", sub="Runtime, net stack, crypto, toolchain", fmt="Go source, asm, docs",
    desc="Go runtime and stdlib including net/http, crypto/tls, x509, syscall, debug/elf, debug/pe, archive/tar. Binary-format and TLS parsing code with direct DFIR relevance.",
    lic="BSD-3-Clause", lv="3-Clause", licurl="https://github.com/golang/go/blob/master/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=89, tier="A", comm="Permitted", attr="Retain notice", cond="None", act="Ingest")
add(id="MC-207", name="CPython", pub="Python Software Foundation", url="https://github.com/python/cpython", dl="https://codeload.github.com/python/cpython/tar.gz/refs/heads/main",
    dom="Programming languages", sub="Interpreter, stdlib, C extensions", fmt="C, Python, docs",
    desc="Interpreter internals, memory allocator, GIL, ssl/socket/subprocess modules, import machinery. Foundation for interpreting attacker tooling written in Python.",
    lic="PSF-2.0", lv="2.0", licurl="https://github.com/python/cpython/blob/main/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=84, tier="A", comm="Permitted", attr="PSF notice", cond="None", act="Ingest")
add(id="MC-208", name="PostgreSQL", pub="PostgreSQL Global Development Group", url="https://github.com/postgres/postgres", dl="https://codeload.github.com/postgres/postgres/tar.gz/refs/heads/master",
    dom="Databases", sub="RDBMS internals, auth, SQL", fmt="C source, SQL, docs",
    desc="Query planner, WAL, MVCC, pg_hba authentication, role/privilege model, PL/pgSQL. Database attack surface and forensic artefact semantics.",
    lic="PostgreSQL", lv="n/a", licurl="https://github.com/postgres/postgres/blob/master/COPYRIGHT", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=83, tier="A", comm="Permitted", attr="Copyright notice", cond="None", act="Ingest")
add(id="MC-209", name="OpenSSL", pub="OpenSSL Foundation", url="https://github.com/openssl/openssl", dl="https://codeload.github.com/openssl/openssl/tar.gz/refs/heads/master",
    dom="Cryptography", sub="TLS, X.509, crypto primitives", fmt="C source, docs, test vectors",
    desc="TLS state machine, certificate path validation, ASN.1 parsing, provider architecture. The reference implementation for the handshake and certificate failures MICROCORE must diagnose.",
    lic="Apache-2.0", lv="2.0", licurl="https://github.com/openssl/openssl/blob/master/LICENSE.txt", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=87, tier="A", comm="Permitted", attr="NOTICE", cond="None", act="Ingest")
add(id="MC-210", name="Moby / Docker Engine", pub="Moby Project", url="https://github.com/moby/moby", dl="https://codeload.github.com/moby/moby/tar.gz/refs/heads/master",
    dom="Containers", sub="Container runtime, image format, namespaces", fmt="Go source, docs",
    desc="Daemon, containerd integration, capability dropping, seccomp/AppArmor profiles, image layer handling. Container escape and misconfiguration analysis.",
    lic="Apache-2.0", lv="2.0", licurl="https://github.com/moby/moby/blob/master/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=85, tier="A", comm="Permitted", attr="NOTICE", cond="Exclude vendor/", act="Ingest")
add(id="MC-211", name="dotnet/runtime", pub="Microsoft / .NET Foundation", url="https://github.com/dotnet/runtime", dl="https://codeload.github.com/dotnet/runtime/tar.gz/refs/heads/main",
    dom="Programming languages", sub="CLR, BCL, crypto, networking", fmt="C#, C++, IL, docs",
    desc=".NET runtime, JIT, GC, System.Security.Cryptography, System.Net, P/Invoke interop. Windows-centric managed-code behaviour and .NET assembly semantics.",
    lic="MIT", lv="MIT", licurl="https://github.com/dotnet/runtime/blob/main/LICENSE.TXT", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=82, tier="A", comm="Permitted", attr="Retain notice", cond="Exclude src/tests native externals", act="Ingest")
add(id="MC-212", name="curl", pub="Daniel Stenberg / curl project", url="https://github.com/curl/curl", dl="https://codeload.github.com/curl/curl/tar.gz/refs/heads/master",
    dom="Networking", sub="HTTP, FTP, TLS client, protocol parsing", fmt="C source, docs, tests",
    desc="URL parsing, HTTP/2/3, proxy handling, authentication schemes, libcurl API. Every web-API assessment depends on this request semantics.",
    lic="curl", lv="n/a", licurl="https://github.com/curl/curl/blob/master/COPYING", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=86, tier="A", comm="Permitted", attr="Copyright notice", cond="None", act="Ingest")
add(id="MC-213", name="Apache httpd", pub="Apache Software Foundation", url="https://github.com/apache/httpd", dl="https://codeload.github.com/apache/httpd/tar.gz/refs/heads/trunk",
    dom="Networking", sub="HTTP server, modules, .htaccess", fmt="C source, docs",
    desc="Request processing, module hooks, access control (.htaccess/Require), mod_ssl, mod_proxy. Classic web-server misconfiguration surface.",
    lic="Apache-2.0", lv="2.0", licurl="https://github.com/apache/httpd/blob/trunk/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=84, tier="A", comm="Permitted", attr="NOTICE", cond="None", act="Ingest")
add(id="MC-214", name="OpenSSH portable", pub="OpenBSD project", url="https://github.com/openssh/openssh-portable", dl="https://codeload.github.com/openssh/openssh-portable/tar.gz/refs/heads/master",
    dom="Networking / Identity", sub="SSH protocol, key exchange, auth", fmt="C source, docs",
    desc="sshd privilege separation, authorized_keys semantics, PAM integration, agent forwarding, key types. Core artefact for lateral-movement and credential analysis.",
    lic="BSD (multi-variant, all permissive)", lv="n/a", licurl="https://github.com/openssh/openssh-portable/blob/master/LICENCE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=88, tier="A", comm="Permitted", attr="Retain notices", cond="File-level licence variants verified permissive in LICENCE", act="Ingest")
add(id="MC-215", name="Node.js", pub="OpenJS Foundation", url="https://github.com/nodejs/node", dl="https://codeload.github.com/nodejs/node/tar.gz/refs/heads/main",
    dom="Programming languages", sub="JS runtime, libuv, npm ecosystem", fmt="C++, JS, docs",
    desc="V8 embedding, libuv event loop, permission model, child_process, crypto, HTTP stack. Basis for analysing npm-based malicious packages.",
    lic="MIT", lv="MIT", licurl="https://github.com/nodejs/node/blob/main/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=80, tier="A", comm="Permitted", attr="Retain notice", cond="Exclude deps/ (bundled third-party, measured)", act="Ingest")

# ---------- measured documentation (Pillar C) ----------
add(id="MC-216", name=".NET documentation", pub="Microsoft", url="https://github.com/dotnet/docs", dl="https://codeload.github.com/dotnet/docs/tar.gz/refs/heads/main",
    dom="Documentation", sub=".NET, C#, ASP.NET Core, security APIs", fmt="Markdown",
    desc="Conceptual and API documentation for .NET: cryptography APIs, authentication, serialization, diagnostics, container images.",
    lic="CC-BY-4.0", lv="4.0", licurl="https://github.com/dotnet/docs/blob/main/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=79, tier="A", comm="Permitted", attr="Attribution", cond="None", act="Ingest")
add(id="MC-217", name="SQL Server documentation", pub="Microsoft", url="https://github.com/MicrosoftDocs/sql-docs", dl="https://codeload.github.com/MicrosoftDocs/sql-docs/tar.gz/refs/heads/live",
    dom="Documentation", sub="SQL Server, T-SQL, security model", fmt="Markdown",
    desc="T-SQL reference, logins/roles/permissions, encryption (TDE, Always Encrypted), auditing, error codes. Large, highly structured DB-admin corpus.",
    lic="CC-BY-4.0", lv="4.0", licurl="https://github.com/MicrosoftDocs/sql-docs/blob/live/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=81, tier="A", comm="Permitted", attr="Attribution", cond="None", act="Ingest")
add(id="MC-218", name="Win32 API documentation", pub="Microsoft", url="https://github.com/MicrosoftDocs/win32", dl="https://codeload.github.com/MicrosoftDocs/win32/tar.gz/refs/heads/docs",
    dom="Documentation", sub="Windows API, kernel objects, security descriptors", fmt="Markdown",
    desc="Win32 API reference: process/thread, memory, handles, registry, services, ACLs and security descriptors, COM. The single most valuable Windows-internals text source measured in this phase.",
    lic="CC-BY-4.0", lv="4.0", licurl="https://github.com/MicrosoftDocs/win32/blob/docs/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=90, tier="A", comm="Permitted", attr="Attribution", cond="None", act="Ingest")
add(id="MC-219", name="Windows driver documentation", pub="Microsoft", url="https://github.com/MicrosoftDocs/windows-driver-docs", dl="https://codeload.github.com/MicrosoftDocs/windows-driver-docs/tar.gz/refs/heads/staging",
    dom="Documentation", sub="Kernel drivers, DMA, IOCTL, WDF", fmt="Markdown",
    desc="Driver development and kernel interfaces: IRP/IOCTL handling, memory mapping, DMA, kernel security guidance, driver signing. Supports exploit-primitive and firmware reasoning.",
    lic="CC-BY-4.0", lv="4.0", licurl="https://github.com/MicrosoftDocs/windows-driver-docs/blob/staging/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=86, tier="A", comm="Permitted", attr="Attribution", cond="None", act="Ingest")
add(id="MC-220", name="Visual Studio documentation", pub="Microsoft", url="https://github.com/MicrosoftDocs/visualstudio-docs", dl="https://codeload.github.com/MicrosoftDocs/visualstudio-docs/tar.gz/refs/heads/main",
    dom="Documentation", sub="IDE, debugging, build systems", fmt="Markdown",
    desc="Debugger usage, breakpoints, dump analysis, diagnostics tools, MSBuild. Debugging workflow text for Windows targets.",
    lic="CC-BY-4.0", lv="4.0", licurl="https://github.com/MicrosoftDocs/visualstudio-docs/blob/main/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=72, tier="B", comm="Permitted", attr="Attribution", cond="IDE-centric; cap contribution", act="Ingest with cap")

# ---------- security (Pillar A) ----------
add(id="MC-222", name="Nuclei templates", pub="ProjectDiscovery", url="https://github.com/projectdiscovery/nuclei-templates", dl="https://codeload.github.com/projectdiscovery/nuclei-templates/tar.gz/refs/heads/main",
    dom="Vulnerability discovery", sub="Template-based detection checks", fmt="YAML templates",
    desc="14,821 YAML templates encoding CVE checks, default-login tests, misconfiguration probes, exposed-panel detection and multi-step exploit flows. Practical offensive knowledge in machine-readable form.",
    lic="MIT", lv="MIT", licurl="https://github.com/projectdiscovery/nuclei-templates/blob/main/LICENSE.md", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=92, tier="A", comm="Permitted", attr="Retain notice", cond="Templates may embed third-party CVE text; attribution retained", act="Ingest")
add(id="MC-223", name="PayloadsAllTheThings", pub="Swissky", url="https://github.com/swisskyrepo/PayloadsAllTheThings", dl="https://codeload.github.com/swisskyrepo/PayloadsAllTheThings/tar.gz/refs/heads/master",
    dom="Offensive security", sub="Exploitation methodology, payload catalogues", fmt="Markdown",
    desc="Methodology notes per vulnerability class: SQLi, XSS, SSTI, SSRF, LDAP, command injection, file upload, deserialization, with concrete payload syntax and bypass notes.",
    lic="MIT", lv="MIT", licurl="https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=90, tier="A", comm="Permitted", attr="Retain notice", cond="Payload-heavy; scan for embedded real credentials", act="Ingest")
add(id="MC-224", name="GitHub Advisory Database", pub="GitHub", url="https://github.com/github/advisory-database", dl="https://codeload.github.com/github/advisory-database/tar.gz/refs/heads/main",
    dom="Vulnerability intelligence", sub="Package advisories (OSV format)", fmt="JSON (OSV schema)",
    desc="Curated security advisories for npm, PyPI, Go, Maven, NuGet, RubyGems, Rust and GitHub Actions, with affected version ranges, CWE and CVSS. Machine-readable vulnerability-to-package mapping.",
    lic="CC-BY-4.0", lv="4.0", licurl="https://github.com/github/advisory-database/blob/main/LICENSE.md", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=89, tier="A", comm="Permitted", attr="Attribution", cond="JSON serialisation overhead; normalise to records", act="Ingest after normalisation")

# ---------- telemetry (Pillar D) ----------
add(id="MC-221", name="NGIDS-DS host logs (ADFA-IDS)", pub="UNSW Canberra / Australian Centre for Cyber Security", url="https://doi.org/10.7910/DVN/IFTZPF", dl="https://dataverse.harvard.edu/api/access/datafile/8083462",
    dom="Host telemetry", sub="Linux auditd-style process/syscall logs with attack labels", fmt="CSV in ZIP",
    desc="99 CSV files of labelled host events (date, time, pid, process path, syscall id, event id, attack category, label) from a controlled intrusion-detection testbed, plus NGIDS netflow and ADFA-LD/ADFA-WD memory and Windows stealth-attack sets.",
    lic="CC0-1.0", lv="1.0", licurl="https://creativecommons.org/publicdomain/zero/1.0/", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=61, tier="B", comm="Permitted", attr="None (CC0)", cond="Row-level records are 99.94% redundant; must aggregate to sessions and cap", act="Ingest aggregated only")

# ---------- discovery-only / conditional ----------
add(id="MC-227", name="The Stack v2", pub="BigCode / Software Heritage / INRIA", url="https://huggingface.co/datasets/bigcode/the-stack-v2", dl="gated: SWH+INRIA agreement required",
    dom="Source code (all languages)", sub="3.28B files, 658 languages", fmt="Parquet metadata + SWH blob ids",
    desc="67.53 TB uncompressed of licence-annotated source code; per-file ScanCode detected_licenses and permissive/no_license classification. Bulk content access requires an agreement with Software Heritage and INRIA.",
    lic="per-file detected licences (mixed)", lv="mixed", licurl="https://huggingface.co/datasets/bigcode/the-stack-v2", cls="LICENSE_COMPATIBLE_PENDING_REVIEW",
    acc="GATED_OR_AUTHENTICATION_REQUIRED", level="Level 3", score=95, tier="B", comm="Depends on per-file licence", attr="Per-file attribution", cond="Bulk access requires signed SWH/INRIA agreement; training must follow SWH principles; per-file licence filter mandatory", act="Obtain agreement; filter permissively licensed subset")
add(id="MC-228", name="Software Heritage archive", pub="Software Heritage (INRIA/UNESCO)", url="https://archive.softwareheritage.org", dl="API + graph dataset (gated for bulk)",
    dom="Source code (all languages)", sub="29B unique files, 441M projects", fmt="Merkle graph, SWHIDs, blob API",
    desc="The largest public source-code archive; content-addressed so deduplication is intrinsic. Bulk graph access is offered as a compressed research dataset under agreement.",
    lic="mixed per origin", lv="mixed", licurl="https://www.softwareheritage.org/legal/", cls="LICENSE_COMPATIBLE_PENDING_REVIEW",
    acc="GATED_OR_AUTHENTICATION_REQUIRED", level="Level 3", score=93, tier="B", comm="Depends on origin licence", attr="Per-origin", cond="No licence filter at archive level; requires per-origin/per-file licence resolution", act="Use as provenance layer, not as blanket corpus")
add(id="MC-225", name="CISA Vulnrichment", pub="CISA", url="https://github.com/cisagov/vulnrichment", dl="https://codeload.github.com/cisagov/vulnrichment/tar.gz/refs/heads/develop",
    dom="Vulnerability intelligence", sub="CVE enrichment (SSVC, CVSS, CWE)", fmt="JSON",
    desc="CISA-authored enrichment of CVE records: decision points, exploitation status, technical impact, missing CWE/CVSS backfill. Complements NVD without duplicating its descriptions.",
    lic="CC0-1.0", lv="1.0", licurl="https://github.com/cisagov/vulnrichment/blob/develop/LICENSE", cls="LICENSE_VERIFIED_COMPATIBLE",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=78, tier="A", comm="Permitted", attr="None", cond="Overlaps NVD CVE identifiers; count enrichment fields only", act="Ingest as enrichment records")

add(id="MC-229", name="NIST Technical Series (SP 800, FIPS, NISTIR)", pub="NIST", url="https://www.nist.gov/nist-research-library/nist-publications", dl="https://nvlpubs.nist.gov/",
    dom="Standards / security engineering", sub="SP 800 controls, crypto standards, guidance", fmt="PDF",
    desc="Security control catalogues (SP 800-53), risk assessment, cryptography (FIPS 140-3, SP 800-38/57), zero trust, supply chain. Public domain in the US with foreign rights reserved.",
    lic="US Government work (public domain, 17 USC 105)", lv="n/a", licurl="https://www.nist.gov/copyrights-disclaimers", cls="LICENSE_COMPATIBLE_PENDING_REVIEW",
    acc="VERIFIED_ACCESSIBLE", level="Level 3", score=88, tier="A", comm="Permitted in US; foreign rights reserved", attr="Courtesy citation requested", cond="Some documents contain third-party copyrighted material; per-document check required", act="Acquire SP 800 + FIPS corpus; PDF text extraction")
add(id="MC-230", name="arXiv computing/security corpus", pub="arXiv / Cornell LIS", url="https://arxiv.org", dl="https://info.arxiv.org/help/bulk_data.html",
    dom="Research", sub="cs.CR, cs.SE, cs.NI, cs.OS preprints", fmt="PDF/LaTeX + metadata",
    desc="Open-access preprints with per-article licences; metadata is CC0, full text licence varies (CC BY, CC BY-SA, arXiv-exclusive). LaTeX sources give clean text.",
    lic="per-article", lv="mixed", licurl="https://info.arxiv.org/help/license/index.html", cls="LICENSE_COMPATIBLE_PENDING_REVIEW",
    acc="VERIFIED_ACCESSIBLE", level="Level 2", score=82, tier="B", comm="Only CC-BY/CC0 subset", attr="Per-article", cond="Filter to CC-BY/CC0 articles only; arXiv-exclusive licence forbids reuse", act="Filter by licence metadata")
add(id="MC-231", name="Debian source archive", pub="Debian Project", url="https://sources.debian.org", dl="https://snapshot.debian.org/",
    dom="Source code (distro)", sub="70k+ source packages, machine-readable copyright", fmt="tar + debian/copyright",
    desc="Complete distribution source with per-package debian/copyright (DEP-5) enabling file-level licence classification; includes security tooling (nmap, metasploit deps, wireshark, radare2 forks).",
    lic="per-package DFSG", lv="mixed", licurl="https://www.debian.org/legal/licenses/", cls="LICENSE_COMPATIBLE_PENDING_REVIEW",
    acc="VERIFIED_ACCESSIBLE", level="Level 2", score=85, tier="B", comm="Per-package", attr="Per-package", cond="Requires DEP-5 parsing; GPL packages excluded", act="Build DEP-5 filtered subset")
add(id="MC-232", name="Linux kernel", pub="Linux Foundation / kernel.org", url="https://github.com/torvalds/linux", dl="https://cdn.kernel.org/pub/linux/kernel/",
    dom="Operating systems", sub="Kernel, drivers, subsystems", fmt="C source, docs",
    desc="The reference Linux kernel: syscall table, netfilter, SELinux/AppArmor, seccomp, eBPF, io_uring, 20k+ drivers. Largest single body of systems code in existence.",
    lic="GPL-2.0 WITH Linux-syscall-note", lv="2.0", licurl="https://github.com/torvalds/linux/blob/master/COPYING", cls="LICENSE_VERIFIED_RESTRICTED",
    acc="VERIFIED_ACCESSIBLE", level="Level 5", score=95, tier="R", comm="Copyleft: redistribution of derived corpus triggers GPL", attr="GPL notice", cond="Excluded from eligible totals until legal review of model-output obligations", act="Hold; legal review")
add(id="MC-233", name="MIT OpenCourseWare", pub="MIT", url="https://ocw.mit.edu", dl="https://ocw.mit.edu/terms/",
    dom="Education", sub="6.0xx/6.8xx systems, algorithms, security courses", fmt="PDF, HTML, video transcripts",
    desc="Course notes and lecture transcripts for operating systems, distributed systems, cryptography and computer architecture.",
    lic="CC-BY-NC-SA-4.0", lv="4.0", licurl="https://ocw.mit.edu/terms/", cls="LICENSE_VERIFIED_RESTRICTED",
    acc="VERIFIED_ACCESSIBLE", level="Level 3", score=76, tier="R", comm="Non-commercial only", attr="Attribution + share-alike", cond="NC clause incompatible with commercial deployment", act="Exclude unless non-commercial scope confirmed")
add(id="MC-234", name="GH Archive", pub="GH Archive / Internet Archive", url="https://www.gharchive.org", dl="https://data.gharchive.org/",
    dom="Repository metadata", sub="Public GitHub event stream", fmt="JSON.gz hourly",
    desc="Every public GitHub event since 2011: pushes, pull requests, issues, releases. Metadata only — no file contents; useful for repository popularity, licence and provenance signals, not for tokens.",
    lic="GitHub public event data (no explicit licence)", lv="n/a", licurl="https://www.gharchive.org/", cls="LICENSE_UNCLEAR",
    acc="VERIFIED_ACCESSIBLE", level="Level 2", score=45, tier="C", comm="Unclear", attr="n/a", cond="Metadata not training text; no explicit reuse grant", act="Use only as selection signal")
add(id="MC-235", name="Metasploit Framework", pub="Rapid7", url="https://github.com/rapid7/metasploit-framework", dl="https://codeload.github.com/rapid7/metasploit-framework/tar.gz/refs/heads/master",
    dom="Offensive tooling", sub="Exploit modules, payloads, auxiliary scanners", fmt="Ruby, Python, C",
    desc="2,000+ exploit and auxiliary modules with real target/version logic, payload encoders and post-exploitation modules. The densest body of practical exploitation code available.",
    lic="BSD-3-Clause (mixed per-file; Debian copyright format)", lv="3-Clause", licurl="https://github.com/rapid7/metasploit-framework/blob/master/LICENSE", cls="LICENSE_COMPATIBLE_PENDING_REVIEW",
    acc="VERIFIED_ACCESSIBLE", level="Level 4 (streamed and classified; not tokenized for inclusion)", score=94, tier="B", comm="Likely permitted; per-file review needed", attr="Retain notices", cond="Mixed per-file licences; some modules vendor third-party code", act="File-level licence audit then ingest")
