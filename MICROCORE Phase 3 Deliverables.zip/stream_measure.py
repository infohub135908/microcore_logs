#!/usr/bin/env python3
"""Stream a GitHub tarball, apply file-level licence/quality filters, tokenize in memory."""
import argparse, io, json, re, sys, tarfile, time, urllib.request, hashlib
import tiktoken

EXT = {
 # code
 ".c":"code",".h":"code",".cc":"code",".cpp":"code",".cxx":"code",".hpp":"code",".hh":"code",".hxx":"code",
 ".py":"code",".go":"code",".rs":"code",".java":"code",".js":"code",".mjs":"code",".cjs":"code",".ts":"code",
 ".tsx":"code",".jsx":"code",".rb":"code",".pl":"code",".pm":"code",".php":"code",".cs":"code",".fs":"code",
 ".m":"code",".mm":"code",".s":"code",".S":"code",".asm":"code",".lua":"code",".kt":"code",".swift":"code",
 ".zig":"code",".nim":"code",".hs":"code",".ml":"code",".mli":"code",".scala":"code",".clj":"code",".ex":"code",
 ".exs":"code",".erl":"code",".hrl":"code",".vim":"code",".el":"code",".awk":"code",".sed":"code",".ps1":"code",
 ".psm1":"code",".bat":"code",".cmd":"code",".sh":"code",".bash":"code",".zsh":"code",".fish":"code",".sql":"code",
 ".proto":"code",".thrift":"code",".ld":"code",".lds":"code",".dts":"code",".dtsi":"code",".v":"code",".sv":"code",
 ".vhd":"code",".vhdl":"code",".f":"code",".f90":"code",".f95":"code",".for":"code",".pas":"code",".d":"code",
 ".r":"code",".jl":"code",".tcl":"code",".groovy":"code",".gradle":"code",".cmake":"code",".mk":"code",
 ".mak":"code",".am":"code",".in":"code",".m4":"code",".ac":"code",".y":"code",".l":"code",".g4":"code",
 # docs
 ".md":"doc",".rst":"doc",".txt":"doc",".adoc":"doc",".asciidoc":"doc",".man":"doc",".1":"doc",".3":"doc",
 ".5":"doc",".8":"doc",".tex":"doc",".pod":"doc",".rdoc":"doc",
 # config / structured
 ".yaml":"config",".yml":"config",".toml":"config",".ini":"config",".cfg":"config",".conf":"config",
 ".json":"config",".xml":"config",".properties":"config",".service":"config",".env":"config",".nix":"config",
 # headers/templates
 ".html":"doc",".htm":"doc",".css":"doc",
}
SKIP_DIR = re.compile(r"(^|/)(\.git|vendor|third_party|third-party|3rdparty|node_modules|external|extern|deps|"
                      r"contrib/vendor|bower_components|dist|build|generated|gen|__pycache__|\.venv|site-packages)(/|$)", re.I)
SKIP_FILE = re.compile(r"(_generated\.|\.generated\.|\.pb\.go$|\.pb\.cc$|\.pb\.h$|_pb2\.py$|_pb2_grpc\.py$|"
                       r"\.min\.js$|\.min\.css$|package-lock\.json$|yarn\.lock$|\.map$|\.svg$|\.csv$|\.tsv$|"
                       r"\.ipynb_checkpoints|\.pem$|\.crt$|\.key$)", re.I)
SPDX = re.compile(r"SPDX-License-Identifier:\s*([A-Za-z0-9\.\-\+ ]+)")
BAD_LIC = re.compile(r"GPL|AGPL|SSPL|BUSL|CC-BY-NC|Commons-Clause", re.I)

def ok_text(b):
    if b"\x00" in b[:4096]: return False
    try: s=b.decode("utf-8")
    except UnicodeDecodeError: return False
    if not s: return False
    printable=sum(1 for c in s[:4096] if c.isprintable() or c in "\n\r\t")
    return printable/max(1,len(s[:4096]))>0.92

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",required=True); ap.add_argument("--branch",default="master")
    ap.add_argument("--id",required=True); ap.add_argument("--maxfile",type=int,default=2_000_000)
    ap.add_argument("--gpt2",action="store_true"); ap.add_argument("--limit",type=int,default=0)
    ap.add_argument("--out",required=True)
    a=ap.parse_args()
    url=f"https://codeload.github.com/{a.repo}/tar.gz/refs/heads/{a.branch}"
    enc=tiktoken.get_encoding("cl100k_base")
    tok2=None
    if a.gpt2:
        from tokenizers import Tokenizer
        tok2=Tokenizer.from_pretrained("gpt2")
    agg={"id":a.id,"repo":a.repo,"branch":a.branch,"url":url,"started":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}
    files_seen=files_sel=files_bin=files_big=files_badlic=files_skip=0
    bytes_sel=0; cl=0; g2=0; by_cat={}; by_ext={}; lic_hits={}; sample=[]; t0=time.time()
    req=urllib.request.Request(url,headers={"User-Agent":"audit"})
    with urllib.request.urlopen(req,timeout=120) as resp:
        tf=tarfile.open(fileobj=resp,mode="r|gz")
        for m in tf:
            if not m.isfile(): continue
            files_seen+=1
            name=m.name.split("/",1)[-1]
            ext="."+name.rsplit(".",1)[-1] if "." in name.rsplit("/",1)[-1] else ""
            cat=EXT.get(ext)
            if cat is None: files_skip+=1; continue
            if SKIP_DIR.search("/"+name) or SKIP_FILE.search(name): files_skip+=1; continue
            if m.size>a.maxfile: files_big+=1; continue
            f=tf.extractfile(m)
            if f is None: continue
            b=f.read()
            if not ok_text(b): files_bin+=1; continue
            s=b.decode("utf-8")
            lic=None
            mm=SPDX.search(s[:4000])
            if mm:
                lic=mm.group(1).strip()
                if BAD_LIC.search(lic):
                    files_badlic+=1; lic_hits[lic]=lic_hits.get(lic,0)+1
                    continue
                lic_hits[lic]=lic_hits.get(lic,0)+1
            n=len(enc.encode_ordinary(s))
            files_sel+=1; bytes_sel+=len(b); cl+=n
            c=by_cat.setdefault(cat,{"files":0,"bytes":0,"cl100k":0}); c["files"]+=1;c["bytes"]+=len(b);c["cl100k"]+=n
            e=by_ext.setdefault(ext,{"files":0,"bytes":0,"cl100k":0}); e["files"]+=1;e["bytes"]+=len(b);e["cl100k"]+=n
            if tok2 is not None:
                g2+=len(tok2.encode(s).ids); c["gpt2"]=c.get("gpt2",0)+0
            if len(sample)<40: sample.append({"path":name,"bytes":len(b),"cl100k":n,"spdx":lic})
            if files_sel%500==0: print(f"  {files_sel} files {bytes_sel/1e6:.1f}MB {cl/1e6:.1f}M tok {time.time()-t0:.0f}s",flush=True)
            if a.limit and files_sel>=a.limit: break
    agg.update({"files_seen":files_seen,"files_selected":files_sel,"files_skipped":files_skip,
        "files_binary":files_bin,"files_too_big":files_big,"files_bad_spdx":files_badlic,
        "bytes_selected":bytes_sel,"cl100k":cl,"gpt2":g2,"by_category":by_cat,"by_ext":{k:v for k,v in sorted(by_ext.items(),key=lambda x:-x[1]["cl100k"])[:15]},
        "spdx_hits":dict(sorted(lic_hits.items(),key=lambda x:-x[1])[:12]),"sample":sample,
        "elapsed_s":round(time.time()-t0,1),"finished":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())})
    json.dump(agg,open(a.out,"w"),indent=1)
    print(json.dumps({k:agg[k] for k in ("id","repo","files_seen","files_selected","files_bad_spdx","bytes_selected","cl100k","gpt2","elapsed_s")},indent=1))
if __name__=="__main__": main()
