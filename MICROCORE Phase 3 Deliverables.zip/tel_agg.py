import argparse,json,zipfile,csv,io,time,collections
import tiktoken
ap=argparse.ArgumentParser(); ap.add_argument("--zip",required=True); ap.add_argument("--files",type=int,default=3)
ap.add_argument("--id",required=True); ap.add_argument("--out",required=True); a=ap.parse_args()
enc=tiktoken.get_encoding("cl100k_base"); z=zipfile.ZipFile(a.zip)
names=[n for n in z.namelist() if n.endswith(".csv") and "host logs" in n][:a.files]
tok=0; sessions=0; uniq=set(); utok=0; rows=0; t0=time.time()
for n in names:
    seqs=collections.OrderedDict()
    with z.open(n) as fh:
        for row in csv.reader(io.TextIOWrapper(fh,encoding="utf-8",errors="replace")):
            if len(row)<9: continue
            date,t,pid,path,sc,ev,cat,sub,lab=row[:9]
            key=(pid,path,date)
            s=seqs.get(key)
            if s is None: seqs[key]=[sc,[cat],lab]
            else:
                s[0]+=","+sc
                if s[1][-1]!=cat: s[1].append(cat)
            rows+=1
    for (pid,path,date),(sc,cats,lab) in seqs.items():
        line=f"session date={date} pid={pid} process={path} categories={'|'.join(cats[:8])} label={lab} syscalls={sc[:4000]}"
        if (path,sc[:4000],lab) in uniq: continue
        uniq.add((path,sc[:4000],lab)); utok+=len(enc.encode_ordinary(line)); sessions+=1
    print(n,rows,sessions,utok,round(time.time()-t0,1),flush=True)
out={"id":a.id,"source":"doi:10.7910/DVN/IFTZPF NGIDS-DS","files_sampled":len(names),"rows_in":rows,
 "unique_sessions":sessions,"cl100k_unique":utok,"tokens_per_session":round(utok/max(1,sessions),1),
 "elapsed_s":round(time.time()-t0,1),"transform":"per-process syscall sequence aggregation, exact-dedup on (process,seq,label)"}
json.dump(out,open(a.out,"w"),indent=1); print(json.dumps(out,indent=1))
