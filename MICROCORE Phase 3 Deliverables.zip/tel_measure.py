import argparse,json,zipfile,csv,io,sys,time
import tiktoken
ap=argparse.ArgumentParser(); ap.add_argument("--zip",required=True); ap.add_argument("--files",type=int,default=2)
ap.add_argument("--id",required=True); ap.add_argument("--out",required=True); a=ap.parse_args()
enc=tiktoken.get_encoding("cl100k_base")
z=zipfile.ZipFile(a.zip)
names=[n for n in z.namelist() if n.endswith(".csv") and "host logs" in n][:a.files]
tok=0; rows=0; uniq=set(); cats={}; bytes_in=0; t0=time.time()
for n in names:
    with z.open(n) as fh:
        r=csv.reader(io.TextIOWrapper(fh,encoding="utf-8",errors="replace"))
        for row in r:
            if len(row)<9: continue
            date,t,pid,path,sc,ev,cat,sub,lab=row[:9]
            line=f"host event date={date} time={t} pid={pid} process={path} syscall={sc} event_id={ev} category={cat} label={lab}"
            tok+=len(enc.encode_ordinary(line)); rows+=1; bytes_in+=len(line)
            uniq.add((path,sc,cat,lab)); cats[cat]=cats.get(cat,0)+1
    print(n,rows,tok,round(time.time()-t0,1),flush=True)
out={"id":a.id,"source":"doi:10.7910/DVN/IFTZPF NGIDS-DS","files_sampled":len(names),"rows":rows,
     "cl100k":tok,"unique_tuples":len(uniq),"unique_ratio":round(len(uniq)/max(1,rows),5),
     "tokens_per_row":round(tok/max(1,rows),2),"categories":cats,"elapsed_s":round(time.time()-t0,1),
     "note":"host-log rows converted to key=value text; per-row records, no aggregation"}
json.dump(out,open(a.out,"w"),indent=1); print(json.dumps({k:out[k] for k in ("rows","cl100k","unique_tuples","unique_ratio","tokens_per_row","elapsed_s")},indent=1))
