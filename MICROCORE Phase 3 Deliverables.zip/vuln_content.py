#!/usr/bin/env python3
"""Content-only, deduplicated measurement of CISA Vulnrichment CVE JSON.

The raw tokenization of this archive (385.5M cl100k) is dominated by JSON
schema keys, indentation and repeated boilerplate. This pass reparses every
record, keeps only content-bearing fields, and reports:
  - content tokens (all records)
  - exact-duplicate record content tokens (same normalised content hash)
  - unique content tokens
  - description-only tokens and their duplicate rate
It also counts rejected-withdrawn records separately.
"""
import hashlib, io, json, sys, tarfile, time, urllib.request

import tiktoken

URL = "https://codeload.github.com/cisagov/vulnrichment/tar.gz/refs/heads/develop"

# keys whose string values carry security knowledge rather than schema
CONTENT_KEYS = {
    "value", "url", "product", "vendor", "packageName", "criteria",
    "vectorString", "baseScore", "baseSeverity", "version",
    "versionStartIncluding", "versionEndIncluding", "versionStartExcluding",
    "versionEndExcluding", "lang", "cpeName", "repo", "title",
}
SKIP_KEYS = {"dataVersion", "dataType", "serial", "assignerShortName",
             "assignerOrgId", "requesterUserId", "dateUpdated", "datePublished",
             "dateReserved", "datePublic", "state", "cveId", "orgId"}


def collect(node, out):
    if isinstance(node, dict):
        for k, v in node.items():
            if k in SKIP_KEYS:
                continue
            if isinstance(v, str) and k in CONTENT_KEYS:
                out.append(v)
            else:
                collect(v, out)
    elif isinstance(node, list):
        for v in node:
            collect(v, out)
    elif isinstance(node, str):
        out.append(node)


def main():
    enc = tiktoken.get_encoding("cl100k_base")
    t0 = time.time()
    req = urllib.request.Request(URL, headers={"User-Agent": "microcore-audit/3.0"})
    fh = urllib.request.urlopen(req, timeout=300)
    tf = tarfile.open(fileobj=fh, mode="r|gz")

    n = 0
    bad = 0
    rejected = 0
    raw_bytes = 0
    content_cl = 0
    uniq_cl = 0
    dup_cl = 0
    desc_cl = 0
    desc_seen = {}
    desc_dup_cl = 0
    hashes = {}
    while True:
        try:
            m = tf.next()
        except Exception:
            bad += 1
            break
        if m is None:
            break
        if not m.isfile() or not m.name.endswith(".json"):
            continue
        f = tf.extractfile(m)
        if f is None:
            continue
        blob = f.read()
        raw_bytes += len(blob)
        try:
            d = json.loads(blob)
        except Exception:
            bad += 1
            continue
        n += 1
        state = (d.get("cveMetadata", {}) or {}).get("state", "")
        if state == "REJECTED":
            rejected += 1
        parts = []
        collect(d.get("containers", {}), parts)
        text = "\n".join(parts)
        ids = enc.encode(text)
        t = len(ids)
        content_cl += t
        h = hashlib.blake2b(text.encode("utf-8", "ignore"), digest_size=16).hexdigest()
        if h in hashes:
            dup_cl += t
        else:
            hashes[h] = 1
            uniq_cl += t
        # description-only view
        descs = []
        conts = []
        for v in (d.get("containers", {}) or {}).values():
            if isinstance(v, dict):
                conts.append(v)
            elif isinstance(v, list):
                conts.extend(x for x in v if isinstance(x, dict))
        for c in conts:
            for item in (c.get("descriptions", []) or []):
                if isinstance(item, dict) and item.get("value"):
                    descs.append(item["value"].strip())
        dtxt = " ".join(descs)
        dcl = len(enc.encode(dtxt))
        desc_cl += dcl
        if dtxt:
            k = hashlib.blake2b(dtxt.encode("utf-8", "ignore"), digest_size=16).hexdigest()
            if k in desc_seen:
                desc_dup_cl += dcl
            else:
                desc_seen[k] = 1
        if n % 20000 == 0:
            print(f"  {n} records {time.time()-t0:.0f}s content={content_cl:,} uniq={uniq_cl:,}",
                  flush=True)

    res = {
        "source": "cisagov/vulnrichment", "branch": "develop", "url": URL,
        "records": n, "json_parse_failures": bad, "rejected_records": rejected,
        "raw_bytes": raw_bytes,
        "content_cl100k": content_cl,
        "unique_content_cl100k": uniq_cl,
        "exact_duplicate_content_cl100k": dup_cl,
        "unique_record_ratio": round(uniq_cl / content_cl, 4) if content_cl else 0,
        "description_cl100k": desc_cl,
        "description_duplicate_cl100k": desc_dup_cl,
        "distinct_descriptions": len(desc_seen),
        "tokens_per_record_content": round(content_cl / n, 1) if n else 0,
        "elapsed_s": round(time.time() - t0, 1),
        "method": "content-field extraction + exact-hash record dedup; not near-dup",
        "checked": "2026-11-26",
    }
    json.dump(res, open("data/vuln_content.json", "w"), indent=1)
    print(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
