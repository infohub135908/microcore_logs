#!/usr/bin/env python3
"""Sample-level near-duplication and field-composition study of Vulnrichment.

Streams the archive, stops after N JSON records, and reports:
  - token split by field family (description prose, CPE criteria, version
    ranges, reference URLs, CVSS vectors, product/vendor names)
  - unique 12-token shingle ratio over the concatenated content stream
The sample is explicitly labelled: it is the first N records in archive order,
not a random draw.
"""
import json, sys, tarfile, urllib.request, hashlib
from collections import Counter
import tiktoken

URL = "https://codeload.github.com/cisagov/vulnrichment/tar.gz/refs/heads/develop"
N = int(sys.argv[1]) if len(sys.argv) > 1 else 5000

FAM = {
    "description": ("value",),          # handled specially below
    "cpe": ("criteria", "cpeName"),
    "url": ("url",),
    "vector": ("vectorString", "baseScore", "baseSeverity"),
    "version": ("version", "versionStartIncluding", "versionEndIncluding",
                "versionStartExcluding", "versionEndExcluding"),
    "product": ("product", "vendor", "packageName"),
}
KEY2FAM = {}
for fam, keys in FAM.items():
    for k in keys:
        KEY2FAM[k] = fam
SKIP = {"dataVersion", "dataType", "serial", "assignerShortName", "assignerOrgId",
        "dateUpdated", "datePublished", "dateReserved", "datePublic", "state",
        "cveId", "orgId", "lang", "repo"}


def walk(node, acc):
    if isinstance(node, dict):
        for k, v in node.items():
            if k in SKIP:
                continue
            if isinstance(v, str) and k in KEY2FAM:
                acc[KEY2FAM[k]].append(v)
            else:
                walk(v, acc)
    elif isinstance(node, list):
        for v in node:
            walk(v, acc)


def main():
    enc = tiktoken.get_encoding("cl100k_base")
    req = urllib.request.Request(URL, headers={"User-Agent": "microcore-audit/3.0"})
    tf = tarfile.open(fileobj=urllib.request.urlopen(req, timeout=300), mode="r|gz")
    fam_tok = Counter()
    stream = []
    n = 0
    while n < N:
        try:
            m = tf.next()
        except Exception:
            break
        if m is None:
            break
        if not m.isfile() or not m.name.endswith(".json"):
            continue
        f = tf.extractfile(m)
        if f is None:
            continue
        try:
            d = json.loads(f.read())
        except Exception:
            continue
        n += 1
        acc = {k: [] for k in FAM}
        conts = []
        for v in (d.get("containers", {}) or {}).values():
            if isinstance(v, dict):
                conts.append(v)
            elif isinstance(v, list):
                conts.extend(x for x in v if isinstance(x, dict))
        for c in conts:
            for it in (c.get("descriptions", []) or []):
                if isinstance(it, dict) and it.get("value"):
                    acc["description"].append(it["value"])
        walk(d.get("containers", {}), acc)
        for fam, vals in acc.items():
            if vals:
                ids = enc.encode("\n".join(vals))
                fam_tok[fam] += len(ids)
                stream.extend(ids)

    shingles = set()
    total = 0
    for i in range(len(stream) - 11):
        h = hash(tuple(stream[i:i + 12]))
        total += 1
        shingles.add(h)
    tot = sum(fam_tok.values())
    res = {
        "source": "cisagov/vulnrichment", "sample_records": n, "sample_type": "first N records in archive order",
        "sample_content_cl100k": tot,
        "field_tokens": dict(fam_tok),
        "field_share": {k: round(v / tot, 4) for k, v in fam_tok.items()} if tot else {},
        "shingle_size": 12, "shingles": total, "unique_shingles": len(shingles),
        "unique_shingle_ratio": round(len(shingles) / total, 4) if total else 0,
        "note": "ratio of distinct 12-token sequences; 1.0 means every sequence is novel",
        "checked": "2026-11-26",
    }
    json.dump(res, open("data/vuln_shingle.json", "w"), indent=1)
    print(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
