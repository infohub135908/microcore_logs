# MICROCORE Phase 5 — Cybersecurity-First Corpus Redesign

Deliverables 1–11. Date of all licence and availability checks: 2026-11-27.

## Documents

| # | File | Contents |
|---|---|---|
| 1 | `01_executive_strategy.md` | strategy, why Stack v3 is abandoned, supply reality, composition |
| 2 | `02_curriculum_matrix.md` | domains A–L × required capabilities, source coverage, sequencing |
| 3 | `03_ranked_sources.md` | 74 ranked sources with 15-field detail; `03_source_register.csv` is the machine-readable register, `_table.md` the condensed table |
| 4 | `04_languages.md` | eleven-language security coding plan, with flag on reconstruction and substitution appendix |
| 5 | `05_allocation_model.md` | percentages, tokens at 5 B and at 2.8 B, caps, enforcement |
| 6 | `06_pipeline.md` | eleven-stage design, manifest schema, dedup tiers, priorities, calibration rule |
| 7 | `07_licensing_register.md` | decisions, evidence, obligations, unresolved legal questions |
| 8 | `08_gap_analysis.md` | domain and language gaps, capabilities no acquisition closes |
| 9 | `09_benchmarks.md` | external and internal evaluations, decontamination rules |
| 10 | `10_roadmap.md` | eight stages, gates, resources, incremental tokens |
| 11 | `11_feasibility.md` | conservative/realistic/optimistic scenarios, routes to 5 B, recommendation |

## Headline numbers

- Sources examined: 74 — 48 approved, 13 conditional, 13 rejected.
- Measured this phase: 47,081,833 cl100k, of which 40,265,955 training-eligible.
- Carried forward: 1,812,199,722 cl100k — measured per source, **not globally deduplicated, provisional**.
- Feasible security-first corpus: **2.1–2.8 B unique**, realistic 2.5 B.
- 5 B is not reachable from licence-clean security sources. See Deliverable 11.

## Evidence discipline

Measured, publisher-reported, sample-projected and unverified figures are labelled as such throughout. No token count, licence, size or availability claim in this phase was estimated from a search result; each licence decision cites the licence file inspected on 2026-11-27, and each measured token count comes from streaming the source through the Phase 3 acquisition pipeline with cl100k_base.

## Reproduction

`sources.py` rebuilds `03_source_register.csv`. The ten measured sources are recorded in `../data/a_MC-4xx.json` with per-source file counts, admitted bytes, tokenizer and cl100k totals. Measurement used the Phase 3 pipeline at `../../p3/pipeline/acquire.py`.
