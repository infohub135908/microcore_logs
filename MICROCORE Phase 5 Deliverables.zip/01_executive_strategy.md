# Deliverable 1 — Executive Strategy

## The decision, and what follows from it

Stack v3 is out. That removes the only source that could have carried the corpus to 5 B by volume, and it removes it for a good reason: a corpus that reaches its target by absorbing 3 B tokens of arbitrary permissively licensed repository code is not a cybersecurity corpus with code in it, it is a code corpus with a security prompt.

So the question changes. It is no longer "which sources reach 5 B" but "which sources make the model genuinely good at security work, and what does that set actually total". This report answers the second question, and the answer is uncomfortable: the licence-clean, security-first supply is roughly **2.1–2.8 B tokens**, not 5 B. Section 11 shows the arithmetic and what closing the gap would cost.

## What a security specialist model needs that a code model does not

Four kinds of knowledge, only one of which looks like code.

**Mechanism.** How a heap allocator hands out chunks, how Kerberos issues a service ticket, how an ELF loader maps segments, how an SMB session is established. This is what lets the model reason about *why* a bug is exploitable rather than pattern-matching a CVE description.

**Procedure.** The actual sequence of commands, observations and judgements in an assessment, an incident, a malware triage. Models fail here far more often than on facts, because procedure is almost absent from static corpora.

**Judgement.** Which finding matters, what a log line implies, when an anomaly is benign. This comes from case narrative and from well-structured worked examples, not from reference documentation.

**Vocabulary and mapping.** CVE, CWE, ATT&CK, CAPEC, CVSS, STIX, detection-rule semantics. Cheap in tokens, expensive to omit, because it is the indexing scheme the rest of the knowledge hangs from.

The corpus plan is built around those four, and the code that is included is chosen because it demonstrates mechanism, not because it is code.

## Why this is a redesign and not a re-rank

The Phase 3 and Phase 4 plans optimised for volume under a licence allowlist. That produced a corpus that was 56 % operating-system and compiler source, with security content at 2.5 %. The new allocation inverts the hierarchy:

| Layer | Share of target | Purpose |
|---|---|---|
| Direct security knowledge and procedure | 45 % | the specialist capability |
| Security-relevant code across 11 languages | 25 % | mechanism and tool-building |
| Systems, network and cryptographic foundations | 20 % | the substrate security reasoning depends on |
| Practical lab and tool-use material | 10 % | procedure and interpretation |

Under the old plan, foundations were allowed to grow to fill whatever volume was convenient. Under this one they are capped, and their cap is enforced by sampling down, not by hoping no one notices.

## The supply reality

Of 74 sources examined and licence-verified on 2026-11-27: 48 approved, 13 conditional, 13 rejected. Ten were measured by streaming and tokenizing them in this phase, contributing 47,081,833 cl100k tokens, of which 40,265,955 is training-eligible (Cybench is evaluation-only).

The pattern is consistent across every domain examined. The technically best community material is unlicensed (HackTricks, Chainsaw), GPL/AGPL (Velociraptor, MobSF, Nishang, bettercap, AFL++), share-alike (OWASP's guides), or restricted (Sigma DRL, Elastic Licence, Nmap NPSL, Terraform BUSL). What survives is:

- **institutional knowledge** — MITRE ATT&CK, NIST, CISA, DISA, MSRC, Google Project Zero, Trail of Bits;
- **commercial-vendor tooling released permissively** — Mandiant, Splunk, Palo Alto, Aqua, Sysdig, GhostPack;
- **academic and community teaching material** — RPISEC MBE, how2heap, xairy's kernel index, Juice Shop, Vulhub;
- **language and platform runtimes** — EDK2, Zephyr, libsodium, BoringSSL, Impacket.

That is a real corpus. It is not 5 B tokens, and pretending otherwise would mean padding it with exactly the material this redesign exists to exclude.

## Three decisions this report asks for

1. **Accept a security-first corpus of 2.1–2.8 B, or authorise a foundation layer** that is explicitly labelled as non-security support material and capped. The second option can reach 5 B; it will not be a purer security model, it will be a broader one.
2. **Fund lab generation.** Procedure is the scarcest category and the only one that can be manufactured legitimately: atomic tests, Vulnerable-app environments and forensic recordings can be executed and captured. It is also the only category where more tokens genuinely means more capability.
3. **Set the mixture as a hard constraint, not a target.** The failure mode of every corpus project is that the easy source expands to fill the budget. With 11 languages, four knowledge layers and six domain pillars, the caps matter more than the totals.

## What has already been established, and is not reopened

Random initialisation, English-first, five model sizes sharing one corpus, cl100k accounting with GPT-2 secondary, Kaggle T4s at roughly 30 GPU-hours weekly, and the existing 1,812,199,722-token provisional baseline. Nothing in this report depends on reaching exactly 5 B; the training plan is unaffected by whether the corpus is 2.8 B or 5 B, only the number of epochs and the mixture change.
