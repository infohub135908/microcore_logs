# Deliverable 2 — Cybersecurity Curriculum and Coverage Matrix

Coverage is scored against what MICROCORE can legally acquire today, not against what exists on the internet. **Strong** means measured, sufficient material with a clean licence. **Partial** means some material, thin or one-sided. **Gap** means nothing legally usable at depth.

## Domain matrix

| Domain | Required subtopics | Best available source types | Current coverage | Principal gap | Priority |
|---|---|---|---|---|---|
| A. Offensive security and penetration testing | recon, enumeration, service assessment, network/web/API testing, authz testing, privesc, AD, cloud, container, segmentation, controlled exploitation, red-team emulation, reporting | tool source (Impacket, GhostPack, Pacu, MicroBurst), vulnerable apps (Juice Shop, Vulhub), lab recordings | **Partial** | almost no procedure narrative; the tools exist, the assessments do not | Critical |
| B. Vulnerability research and exploit development | stack/heap/UAF/double-free/int overflow/format string/race, ROP, mitigations, heap internals, kernel, browser, fuzzing, crash triage, patch analysis | teaching repos (how2heap, MBE), research writeups (Project Zero, MSRC), fuzz targets (OSS-Fuzz), kernel index | **Partial** | depth is uneven: heap and stack strong, browser/JIT and kernel exploitation thin | Critical |
| C. Reverse engineering and binary analysis | static/dynamic analysis, disassembly, decompilation, x86/ARM, calling conventions, ELF/PE, debuggers, patching, firmware, protocol RE, anti-tamper, unpacking | tool source (Ghidra, Capstone, angr, pwndbg, FLOSS, Binwalk), firmware (EDK2), docs (Ghidra handbook is Apache-2.0) | **Strong** | protocol RE and obfuscation analysis thin; most malware RE writeups are unlicensed | High |
| D. Malware analysis and tradecraft | triage, static/dynamic, sandboxing, persistence, C2, injection, credential theft, evasion, packers, ransomware, rootkits, fileless, LOTL, config extraction, IOCs | capa + capa-rules, FLOSS, ATT&CK, detection content, OTRF telemetry | **Partial** | sample-level narrative absent: no licence-clean malware analysis corpus exists | High |
| E. Defensive security and detection engineering | SOC, SIEM, EDR, NDR, IDS, hunting, detection-as-code, log analysis, Sigma/YARA semantics, Suricata/Zeek/Sysmon, Windows/Linux/cloud audit, validation, FP reduction, coverage analysis | Splunk security_content, Sigma spec, Falco, Zeek, YARA, KapeFiles, ATT&CK | **Strong** | Sigma and Suricata rule corpora are licence-blocked; semantics covered, rules not | High |
| F. Digital forensics and incident response | disk/memory/network/Windows/Linux/cloud/container/mobile forensics, timelines, acquisition, chain of custody, containment, ransomware IR, compromise assessment, reporting | Plaso, KapeFiles, OTRF, Sleuth Kit (licence unclear), case literature (mostly restricted) | **Partial** | memory forensics (Volatility VSL) and case narratives are blocked; tooling present, investigations absent | Critical |
| G. OS, enterprise and identity | Linux/Windows internals, Server, AD, Entra ID, Kerberos, LDAP, SMB, NTLM, DNS, PAM, filesystems, processes, syscalls, kernel, privilege boundaries, IAM, hardening | Impacket, GhostPack, entra-docs, Win32 docs, FreeBSD, PowerShell docs | **Strong** (docs + protocol code) | Windows kernel source does not exist legally; AD *attack paths* thin relative to protocol mechanics | Critical |
| H. Network and protocol security | TCP/IP, DNS, HTTP/TLS, SSH, SMTP, FTP, SMB, LDAP, Kerberos, routing, VPN, firewalls, segmentation, packet analysis, wireless, protocol fuzzing | libpcap/tcpdump, BoringSSL, Zeek, FreeBSD netinet, Zephyr (802.15.4/BLE) | **Partial** | wireless (hostapd is BSD but unverified here) and protocol fuzzing thin | High |
| I. Cloud, container and infrastructure security | AWS/Azure/GCP IAM, control plane, storage exposure, metadata services, serverless, cloud networking, Kubernetes, Docker, escapes, supply chain, CI/CD, secrets, IaC, cloud detection and IR | Checkov, Falco, kube-bench, kube-hunter, OPA, Prowler, Pacu, MicroBurst, kubernetes/website, azure-docs | **Partial** | GCP nearly absent; cloud IR procedure absent; AWS/Azure tooling strong | Critical |
| J. Web, API and application security | OWASP classes, injection families, XSS/CSRF/SSRF, traversal, upload, authn/authz flaws, deserialization, template injection, API object-level authz, logic flaws, races, browser security, CORS/CSP, session management, code auditing, remediation | Juice Shop, NodeGoat, CodeQL, Trail of Bits handbook, vulnerable repos | **Partial** | OWASP's own guidance corpus is share-alike and excluded; depth must come from code and labs | High |
| K. Mobile, firmware, IoT, wireless, hardware | Android/iOS security, mobile RE and testing, firmware, embedded Linux, bootloaders, secure boot, IoT protocols, BLE, Wi-Fi, NFC/RFID, Zigbee, hardware interfaces, side channels, fault injection, hardware debugging, OT/ICS | jadx, apktool, EDK2, Zephyr, FreeRTOS, ChipWhisperer, Binwalk | **Partial** | iOS, NFC/RFID, Zigbee, OT/ICS: essentially nothing licence-clean | Critical (gap domain) |
| L. Cryptography and security mathematics | symmetric, public key, hashes, signatures, key exchange, TLS/PKI, certificate validation, auth protocols, implementation flaws, RNG, side channels, cryptanalysis, modular arithmetic | libsodium, BoringSSL, mbedTLS, Tink, OpenSSL, NIST, ChipWhisperer | **Strong** | applied cryptanalysis literature mostly non-permissive | Medium |

## Cross-cutting capability matrix

| Capability | Where it is taught | Coverage | Note |
|---|---|---|---|
| Reading tool output | tool repos, docs, OTRF recordings | Partial | output *formats* documented; interpretation rarely |
| Command-line competence | Atomic Red Team, Vulhub, KapeFiles | Partial | commands present, sessions absent |
| Debugging and crash triage | pwndbg, MBE, OSS-Fuzz, Project Zero | Partial | strongest of the procedural categories |
| Detection authoring | Splunk content, Sigma spec, Falco | Strong | rule *semantics* covered |
| Secure code review | CodeQL, Trail of Bits, vulnerable apps | Partial | query language strong, review judgement weak |
| Exploit reasoning | how2heap, MBE, kernel index | Partial | concept strong, end-to-end chain weak |
| Incident narrative | — | **Gap** | nothing licence-clean at depth |
| Reporting and remediation | NIST 800-115, vendor docs | Partial | template-level only |

## What the matrix says about allocation

Two domains are Strong and both are documentation-heavy: reverse engineering and detection. Three are Critical and all are procedure-heavy: offensive operations, DFIR, and the hardware/firmware/mobile block. That asymmetry is the central planning fact: **the corpus is rich in things the model can read and poor in things the model must do.**

Every acquisition decision in Deliverable 3 follows from it. Where a source adds mechanism or vocabulary, it is taken even if small. Where a source would add volume without procedure, it is capped. And where procedure simply does not exist in licence-clean form — which is most of DFIR, most of cloud IR, and all of OT/ICS — the plan says so rather than substituting a code repository and calling the gap closed.
