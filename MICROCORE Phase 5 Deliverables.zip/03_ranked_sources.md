# Deliverable 3 — Ranked Source Acquisition Table

74 sources, all licence-verified on 2026-11-27 by fetching the licence file from the repository or the publisher's terms page. 48 approved, 13 conditional, 13 rejected. Ten were measured end-to-end in this phase.

Ranking order: Tier A approved sources first, ordered by expected cybersecurity contribution per token and by how directly they close a Critical domain gap; then Tier B; then conditional; then rejected (kept visible for audit).

| # | Source | Domains | Licence | Commercial | Redistribution | Measured cl100k | Tier | Decision | Priority |
|---|---|---|---|---|---|---|---|---|---|
| 1 | [Atomic Red Team](https://github.com/redcanaryco/atomic-red-team) | red-team, detection validation, lab generation | MIT | yes | yes | 2,233,518 | A | APPROVED | now |
| 2 | [Splunk Security Content](https://github.com/splunk/security_content) | detection engineering, SIEM, threat hunting | Apache-2.0 | yes | yes | 4,956,249 | A | APPROVED | now |
| 3 | [OTRF Security-Datasets](https://github.com/OTRF/Security-Datasets) | DFIR, telemetry, detection | MIT | yes | yes | 250,695 | A | APPROVED | now |
| 4 | [OWASP Juice Shop](https://github.com/juice-shop/juice-shop) | web appsec, labs, secure coding | MIT | yes | yes | 3,203,538 | A | APPROVED | now |
| 5 | [Cybench](https://github.com/andyzorigin/cybench) | evaluation, CTF, tool use | Apache-2.0 | yes | yes | 6,815,878 | A | CONDITIONAL | evaluation only |
| 6 | [Checkov](https://github.com/bridgecrewio/checkov) | cloud security, IaC, secure config | Apache-2.0 | yes | yes | 4,509,235 | A | APPROVED | now |
| 7 | [Falco](https://github.com/falcosecurity/falco) | container security, detection engineering | Apache-2.0 | yes | yes | 624,695 | A | APPROVED | now |
| 8 | [kube-bench](https://github.com/aquasecurity/kube-bench) | kubernetes security, hardening | Apache-2.0 | yes | yes | 1,008,409 | A | APPROVED | now |
| 9 | [Open Policy Agent](https://github.com/open-policy-agent/opa) | cloud security, IAM, policy-as-code | Apache-2.0 | yes | yes | 9,412,355 | A | APPROVED | now |
| 10 | [CodeQL](https://github.com/github/codeql) | SAST, code auditing, vulnerability discovery | MIT | yes | yes | 14,067,261 | A | APPROVED | next |
| 11 | [Trail of Bits Testing Handbook](https://github.com/trailofbits/testing-handbook) | appsec, fuzzing, tool use | CC-BY-4.0 | yes | yes | not measured | A | APPROVED | now |
| 12 | [Linux Kernel Exploitation](https://github.com/xairy/linux-kernel-exploitation) | kernel security, exploit development | CC-BY-4.0 | yes | yes | not measured | A | APPROVED | now |
| 13 | [MSRC Security Research](https://github.com/microsoft/MSRC-Security-Research) | exploit dev, mitigations, Windows internals | CC-BY-4.0 | yes | yes | not measured | A | APPROVED | next |
| 14 | [Google Security Research](https://github.com/google/security-research) | vuln research, browser/kernel security | Apache-2.0 | yes | yes | not measured | A | APPROVED | next |
| 15 | [capa-rules](https://github.com/mandiant/capa-rules) | malware analysis, detection engineering | Apache-2.0 | yes | yes | not measured | A | APPROVED | now |
| 16 | [FLOSS](https://github.com/mandiant/flare-floss) | malware analysis, RE | Apache-2.0 | yes | yes | not measured | A | APPROVED | now |
| 17 | [KapeFiles](https://github.com/EricZimmerman/KapeFiles) | DFIR, Windows forensics | MIT | yes | yes | not measured | A | APPROVED | now |
| 18 | [Plaso](https://github.com/log2timeline/plaso) | DFIR, timeline analysis | Apache-2.0 | yes | yes | not measured | A | APPROVED | next |
| 19 | [OpenCTI](https://github.com/OpenCTI-Platform/opencti) | threat intel, CTI engineering | Apache-2.0 | yes | yes | not measured | A | APPROVED | later |
| 20 | [Rubeus](https://github.com/GhostPack/Rubeus) | Active Directory, Kerberos, red team | BSD-3-Clause (file header says 3-clause; classifier read BSD-2) | yes | yes | not measured | A | APPROVED | now |
| 21 | [Seatbelt](https://github.com/GhostPack/Seatbelt) | Windows internals, host enumeration | BSD-3-Clause (Apache text also present) | yes | yes | not measured | A | CONDITIONAL | now |
| 22 | [Certify](https://github.com/GhostPack/Certify) | AD CS, PKI, enterprise identity | BSD-3-Clause | yes | yes | not measured | A | APPROVED | now |
| 23 | [PKINITtools](https://github.com/dirkjanm/PKINITtools) | AD, Kerberos, PKI | MIT | yes | yes | not measured | A | APPROVED | now |
| 24 | [Impacket](https://github.com/fortra/impacket) | AD, SMB, Kerberos, network protocols | BSD-3-Clause (custom 3-clause text) | yes | yes | not measured | A | APPROVED | now |
| 25 | [PowerSploit](https://github.com/PowerShellMafia/PowerSploit) | PowerShell, Windows, red team | BSD-3-Clause | yes | yes | not measured | A | APPROVED | now |
| 26 | [Empire](https://github.com/BC-Security/Empire) | red team, C2 concepts | BSD-3-Clause | yes | yes | not measured | A | CONDITIONAL | later |
| 27 | [adidnsdump](https://github.com/dirkjanm/adidnsdump) | AD, DNS | MIT | yes | yes | not measured | B | APPROVED | now |
| 28 | [Pacu](https://github.com/RhinoSecurityLabs/pacu) | cloud security, AWS IAM | BSD-3-Clause | yes | yes | not measured | A | APPROVED | now |
| 29 | [MicroBurst](https://github.com/NetSPI/MicroBurst) | Azure security, Entra ID | BSD-3-Clause | yes | yes | not measured | A | APPROVED | now |
| 30 | [how2heap](https://github.com/shellphish/how2heap) | heap exploitation, memory corruption | MIT | yes | yes | not measured | A | APPROVED | now |
| 31 | [RPISEC Modern Binary Exploitation](https://github.com/RPISEC/MBE) | exploit dev, RE, assembly | BSD-2-Clause | yes | yes | not measured | A | APPROVED | now |
| 32 | [angr](https://github.com/angr/angr) | program analysis, RE | BSD-2-Clause | yes | yes | not measured | A | APPROVED | next |
| 33 | [Z3](https://github.com/Z3Prover/z3) | formal methods, exploit reasoning | MIT | yes | yes | not measured | A | APPROVED | later |
| 34 | [Capstone](https://github.com/capstone-engine/capstone) | RE, disassembly, architecture | BSD-3-Clause | yes | yes | not measured | A | APPROVED | next |
| 35 | [pwndbg](https://github.com/pwndbg/pwndbg) | exploit dev, debugging | MIT | yes | yes | not measured | A | APPROVED | now |
| 36 | [OSS-Fuzz](https://github.com/google/oss-fuzz) | fuzzing, vulnerability discovery | Apache-2.0 | yes | yes | not measured | A | APPROVED | next |
| 37 | [ChipWhisperer](https://github.com/newaetech/chipwhisperer) | hardware security, side channels | Apache-2.0 (mixed file notices) | yes | yes | not measured | A | CONDITIONAL | next |
| 38 | [EDK2 (TianoCore UEFI)](https://github.com/tianocore/edk2) | firmware, bootloaders, secure boot | BSD-2-Clause-Patent per file headers; no single top-level licence file found | yes | yes | not measured | A | CONDITIONAL | next |
| 39 | [Zephyr RTOS](https://github.com/zephyrproject-rtos/zephyr) | IoT, embedded, wireless protocols | Apache-2.0 | yes | yes | not measured | A | APPROVED | next |
| 40 | [FreeRTOS Kernel](https://github.com/FreeRTOS/FreeRTOS-Kernel) | IoT, embedded | MIT | yes | yes | not measured | A | APPROVED | now |
| 41 | [libsodium](https://github.com/jedisct1/libsodium) | cryptography, secure coding | ISC | yes | yes | not measured | A | APPROVED | next |
| 42 | [BoringSSL](https://github.com/google/boringssl) | TLS, cryptography, protocol security | Apache-2.0 (mixed OpenSSL/ISC notices) | yes | yes | not measured | A | APPROVED | later |
| 43 | [Tink](https://github.com/tink-crypto/tink-java) | cryptography, key management | Apache-2.0 | yes | yes | not measured | A | APPROVED | later |
| 44 | [apktool](https://github.com/iBotPeaches/Apktool) | mobile, Android RE | Apache-2.0 | yes | yes | not measured | A | APPROVED | now |
| 45 | [jadx](https://github.com/skylot/jadx) | mobile, RE, decompilation | Apache-2.0 | yes | yes | not measured | A | APPROVED | now |
| 46 | [Binwalk](https://github.com/ReFirmLabs/binwalk) | firmware analysis | MIT | yes | yes | not measured | A | APPROVED | now |
| 47 | [SecLists](https://github.com/danielmiessler/SecLists) | recon, password security | MIT | yes | yes | not measured | B | CONDITIONAL | later |
| 48 | [Vulhub](https://github.com/vulhub/vulhub) | labs, CVE reproduction | MIT | yes | yes | not measured | A | APPROVED | now |
| 49 | [MITRE ATT&CK STIX](https://github.com/mitre-attack/attack-stix-data) | threat intel, detection engineering | Custom licence: non-exclusive royalty-free, commercial use permitted with notice | yes | yes (with notice) | not measured | A | APPROVED | now |
| 50 | [NIST SP 800 series](https://csrc.nist.gov/pubs) | standards, GRC, IR | US Government work — public domain (17 U.S.C. 105) | yes | yes | not measured | A | APPROVED | next |
| 51 | [CISA KEV catalogue](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) | vuln intel, prioritisation | US Government work — public domain | yes | yes | not measured | A | APPROVED | now |
| 52 | [NVD CVE feeds (2.0)](https://nvd.nist.gov/vuln/data-feeds) | vuln intel | US Government work — public domain | yes | yes | not measured | A | APPROVED | next |
| 53 | [Sigma specification](https://github.com/SigmaHQ/sigma-specification) | detection engineering, log semantics | Public domain (spec); rules are DRL — rules excluded | yes | yes | not measured | A | APPROVED | now |
| 54 | [DISA STIGs](https://public.cyber.mil/stigs/) | hardening, compliance, enterprise | US Government work; distribution statement and site agreement apply | unclear | unclear | not measured | C | CONDITIONAL | later |
| 55 | [IETF RFCs](https://www.rfc-editor.org/) | protocols, network security | IETF Trust legal provisions: copyright retained, limited reproduction rights | unclear | restricted | not measured | C | CONDITIONAL | later |
| 56 | [Elastic detection-rules](https://github.com/elastic/detection-rules) | detection engineering | Elastic License 2.0 — source-available, not open source | restricted | restricted | not measured | D | REJECTED | never |
| 57 | [SigmaHQ rules](https://github.com/SigmaHQ/sigma) | detection engineering | Detection Rule License 1.1 | restricted | restricted | not measured | D | REJECTED | never |
| 58 | [HackTricks](https://github.com/carlospolop/hacktricks) | pentest, AD, cloud, privesc | No licence file found | no | no | not measured | D | REJECTED | never |
| 59 | [OWASP Cheat Sheet Series](https://github.com/OWASP/CheatSheetSeries) | appsec, secure coding | CC-BY-SA-4.0 | yes | yes with share-alike | not measured | D | REJECTED | never |
| 60 | [OWASP WSTG](https://github.com/OWASP/wstg) | web appsec testing | CC-BY-SA-4.0 | yes | share-alike | not measured | D | REJECTED | never |
| 61 | [Velociraptor](https://github.com/Velocidex/velociraptor) | DFIR, endpoint | AGPL-3.0 | yes | copyleft | not measured | D | REJECTED | never |
| 62 | [MobSF](https://github.com/MobSF/Mobile-Security-Framework-MobSF) | mobile security | GPL-3.0 | yes | copyleft | not measured | D | REJECTED | never |
| 63 | [Chainsaw](https://github.com/WithSecureLabs/chainsaw) | DFIR, Windows forensics | No licence file found | no | no | not measured | D | REJECTED | never |
| 64 | [Nishang](https://github.com/samratashok/nishang) | PowerShell, red team | GPL-3.0 | yes | copyleft | not measured | D | REJECTED | never |
| 65 | [bettercap](https://github.com/bettercap/bettercap) | network security, MITM concepts | GPL-3.0 | yes | copyleft | not measured | D | REJECTED | never |
| 66 | [AFL++](https://github.com/AFLplusplus/AFLplusplus) | fuzzing | AGPL-3.0 | yes | copyleft | not measured | D | REJECTED | never |
| 67 | [radare2](https://github.com/radareorg/radare2) | RE, binary analysis | LGPL-3.0 | yes | weak copyleft | not measured | C | CONDITIONAL | never |
| 68 | [semgrep-rules](https://github.com/semgrep/semgrep-rules) | SAST, code auditing | LGPL-2.1 + Commons Clause | no (Commons Clause) | restricted | not measured | D | REJECTED | never |
| 69 | [Terraform](https://github.com/hashicorp/terraform) | cloud, IaC | BUSL-1.1 (not open source) | restricted | restricted | not measured | D | REJECTED | never |
| 70 | [Nmap](https://github.com/nmap/nmap) | recon, network assessment | Nmap Public Source License (NPSL) — GPL-like with restrictions | restricted for redistribution | restricted | not measured | C | CONDITIONAL | never |
| 71 | [PurpleLlama / CyberSecEval](https://github.com/meta-llama/PurpleLlama) | evaluation | Llama 3.2 Community Licence | restricted | restricted | not measured | C | CONDITIONAL | evaluation only |
| 72 | [NYU CTF Bench](https://github.com/NYU-LLM-CTF/NYU_CTF_Bench) | evaluation | GPL-2.0 | yes | copyleft | not measured | C | CONDITIONAL | evaluation only |
| 73 | [InterCode](https://github.com/princeton-nlp/intercode) | evaluation, tool use | MIT | yes | yes | not measured | B | APPROVED | evaluation only |
| 74 | [Metasploit Framework](https://github.com/rapid7/metasploit-framework) | exploit dev, red team | BSD-3-Clause at repo level; substantial file-level variation | yes | yes | not measured | C | CONDITIONAL | never |

## Measured in this phase

Ten sources were streamed, licence-filtered and tokenized with cl100k_base on 2026-11-27:

| ID | Source | cl100k tokens | Files |
|---|---|---|---|
| MC-410 | github/codeql | 14,067,261 | 27,928 |
| MC-409 | open-policy-agent/opa | 9,412,355 | 5,082 |
| MC-405 | andyzorigin/cybench | 6,815,878 | 3,095 |
| MC-402 | splunk/security_content | 4,956,249 | 4,192 |
| MC-406 | bridgecrewio/checkov | 4,509,235 | 7,540 |
| MC-404 | juice-shop/juice-shop | 3,203,538 | 1,031 |
| MC-401 | redcanaryco/atomic-red-team | 2,233,518 | 1,025 |
| MC-408 | aquasecurity/kube-bench | 1,008,409 | 372 |
| MC-407 | falcosecurity/falco | 624,695 | 335 |
| MC-403 | OTRF/Security-Datasets | 250,695 | 181 |
| | **Total** | **47,081,833** | |

Of that, 6,815,878 (Cybench) is evaluation-only and does not enter the training corpus, leaving **40,265,955 training-eligible tokens**.

Two measurements are worth reading carefully rather than averaging. **OTRF Security-Datasets yields only 250,695 tokens from the repository tree** because the actual telemetry sits inside ZIP archives that the text filter does not open; the repository is a delivery mechanism, not the corpus. Its real value is in the archives, and it must be measured by extraction rather than by tree size. Similarly **kube-bench is small but the CIS benchmark text it implements is not redistributable**, so the Go and YAML are usable and the standard is not.

## Ranked shortlist: what to acquire next

| Order | Source | Why now | Expected tokens |
|---|---|---|---|
| 1 | Impacket | the single richest licence-clean AD/SMB/Kerberos protocol corpus | 8–12 M |
| 2 | GhostPack suite (Rubeus, Certify, Seatbelt) | AD attack paths, C# | 3–5 M |
| 3 | MSRC Security Research | Windows exploitation and mitigation depth, CC-BY-4.0 | 60–120 M |
| 4 | Google security-research | browser/kernel vuln research with PoCs | 40–90 M |
| 5 | Trail of Bits Testing Handbook | procedure-heavy tool usage, prose | 3–6 M |
| 6 | xairy kernel exploitation index | kernel exploitation map, high value per token | 1–2 M |
| 7 | how2heap + RPISEC MBE | heap and stack exploitation teaching | 5–10 M |
| 8 | Zephyr | embedded/IoT mechanism at scale | 120–200 M |
| 9 | EDK2 | UEFI/secure boot, per-file licence enforcement needed | 100–180 M |
| 10 | Vulhub | 200+ CVE reproduction environments | 2–4 M |
| 11 | NVD older years + CISA KEV | vulnerability vocabulary, incremental to 2024 | 60–120 M |
| 12 | NIST 800 series | normative defensive knowledge | 40–90 M |

## What is not in the shortlist, and why

Sigma rules, Elastic rules, MobSF, Velociraptor, AFL++, bettercap, Nishang, Nmap and Terraform are all technically valuable and all fail the licence gate. HackTricks and Chainsaw have no licence at all. OWASP's Cheat Sheets, WSTG, ASVS and Top 10 are CC-BY-SA-4.0, which would propagate share-alike obligations into a corpus intended for commercial use.

None of these is rejected for quality. They are rejected because the project's own standard is a legally defensible corpus, and a defensible corpus cannot contain material whose terms it cannot meet.
