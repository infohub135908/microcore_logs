# Deliverable 4 — Security Coding Plan for the Eleven Languages

## Provenance of the list, stated plainly

The exact eleven-language list was **not present** in the accessible project records: the Phase 2 specification attachment, the Phase 3 and Phase 4 deliverables, and the `microcore_logs` archive were all searched, and none states it. Rather than silently invent a list, the eleven below are reconstructed from the languages the project has actually measured and allocated across Phases 3–4, and every one is corroborated by a measured token count in the Phase 3 content distribution (`p3/out/12_token_yield_report.md`).

| # | Language | Evidence of project commitment (measured tokens) |
|---|---|---|
| 1 | C | 240,300,000 |
| 2 | C++ | 183,500,000 |
| 3 | C# | 90,200,000 |
| 4 | Go | 62,100,000 |
| 5 | Rust | 35,400,000 |
| 6 | Python | fraction of the Python-measured repositories (CPython 27,861,616 plus tooling) |
| 7 | Java | present in Kafka, OpenSearch, Ghidra, apktool, jadx |
| 8 | JavaScript | present in VS Code, Home Assistant, Node.js (19,190,266) |
| 9 | TypeScript | present in VS Code, Juice Shop, OpenCTI |
| 10 | PowerShell | measured documentation block, PowerSploit, MicroBurst |
| 11 | Shell/Bash | present across FreeBSD, Kubernetes, tooling |

**If the canonical list differs**, the substitution mechanics are identical: the analysis below is per-language and additive. The most likely alternatives are PHP, Ruby, Kotlin, Swift, Assembly and SQL. Notes for those are in the appendix, so a swap costs a paragraph, not a rewrite. What should not happen is silently expanding the set to fourteen languages.

## Why these eleven, from a security standpoint

They are not the eleven most popular languages; they are the eleven that between them cover the security-relevant execution surfaces:

C and C++ are where memory corruption lives — kernels, parsers, protocol stacks, embedded firmware. C# and PowerShell are the Windows and Active Directory surface, which is where enterprise intrusions happen. Go and Rust are the modern cloud control plane and, increasingly, the tooling; Rust additionally teaches the memory-safety contrast that explains why certain bug classes vanish. Python is the language of security tooling and exploit scripting. Java is the enterprise server surface and the Android toolchain language. JavaScript and TypeScript are the web attack surface and the analysis targets for prototype pollution and client-side bugs. Shell is what incident responders actually type.

## Per-language plan

### 1. C
Mechanism: manual memory management, undefined behaviour, integer promotion, pointer arithmetic, varargs, signals, setjmp, threading with pthreads, libc and syscall boundaries.
Vulnerability classes: overflow, UAF, double free, off-by-one, format string, uninitialised use, signedness, TOCTOU, stack exhaustion.
Sources: how2heap (MIT), RPISEC MBE (BSD-2), libsodium (ISC), libpcap/tcpdump (BSD-3), Capstone (BSD-3), FreeRTOS (MIT), Zephyr (Apache-2.0), EDK2 (BSD-2-Clause-Patent, per file), Binwalk (MIT).
Tooling and auditing: CodeQL (MIT), sanitizers documentation (LLVM, already held), OSS-Fuzz build scripts (Apache-2.0).
Gap: no licence-clean corpus of real-world CVE patches with root-cause narrative. Where a patch can be paired with its advisory (NVD + vendor advisories), that pairing must be assembled, not acquired.

### 2. C++
Mechanism: object lifetime, vtables and virtual dispatch, RTTI, exceptions and unwinding, templates, RAII, allocators, STL container internals, ABI and name mangling.
Vulnerability classes: virtual call hijacking, type confusion, iterator invalidation, exception-safety bugs, heap grooming against specific allocators.
Sources: Ghidra (Apache-2.0), Capstone, Zephyr, OPA, Falco, LLVM (held).
Practical material: the heap-exploitation literature applies to libstdc++/libc++ allocators and is best taught through how2heap plus allocator source, both available.
Gap: browser and JIT exploitation is the highest-value C++ security topic and has no permissive corpus; Project Zero writeups (Apache-2.0 repository) are the nearest substitute.

### 3. C#
Mechanism: CLR, JIT, assemblies, reflection, P/Invoke, COM interop, WMI, remoting, AppDomains, strong naming, and the Windows API surface it wraps.
Vulnerability classes: deserialization gadget chains, DLL hijacking, unquoted service paths, token manipulation, Kerberos ticket abuse, AMSI bypass patterns.
Sources: GhostPack suite (BSD-3), Seatbelt, Certify, Rubeus, Empire (BSD-3, conditional), VS Code's C# extension surface is not relevant.
Practical material: .NET runtime source (MIT) is already held at 119,312,899 tokens and gives the runtime semantics these tools abuse.
Gap: no licence-clean corpus of real .NET malware; the attack tooling is present, the malicious samples are not, and that is the correct trade.

### 4. Go
Mechanism: goroutines and channels, the runtime scheduler, interface dispatch, `unsafe`, cgo boundaries, static binaries and their symbol tables, module supply chain.
Vulnerability classes: race conditions, path traversal in filepath handling, SSRF via HTTP clients, template injection, insecure TLS configuration, dependency confusion.
Sources: kube-bench, Trivy, Grype, Syft, Prowler, OPA, kube-hunter, Kubernetes source (held), Traefik-class proxies.
Practical material: Go is the dominant language of cloud-native security tooling, so its security value is as much "how security tools are built" as "how Go fails".
Gap: Go-specific vulnerability writeups are scattered and mostly blog-licensed.

### 5. Rust
Mechanism: ownership and borrowing, lifetimes, `unsafe` blocks, FFI, trait objects, panic and unwinding, async runtimes.
Vulnerability classes: unsound `unsafe`, integer overflow in release mode wrapping, TOCTOU in `std::fs`, denial of service via allocation, supply-chain attacks through build scripts.
Sources: Binwalk (MIT), Rust compiler and standard library (held), Rust Reference and Nomicon (dual MIT/Apache-2.0).
Security value: Rust is the contrast case. A model that understands why a Rust parser resists the bug classes a C parser suffers can reason about memory safety as a property rather than a checklist.
Gap: few security tools in Rust are permissively licensed; most are GPL.

### 6. Python
Mechanism: the object model, descriptors, import machinery, GIL, pickle, subprocess and shell interaction, ctypes, asyncio, virtual environments and packaging.
Vulnerability classes: unsafe deserialization (pickle, yaml.load), command injection, path traversal, SSTI in Jinja2, dependency confusion, ReDoS.
Sources: Impacket, Pacu, PKINITtools, angr, pwndbg, Plaso, Checkov, FLOSS, capa, OTRF, Exploit-tooling ecosystem — the richest permissive security-tooling language by far.
Practical material: this is where the model learns what security tooling looks like from the inside, including argument parsing, output formatting and error handling that real tools use.
Gap: CPython source is held; what is missing is analysis of vulnerable Python applications, which must come from labs.

### 7. Java
Mechanism: JVM, class loading, bytecode, reflection, serialization, JNDI, RMI, deserialization gadget chains, Spring and servlet lifecycles, Android's ART.
Vulnerability classes: deserialization RCE, JNDI injection (Log4Shell class), expression-language injection, XXE, unsafe reflection, insecure random.
Sources: Kafka, OpenSearch, Ghidra, apktool, jadx, Tink (all Apache-2.0).
Practical material: apktool and jadx double as both Java codebases and mobile-analysis tooling, which is efficient.
Gap: enterprise Java vulnerability research is well documented publicly but almost entirely in non-permissive conference material.

### 8. JavaScript
Mechanism: the event loop, closures, prototypes, `this` binding, the module system, the V8 object model, browser security model (SOP, CORS, CSP), Node's fs/net/child_process.
Vulnerability classes: prototype pollution, XSS and DOM clobbering, SSRF, command injection, ReDoS, path traversal, insecure JWT handling, dependency compromise.
Sources: Juice Shop (MIT), VS Code (MIT), Home Assistant (Apache-2.0), OpenCTI (Apache-2.0), Node.js (held).
Practical material: Juice Shop is the best single artefact here — a vulnerable application whose challenges map onto the OWASP classes with working exploits.
Gap: no permissive corpus of real-world XSS/SSRF disclosures.

### 9. TypeScript
Mechanism: structural typing, type erasure at runtime, declaration files, module resolution, decorators, and the fact that types provide no runtime safety.
Vulnerability classes: the same runtime classes as JavaScript, plus false confidence from typing: `any` casts across trust boundaries, unsound type assertions, unvalidated external data.
Sources: VS Code, Juice Shop, OpenCTI, Checkov's TypeScript components.
Practical material: TypeScript is where modern security dashboards and tooling front-ends are written; the corpus should prefer security products over generic apps.
Gap: as JavaScript.

### 10. PowerShell
Mechanism: the object pipeline, cmdlets and parameters, providers, remoting (WinRM), WMI/CIM, .NET interop, execution policy, AMSI, transcription and logging, constrained language mode.
Vulnerability classes: execution-policy bypass, AMSI bypass, credential access, lateral movement, fileless execution, logging evasion, and — for defence — the log evidence each leaves behind.
Sources: PowerSploit (BSD-3), MicroBurst (BSD-3), Atomic Red Team (MIT), PowerShell documentation (held), Empire (BSD-3, conditional).
Practical material: this is the single most important language for DFIR realism, because most Windows incident response is PowerShell plus log interpretation.
Gap: the best offensive PowerShell (Nishang, Empire modules) is GPL or aggressive dual-use; the licence-clean subset is smaller than the domain needs.

### 11. Shell / Bash
Mechanism: process creation, pipes and redirection, signals, job control, quoting and word splitting, globbing, environment and PATH, setuid interaction, cron and systemd units.
Vulnerability classes: command injection, argument injection, PATH hijacking, unsafe eval, symlink attacks, TOCTOU in scripts, insecure temporary files, shellshock-class parsing bugs.
Sources: FreeBSD userland (held), Kubernetes and container tooling scripts, Vulhub compose files, Atomic Red Team command lines, documentation across all acquired repos.
Practical material: shell is the language of the incident timeline. The value is less in shell *programs* than in shell *sessions*, which is a lab-generation problem, not an acquisition one.

## Language-level allocation within the 25 % code budget

If the code layer is 25 % of a 2.8 B corpus (700 M tokens), the split should follow security value rather than market share:

| Language | Share of code layer | Tokens at 700 M |
|---|---|---|
| C | 20 % | 140 M |
| C++ | 14 % | 98 M |
| Python | 15 % | 105 M |
| C# | 10 % | 70 M |
| Go | 10 % | 70 M |
| Java | 8 % | 56 M |
| JavaScript | 7 % | 49 M |
| PowerShell | 6 % | 42 M |
| Shell | 5 % | 35 M |
| Rust | 3 % | 21 M |
| TypeScript | 2 % | 14 M |

The ordering is deliberately not popularity-ordered. Python and C lead because they are where security tooling and memory corruption respectively live. TypeScript is last because its security value is largely inherited from JavaScript and its natural corpus is business applications, which this project excludes.

## Appendix — substitution notes

**PHP**: security value is high (the largest share of real-world web vulnerabilities); permissive corpora are limited, mostly frameworks (Laravel, Symfony, both MIT). **Ruby**: Metasploit is the anchor and it is licence-blocked at file level; Rails is MIT. **Kotlin**: Android surface, Apache-2.0 tooling available. **Swift**: iOS, but almost no licence-clean iOS security material exists. **Assembly**: already inside the C/C++ allocation via disassembly output and EDK2/FreeBSD; treat as a cross-cutting skill, not a separate budget line. **SQL**: injection semantics are best taught through vulnerable applications and database engine source (PostgreSQL, held).
