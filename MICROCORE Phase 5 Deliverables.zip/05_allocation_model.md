# Deliverable 5 — Token Allocation Model

Two columns are given throughout: the allocation **if** 5 B is reached, and the allocation at the **realistic 2.8 B** corpus that current supply supports. Percentages are identical; only the absolute tokens differ. Fixing the percentages first and the totals second is deliberate — it prevents a large source from redefining the mixture.

## Top-level allocation

| Layer | Share | At 5 B | At 2.8 B | Rationale |
|---|---|---|---|---|
| Direct security knowledge (reference, standards, vuln intelligence, research) | 30 % | 1.50 B | 840 M | the vocabulary and mechanism a specialist needs; cheapest to acquire, highest certainty |
| Security procedure and tool-use (labs, recordings, worked investigations, detection authoring) | 15 % | 750 M | 420 M | where models fail most; only partly acquirable, largely generatable |
| Security-relevant code (11 languages) | 25 % | 1.25 B | 700 M | mechanism and tool-building, capped |
| Systems, network, crypto foundations | 20 % | 1.00 B | 560 M | substrate; already largely held |
| Enterprise/cloud/identity operational material | 10 % | 500 M | 280 M | closes the AD/cloud gap |

Security-direct plus procedure is 45 %; adding security-relevant code brings security-attributable content to 70 %.

## Domain allocation

| Domain | Share | At 5 B | At 2.8 B | Primary sources | Coverage | Risk of over-representation |
|---|---|---|---|---|---|---|
| Vulnerability intelligence and advisory data | 8 % | 400 M | 224 M | NVD, KEV, Vulnrichment, GitHub Advisory | strong | low-value repetition; needs field-level dedup |
| Standards, frameworks, hardening guidance | 7 % | 350 M | 196 M | NIST, DISA (conditional), ATT&CK, Sigma spec | partial | compliance boilerplate crowding out technique |
| Offensive operations and AD attack paths | 8 % | 400 M | 224 M | Impacket, GhostPack, Pacu, MicroBurst | partial | dual-use skew; must be balanced by defence |
| Vulnerability research and exploit development | 9 % | 450 M | 252 M | Project Zero, MSRC, how2heap, MBE, kernel index | partial | exploitation without defence; cap at 9 % |
| Reverse engineering and binary analysis | 6 % | 300 M | 168 M | Ghidra, Capstone, angr, pwndbg, FLOSS, Binwalk | strong | tool code dwarfing technique; cap by language |
| Malware analysis and detection content | 7 % | 350 M | 196 M | capa-rules, Splunk content, ATT&CK, OTRF | partial | rule duplication across vendors |
| Detection engineering and telemetry | 6 % | 300 M | 168 M | Splunk, Falco, Sigma spec, Zeek, kube-bench | strong | YAML volume inflating token count |
| DFIR and incident response | 6 % | 300 M | 168 M | Plaso, KapeFiles, OTRF, generated cases | partial | logs repeating; requires shingle filtering |
| Web, API and application security | 7 % | 350 M | 196 M | Juice Shop, NodeGoat, CodeQL, ToB handbook | partial | tutorial-level material |
| Cloud, container and IaC security | 7 % | 350 M | 196 M | Checkov, Trivy, OPA, Falco, Prowler, Pacu, k8s | partial | generic Kubernetes manifests |
| Enterprise identity (AD, Entra, Kerberos) | 6 % | 300 M | 168 M | Impacket, entra-docs, Win32 docs, Certify | strong | protocol code over narrative |
| Mobile, firmware, IoT, hardware | 6 % | 300 M | 168 M | EDK2, Zephyr, FreeRTOS, jadx, apktool, ChipWhisperer | partial | large firmware code, thin analysis |
| Cryptography and mathematics | 5 % | 250 M | 140 M | libsodium, BoringSSL, mbedTLS, Tink, NIST | strong | implementation detail over design reasoning |
| Security tooling and workflow engineering | 5 % | 250 M | 140 M | tool repos across all domains | partial | CLI boilerplate |
| General systems and networking foundations | 7 % | 350 M | 196 M | FreeBSD, LLVM, PostgreSQL, OpenSSL, Node, curl | strong (held) | already 56 % of current corpus — must be sampled down |

## How the allocation is enforced

The allocation is a **sampling instruction**, not an aspiration. For each domain the pipeline computes measured availability, then samples down to the allocation with a fixed seed and records the seed and the sampling ratio in the manifest. If a domain cannot fill its allocation, the deficit is recorded as a gap rather than silently redistributed to a domain with surplus — which is how a security corpus turns into a code corpus.

Three hard caps sit above the domain table:

| Cap | Value | Reason |
|---|---|---|
| Any single repository | 5 % of corpus | LLVM at 375 M would otherwise be 13 % of a 2.8 B corpus |
| Any single publisher | 12 % | prevents Microsoft or Google from dominating |
| Any single language | 20 % of code layer | C and C++ would otherwise absorb the layer |
| Synthetic or generated content | 20 % of corpus | beyond that, the model learns its own generator's habits |
| Non-security application code | 5 % of corpus | UI, CRUD and business logic excluded by design |

## What this allocation costs

At 2.8 B the corpus is 70 % security-attributable, against roughly 3 % today. That is the redesign's actual achievement, and it is achievable with the sources in Deliverable 3 plus moderate lab generation. At 5 B the same percentages require 1.5 B of direct security knowledge and 750 M of procedure — and the measured supply of the first is roughly 600–900 M, the second perhaps 300 M before generation. The gap is therefore concentrated in exactly the two layers that matter most, which is why Deliverable 11 concludes what it does.
