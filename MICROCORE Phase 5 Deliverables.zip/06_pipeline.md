# Deliverable 6 — Acquisition and Deduplication Pipeline

Designed for the constraint that actually exists: two T4 GPUs on Kaggle for training, and a working environment with a few gigabytes of disk. The pipeline must therefore be **streaming and incremental**, able to run a source at a time, and able to stop and resume without recomputing.

## Stage graph

```
source registry (YAML)
   │
   ├─ 1 fetch ────────────► raw/ (per-source, immutable, hashed)
   │                        record: url, etag/commit, bytes, sha256, date
   ├─ 2 licence gate ─────► per-file decision
   │                        repository licence + file header + allowlist
   │                        output: ADMIT / CONDITIONAL / REJECT + reason
   ├─ 3 relevance gate ───► domain classifier + language classifier
   │                        drop: unrelated app code, generated, vendored, minified
   ├─ 4 quality gate ─────► size, entropy, alpha ratio, line length, duplicates of boilerplate
   ├─ 5 safety gate ──────► PII regex + secret regex + malware quarantine
   │                        quarantine, never execute
   ├─ 6 normalise ────────► encoding, line endings, markup strip, PDF/HTML → text
   ├─ 7 exact dedup ──────► sha256 of normalised content
   ├─ 8 near dedup ───────► MinHash 128 perms, 5-shingles, bands=16, Jaccard ≥ 0.8
   ├─ 9 tokenize ─────────► cl100k_base (primary), GPT-2 (secondary)
   ├─ 10 allocate ────────► domain × language quota sampling, seeded
   └─ 11 manifest ────────► provenance record, rejection report, build hash
```

Stages 1–2 are cheap and decisive. The rule that follows from hard experience in earlier phases: **never run stage 9 on material that has not passed 2, 3 and 4**, because tokenizing organises the illusion of progress.

## Manifest schema

One JSONL record per admitted document:

```json
{
  "doc_id": "mc:sha256:8f3a…",
  "source_id": "MC-424",
  "source_name": "Impacket",
  "source_url": "https://github.com/fortra/impacket",
  "snapshot": {"type": "git", "commit": "…", "retrieved": "2026-11-27"},
  "path": "impacket/examples/secretsdump.py",
  "lang": "python",
  "domain": ["enterprise-identity", "offensive"],
  "licence": {"repo": "BSD-3-Clause", "file": "BSD-3-Clause", "decision": "ADMIT",
              "evidence": "LICENSE, 8376 B, sha256 …", "attribution": "Fortra"},
  "quality": {"bytes": 41233, "alpha": 0.41, "max_line": 118, "generated": false, "vendor": false},
  "safety": {"pii": false, "secrets": false, "quarantined": false},
  "dedup": {"exact": false, "cluster": "…", "jaccard_max": 0.12},
  "tokens": {"cl100k": 9114, "gpt2": 10233},
  "build": "b5.3"
}
```

One record per rejected file too, with `decision` and `reason`, so the rejection report is a first-class artefact rather than a log line.

A per-source summary record accompanies it: files seen, admitted by licence, admitted by quality, rejected by category, exact duplicates, near duplicates, PII hits, secrets quarantined, eligible bytes, cl100k, GPT-2.

## Deduplication

Three tiers, matching the Phase 4 design and carrying forward its measured parameters:

**Exact**: sha256 of normalised text (LF, no trailing spaces, BOM stripped, HTML/markup reduced to text). O(1) per document, and it catches the largest real duplication — the same file vendored into many repositories and the same document republished across vendor doc trees.

**Near**: 128-permutation MinHash over 5-word shingles, 16 bands × 8 hashes, confirmed with Jaccard ≥ 0.8. Bands live in a plain key-value index on disk; at a few million documents this fits in memory. Code-aware variant: tokenise identifiers to a normal form before shingling (drop comments, normalise whitespace) so that reformatted copies collide.

**Cross-source semantic**: applied only as a sampling audit, not as a dedup pass. Embedding clustering of a stratified 1 % sample gives an estimate of residual duplication, which is reported as an estimate and absorbed into the safety margin.

Benchmark decontamination is a fourth, separate mechanism: every evaluation item is hashed and its 13-gram fingerprints are blocked from the training set before tokenization. This must be a hard filter, not a post-hoc check.

## Storage and compute budget

| Stage | Peak disk | CPU | Notes |
|---|---|---|---|
| fetch (per source) | source size × 1.2 | minutes | delete after stage 8 unless it is a reference copy |
| licence + quality gates | negligible | minutes per 10 k files | streaming |
| PDF/HTML extraction | source size | hours for NIST-scale PDF sets | batch, resumable |
| near dedup | 0.5 KB per doc | hours at 1 M docs | index on disk |
| tokenization | negligible | ~1 hour per 100 MB of text | cl100k at ~2 MB/min per core |
| full build at 2.8 B | ~300 GB scratch | 200–400 CPU-hours | compatible with incremental runs |

The Kaggle allocation (30 GPU-hours/week) is a *training* constraint and does not bound acquisition, which is CPU-only. Acquisition can run on any available machine; the only hard requirement is scratch disk for the near-dedup index and the tokenized shards.

## Implementation priorities

1. **Registry + manifest + rejection report** — without these, nothing is auditable, and the audit trail is the project's legal defence.
2. **Licence gate with per-file headers** — the single highest-risk component; EDK2 and Impacket both require it.
3. **Exact dedup + tokenizer** — gives trustworthy per-source yields immediately.
4. **Safety gate** — before any malware-adjacent or credential-adjacent source.
5. **Near dedup** — only needed once the corpus exceeds ~500 M tokens.
6. **Allocation sampler** — last, because it depends on knowing measured availability per domain.

## Calibration rule

No source is ingested at full size before a calibrated sample. The rule used in Phase 4 and retained here: take 2,000 files or 0.5 % of the source, whichever is smaller, run all eleven stages, and report the admit rate, the duplicate rate and the tokens per MB. If the projected contribution changes the plan materially, measure at 5 % before committing.

## Reproducibility

Every build records: source registry hash, per-source snapshots (commit or ETag), filter version, tokenizer version, sampling seed, and the final manifest hash. A rebuild from the registry and the snapshot list must reproduce the same token count to within zero, which is achievable because tokenization is deterministic and sampling is seeded.
