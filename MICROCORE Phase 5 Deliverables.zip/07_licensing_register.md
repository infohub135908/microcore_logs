# Deliverable 7 — Licensing and Provenance Register

All checks performed 2026-11-27. Method: fetch the licence file from the repository at its default branch and read its text; where a repository publishes several licence files or per-file headers, both were inspected. GitHub's SPDX label alone was never accepted as clearance — several labels in this register disagreed with the file text (Seatbelt labelled Apache-2.0 by classifier while its header says BSD-3-Clause; Rizin's COPYING is GPL text while the project states LGPL-3.0).

## Decision rules applied

**APPROVED** — licence text grants commercial use, redistribution and modification, with attribution at most. Copyleft absent.
**CONDITIONAL** — usable under a stated condition: per-file licence enforcement, a usage agreement, a non-standard but commercial-permitting notice, or evaluation-only use.
**REJECTED** — no licence, copyleft (GPL/AGPL), share-alike (CC-BY-SA), source-available restriction (Elastic, BUSL, Commons Clause, NPSL), or unresolved file-level ambiguity after review.

A source is never approved because it is public, popular, or described as open source. The register records the evidence, not the reputation.

## What the 74 sources resolved to

| Decision | Count | Notes |
|---|---|---|
| APPROVED | 48 | includes 10 measured in this phase |
| CONDITIONAL | 13 | per-file enforcement, evaluation-only, or terms not yet read |
| REJECTED | 13 | copyleft, share-alike, source-available, or no licence |

## Rejected, with exact reasons

| Source | Licence evidence | Reason |
|---|---|---|
| Elastic detection-rules | LICENSE.txt, 3,858 B, Elastic License 2.0 | source-available; restricts providing as a service |
| SigmaHQ rules | LICENSE: rules under DRL 1.1 | restricts commercial use and derivatives |
| HackTricks | no licence file in the tree | no rights granted |
| OWASP Cheat Sheets | CC-BY-SA-4.0 | share-alike propagates to the corpus |
| OWASP WSTG | CC-BY-SA-4.0, 20,129 B | same |
| Velociraptor | AGPL-3.0, 26,863 B | network copyleft |
| MobSF | GPL-3.0, 35,134 B | copyleft |
| Chainsaw | no licence file | no rights granted |
| Nishang | GPL-3.0, 1,128 B | copyleft |
| bettercap | GPL-3.0, 35,187 B | copyleft |
| AFL++ | AGPL-3.0, 34,523 B | copyleft |
| semgrep-rules | LGPL-2.1 + Commons Clause, 1,042 B | Commons Clause forbids commercial resale |
| Terraform | BUSL-1.1, 4,950 B | restricts competing use; not open source |

## Conditional, with the condition stated

| Source | Condition |
|---|---|
| **EDK2** | no single top-level licence file located; every file carries its own BSD-2-Clause-Patent header. Admissible only if the pipeline reads headers per file and drops any file whose header is absent or different. |
| **Seatbelt** | LICENSE contains both Apache-2.0 and a BSD-3-Clause statement; per-file resolution required |
| **ChipWhisperer** | LICENSE.txt notes third-party files under other terms; per-file check required |
| **DISA STIGs** | public.cyber.mil reachable, but the site's terms of use and distribution statement have not been read. Not admissible until they are. |
| **IETF RFCs** | IETF Trust legal provisions retain copyright and grant limited reproduction; not a permissive licence. Legal read required. |
| **Nmap (NPSL)** | NPSL restricts redistribution of modified versions; legal read required |
| **radare2 (LGPL-3.0)** | weak copyleft: file-level compliance burden; prefer Capstone/Ghidra instead |
| **Cybench, PurpleLlama, NYU CTF Bench, InterCode** | evaluation-only; must never enter training |
| **Empire** | BSD-3-Clause but C2 tooling; inclusion needs editorial review, not a licence question |
| **SecLists** | MIT, but contains real credential lists; training on it would encode breached passwords |
| **Metasploit** | BSD-3-Clause at repo level; substantial per-file variation unresolved — the same finding as the earlier rejection |
| **kube-bench** | code is Apache-2.0; the CIS benchmark *text* it implements is licensed separately and is not redistributable |

## Approved sources that still carry obligations

**CC-BY-4.0** (Trail of Bits Testing Handbook, xairy kernel index, MSRC Security Research, Kubernetes website, Microsoft docs): attribution plus an indication of modifications. Because tokenization, filtering and deduplication are modifications, every corpus release must state them and carry a NOTICE listing the sources.

**MIT / BSD / ISC / Apache-2.0**: reproduce the copyright notice and, for Apache-2.0, the NOTICE file where one exists. Apache-2.0 additionally carries a patent grant, which is an advantage for commercial use.

**ATT&CK**: a custom MITRE notice permits research, development and commercial use provided the copyright designation and licence are reproduced. This is broader than commonly assumed and is why ATT&CK is APPROVED rather than quarantined.

**US Government works** (NIST, CISA KEV, NVD): public domain under 17 U.S.C. §105; attribution is courtesy, not obligation. Each document's provenance is still recorded per item.

## Unresolved legal questions

1. **Does the DISA site agreement permit corpus inclusion?** The terms are behind a usage statement that has not been read. Until then, DISA material contributes zero.
2. **Are RFC texts usable?** The IETF Trust licence permits quotation and reproduction in limited forms; a corpus is arguably outside that. Needs a written opinion.
3. **Is the NPSL compatible?** Nmap's licence is GPL-like with an added restriction on modified redistribution. If MICROCORE's tooling never redistributes Nmap, the restriction may be irrelevant; the code being redistributed inside a corpus is a different question.
4. **What satisfies "indication of changes" for CC-BY content inside a tokenized corpus?** The proposed answer — a NOTICE plus a documented transformation record — has not been tested.
5. **Does the Llama Community Licence permit evaluation-only use of CyberSecEval by a non-Llama model?** Assumed yes for evaluation, never for training.
6. **Is attribution per file or per repository?** The register assumes per source plus per `repo_path` in the manifest, which is stronger than most licences require and therefore safe.

## Provenance requirements

Every corpus build must ship: the source registry, the per-file manifest (source, snapshot, path, licence, decision, tokens), the rejection report, the filter version, the tokenizer version and the sampling seed. Anything less makes attribution unverifiable and the corpus indefensible.
