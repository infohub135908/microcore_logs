# Deliverable 8 — Gap Analysis

Measured against the twelve required coverage domains (A–L) and the eleven-language coding layer. "Gap" means: the capability described is not reachable from sources that are both licence-clean and currently measured. Where a gap could be closed by generation, that is stated separately, because generated material has a different evidential status.

## Domain gaps

| Domain | Status | What exists | What is missing | Closing route |
|---|---|---|---|---|
| A. Offensive operations | **partial** | Impacket, GhostPack, Pacu, MicroBurst, atomic-red-team — mostly tool code | narrative reasoning about attack paths; engagement-level tradecraft | generate from lab walkthroughs; unpaid but high-value write-ups remain unlicensed |
| B. Vulnerability research / exploit dev | **partial** | how2heap, MBE, Project Zero, MSRC, xairy index (CC-BY) | modern mitigations (CFG, CET, MTE); heap internals across allocators | deep technical reading of write-ups; licence-by-licence |
| C. Reverse engineering | **strong** | Ghidra 30.1 M, Capstone, angr, pwndbg, FLOSS, Binwalk | dynamic instrumentation, symbolic execution at scale, anti-analysis | adequate; no acquisition required |
| D. Malware analysis | **partial** | capa + rules, OTRF Security-Datasets 0.25 M, Splunk content | family-level analysis reports; unpacking narratives; behavioural ontologies | ATT&CK + generated cases; real samples quarantined and never trained on |
| E. Defensive / detection | **strong** | Splunk security_content 4.96 M, Falco, Sigma spec, Zeek, kube-bench | Sigma rules lost to DRL; Elastic lost to ELv2 | write equivalent rules as generated content |
| F. DFIR | **partial** | Plaso, KapeFiles, OTRF | end-to-end investigations; timeline reasoning; memory forensics (Volatility GPL) | case-based generation from public incident reports |
| G. OS / enterprise / identity | **strong** | entra-docs 11.7 M, Win32 docs, Impacket, Certify, Rubeus | Entra ID conditional access depth; hybrid identity failure modes | Microsoft Learn ingestion under CC-BY-4.0 |
| H. Network / protocol | **strong** | Wireshark docs, tcpdump, libpcap, Zeek, RFCs (conditional) | packet-level analysis traces; protocol fuzzing campaigns | generate from PCAPs (must verify licensing of capture corpora) |
| I. Cloud / containers / IaC | **strong** | Checkov 4.5 M, Trivy, OPA 9.4 M, Prowler, Falco, kube-bench, k8s docs | control-plane attack paths; cloud IAM reasoning; Terraform lost to BUSL | generate; use provider docs under their own licences |
| J. Web / API / appsec | **partial** | Juice Shop 3.2 M, NodeGoat, CodeQL 14.1 M | OWASP prose lost to CC-BY-SA; API-specific abuse cases | generate; CodeQL queries carry the query-language semantics |
| K. Mobile / firmware / IoT / hardware | **partial** | EDK2 (conditional), Zephyr, FreeRTOS, jadx, apktool, ChipWhisperer | actual firmware images; baseband; side-channel measurement data | narrow; largely unacquirable under clean licences |
| L. Cryptography | **strong** | libsodium, BoringSSL, mbedTLS, Tink, NIST SP 800 | protocol-level attack reasoning; side-channel analysis | NIST + generated analysis |

Six domains are strong, six partial, none empty. The partials cluster where the best material is either prose written by practitioners with no licence (offensive, exploit dev, DFIR case work) or copyleft tooling (Volatility, Radare2, MobSF).

## Language gaps (code layer)

| Language | Supply | Gap |
|---|---|---|
| C | strong | none; risk is over-supply |
| C++ | strong | none; Ghidra/LLVM dominate, so cap needed |
| Python | strong | none; cap at 15 % |
| Go | strong | none; cloud/IaC tooling supplies it |
| C# | moderate | GhostPack, Certify, Rubeus; thin on modern .NET |
| PowerShell | moderate | PowerShell-Suite scripts, but narrative use is scarce |
| Java | moderate | jadx, apktool, Tink; thin on enterprise appsec |
| JavaScript | moderate | Juice Shop, NodeGoat; thin at scale |
| TypeScript | **weak** | CodeQL is the main source; little else licence-clean |
| Shell | moderate | widespread but low information density |
| Rust | **weak** | no significant licence-clean security Rust corpus found |

Rust and TypeScript are the two genuine language gaps. Neither can be filled by inventing repositories.

## Capability gaps that no acquisition closes

1. **Interactive tool use.** Running a debugger, pivoting in a network, triaging a live alert — this is trajectory data, and essentially none exists under a clean licence. It must be generated in a lab.
2. **Reasoning under uncertainty.** Real investigations contain ambiguity; documents do not. Generated cases can approximate it, but the approximation is a modelling choice, not a measurement.
3. **Novel exploitation.** No corpus teaches this; it emerges, if at all, from depth in B and C.
4. **Enterprise-scale telemetry.** Production logs are never public. OTRF is the closest substitute and is three orders of magnitude too small.

## Honest summary

The corpus can make MICROCORE strong in reverse engineering, detection engineering, cloud/IaC, identity, networking, and cryptography — six of twelve domains. It can make it adequate in offensive operations, exploit development, malware analysis, DFIR, web security and firmware. It cannot make it a substitute for hands-on adversarial experience, and no amount of additional licence-clean text will change that.

The largest single gap is not a domain but a layer: **security procedure**. Roughly 15 % of the intended mixture has no measured supply at all.
