# Deliverable 9 — Cybersecurity Benchmark Plan

Evaluation is separate from training by rule. Every item below is excluded from the corpus and hashed into the decontamination blocklist before any build.

## External benchmarks

| Benchmark | Licence | Format | Measures | Contamination risk | Use |
|---|---|---|---|---|---|
| **Cybench** ([cybench](https://github.com/andyzorigin/cybench)) | Apache-2.0, 11,357 B verified | 40 CTF tasks across 4 competitions, agent-style | autonomous multi-step offensive problem solving | measured at 6,815,878 cl100k in this phase — already in hand, so its exclusion must be enforced, not assumed | primary capability benchmark |
| **CyberSecEval** (PurpleLlama) | Llama 3.2 Community Licence; evaluation use | insecure-code generation, cyberattack helpfulness, prompt injection | propensity to produce vulnerable code; refusal behaviour | licence forbids training use, which conveniently forces separation | safety and secure-coding |
| **NYU CTF Bench** | GPL-2.0 | 200 CTF challenges with Docker environments | challenge solving with execution | GPL means eval-only; never merged into corpus | held-out, cross-benchmark |
| **InterCode** (cybersecurity variant) | MIT, 1,093 B verified | interactive shell environments | command-level task completion | low | tool-use proxy |
| **SecBench / SecEval** | unverified | MCQ over security knowledge | recall of facts and standards | moderate | knowledge floor, not capability |

Cybench is the anchor. It is the only benchmark here that requires the model to *do* something, and it is licence-clean for evaluation.

## Internally developed evaluations

Because the external set is small and largely offensive-CTF-shaped, four internal evaluations are specified. Each is built from held-out material captured during acquisition, before it enters any build.

**1. Detection authoring.** Given a described adversary behaviour, produce a detection rule for Splunk, Falco and Zeek. Scored by whether the rule parses and whether it fires on a synthetic positive and stays silent on a synthetic negative. Source material: Splunk security_content stories held out at 10 %.

**2. Vulnerability triage.** Given an advisory and a code excerpt, decide reachability and severity. Scored against NVD and GitHub Advisory labels held out from the corpus. This is the benchmark that measures whether the model has learned *judgement* rather than vocabulary.

**3. Binary analysis.** Given a stripped binary built from a held-out source file, identify the algorithm or the vulnerability. Built from Ghidra and Capstone test material plus compiled samples from held-out code. Scored by exact classification.

**4. Incident reconstruction.** Given a synthetic timeline of host and network events, identify the initial access vector and the persistence mechanism. Generated scenarios, so the ground truth is known by construction — and the limitation must be stated: models can pass generated scenarios by learning the generator.

## Reporting rules

Results are reported per benchmark with the corpus build hash, because a benchmark score is meaningless without the corpus it was trained on. No benchmark result is reported for a model that saw its items; the decontamination filter runs before tokenization and its blocklist is published with the build.

Contamination checks are two-sided: exact 13-gram match against the blocklist, and a semantic check on a 1 % sample using embeddings, reported as an estimate.

## What these benchmarks cannot show

None of them measures whether MICROCORE is *safer* to deploy, only whether it is more capable. Safety behaviour is measured by CyberSecEval's refusal and insecure-code suites plus a red-team review that is not a benchmark. The two must not be conflated in any report.
