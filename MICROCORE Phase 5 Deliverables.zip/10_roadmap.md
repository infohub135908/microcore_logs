# Deliverable 10 — Phased Acquisition Roadmap

Tokens shown as incremental gross contributions, before global deduplication. Every figure marked *projection* is extrapolated from measured per-source yields and is not a measurement.

## Starting position

| Item | Tokens (cl100k) | Evidence |
|---|---|---|
| Carried-forward measurements (Phases 2–4) | 1,812,199,722 | measured, **pre-deduplication, provisional** |
| Phase 5 measured, training-eligible | 40,265,955 | measured this phase |
| Phase 5 measured, evaluation-only (excluded) | 6,815,878 | measured, Cybench — never trained on |
| Global cross-source deduplication | not performed | — |

The 1.812 B figure must not be described as unique until Stage 7 runs.

## Stages

**Stage 1 — Infrastructure (weeks 1–3).** Registry, manifest schema, rejection report, licence gate with per-file headers, safety gate, exact dedup, tokenizer. No new tokens. This stage is a prerequisite for everything and is the cheapest part of the plan.

**Stage 2 — Re-ingest what is already measured (weeks 3–5).** Re-run the 38 measured sources through the new pipeline. Expected: 1.85 B gross re-measured, with 12–20 % rejected at the licence or quality gate (*projection*). This is where the provisional figure is first tested.

**Stage 3 — Tier A code and tooling (weeks 5–9).** Impacket, GhostPack, Pacu, MicroBurst, pwndbg, angr, Capstone, FLOSS, Binwalk, Plaso, KapeFiles, OTRF, Project Zero, MSRC, Google security-research, kube-hunter, Prowler, Trivy, Grype, Syft, Gatekeeper, Terrascan, OpenCTI, apktool, jadx, NodeGoat, PKINITtools, adidnsdump, vulhub, how2heap, SecLists (credentials excluded). **≈ 320 M** (*projection*).

**Stage 4 — Reference corpora (weeks 7–12).** NIST SP 800 series and CSF, CISA KEV, NVD 2.0 historical feeds, GitHub Advisory, Vulnrichment, ATT&CK STIX + docs, Sigma specification, MITRE Engenuity material where licensed, Microsoft Learn, FreeBSD docs, Kubernetes docs, Wireshark docs, RFC subset pending legal read. **≈ 210 M** (*projection*).

**Stage 5 — Firmware and embedded (weeks 10–14).** EDK2 with per-file header enforcement, Zephyr, FreeRTOS, mbedTLS, ChipWhisperer (conditional), libsodium, Tink, BoringSSL. **≈ 180 M** (*projection*).

**Stage 6 — Generated procedure and lab data (weeks 10–20, parallel).** Detection authoring from held-out Splunk stories; triage cases from held-out advisories; timeline reconstructions; secure-code-review pairs across the eleven languages. **≈ 250 M**, capped at 20 % of corpus. Evidence category: generated, not measured. Quality gate: every generated item must pass a validity check (rule parses, case is internally consistent) and must be labelled in the manifest.

**Stage 7 — Global deduplication and allocation (weeks 18–22).** Exact + MinHash across the entire corpus, then quota sampling to the Deliverable 5 allocation. This is the first point at which a defensible unique total exists.

**Stage 8 — Final build and audit (weeks 22–24).** Freeze, hash, publish manifest, rejection report, NOTICE file, decontamination blocklist.

## Dependencies and gates

| Gate | Blocks | Criterion |
|---|---|---|
| G1 licence gate validated on 5 sources with per-file variation | Stages 3–6 | zero unresolved files |
| G2 dedup index built | Stage 7 | index covers all documents |
| G3 allocation sampler calibrated | Stage 8 | no domain exceeds its cap |
| G4 legal read on DISA, IETF, NPSL | Stage 4 inclusion | written decision per source |
| G5 decontamination filter | any build | Cybench and internal evals blocked |

## Resource requirements

| Resource | Stage 7 requirement | Available |
|---|---|---|
| Scratch disk | ~300 GB | not available in this environment (5.1 GB free); must run on external storage |
| CPU | 200–400 core-hours | feasible on any 8-core machine over 3–4 weeks |
| RAM | 16 GB for near-dedup at 3 M docs | feasible |
| GPU | none for acquisition; training separate | Kaggle 2×T4, 30 h/week |

Storage, not compute, is the binding constraint for Stage 7 and it is unresolved.

## Realistic completion

Stages 1–6 plus Stage 7 at 2.5 B unique is a 20–24 week programme at one person's part-time effort, assuming legal reads conclude favourably on DISA and IETF. Reaching 5 B is not in this roadmap because the sources to fill it do not exist under clean licences — see Deliverable 11.
