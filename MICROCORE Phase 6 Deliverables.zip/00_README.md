# MICROCORE Phase 6 — Global Discovery, Acquisition and Unique Token Expansion

Thirteen deliverables. All licence and access checks dated 2026-11-27.

## Headline

| Metric | Value |
|---|---|
| Candidates investigated | **135** (61 new this phase) — 90 approved, 19 conditional, 26 rejected |
| Newly measured | **30 repositories, 442,750,324 cl100k** (434,731,317 net of one duplicate) |
| Largest single find | Azure/Azure-Sentinel, 108,063,051 tokens of detection logic |
| Largest dataset find | GitHub advisory-database, 217,435,658 tokens |
| Academic pool found | arXiv cs.CR CC-BY: 22.5 % of 54,934 papers, ~150 M projected |
| Exact duplication measured | 1.628 % across 61,211 files (not a global rate) |
| Baseline | 1,852,465,677 gross, reconciled, still not globally deduplicated |
| Revised ceiling | **2.08 / 2.66 / 3.03 B** (conservative / realistic / optimistic) |
| Gap to 5 B | 2.34 B realistic |

Phase 5 said 2.49 B. That was too low, and this phase shows why: one repository contained more detection content than the entire previous security corpus, and one sampling decision (arXiv's default licence) had hidden a 150 M-token CC-BY pool.

## Deliverables

| # | File | Contents |
|---|---|---|
| 1 | `01_baseline_audit.md` | Phase 1–5 reconstruction; the chain reconciles to the token; two variances documented |
| 2 | `02_discovery_register.md` | 135 candidates, how the 61 new ones were found |
| 3 | `03_top50.md` | ranked incremental opportunities with value reasoning |
| 4 | `04_access_verification.md` | download evidence, rejection register for 403/502/gated routes |
| 5 | `05_licensing_register.md` | decisions, evidence, obligations, unresolved questions |
| 6 | `06_token_yield.md` | measured counts, density analysis, sample-measured arXiv |
| 7 | `07_dedup_overlap.md` | measured exact duplication, four-tier global plan, seven-stage ladder |
| 8 | `08_domain_matrix.md` | A–O coverage, baseline vs new, remaining gaps |
| 9 | `09_languages.md` | eleven-language measured mix and per-language gaps |
| 10 | `10_feasibility.md` | line items, haircuts, three scenarios, routes to 5 B |
| 11 | `11_roadmap.md` | what to acquire next, gates, cost table |
| 12 | `D12_source_inventory.csv` | 135 rows × 34 fields, pipeline-ready |
| 13 | `13_evidence_appendix.md` | URLs, commands, limitations, file list |

## Evidence discipline

Measured, sample-measured, projected, generated and conditional are kept separate in every table. Conditional sources contribute zero. No conditional or projected figure appears inside a measured total. The 1.628 % duplication figure is explicitly bounded to a fifteen-repository subset and is not offered as a global rate.
