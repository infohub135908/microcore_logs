# Deliverable 1 — Existing Corpus Forensic Audit

Reconstructed from the actual measurement files (`p2/out/token_yield.csv`, `p3/out/token_yield_p3.csv`, `p4/data/a_MC-3xx.json`, `p5/data/a_MC-4xx.json`), not from the executive summaries. The published artefacts in [microcore_logs](https://github.com/infohub135908/microcore_logs) match the local records.

## The chain reconciles, with two documented variances

| Phase | Register sum | Reported count | Reconciliation | Verdict |
|---|---|---|---|---|
| 2 | 109,429,097 | 101,738,163 | −5,459,909 duplicate row (MC-105d, pre-dedup Kubernetes variant) −2,179,229 licence-restricted (Sigma 2,009,343 + LOLBAS 169,886) −51,796 deferred (MC-012 OTRF) | **exact** |
| 3 | 1,193,631,552 | 1,193,634,164 implied | 2,612 tokens unaccounted | **variance 0.0002 %** |
| 4 | 566,340,470 (incl. p5 files stored in `p4/data5`) | 516,827,395 | −47,081,833 (the ten Phase 5 files, counted there) −2,431,242 (osquery, disqualified) | **exact** |
| 5 | 47,081,833 | 40,265,955 | −6,815,878 Cybench, evaluation-only | **exact** |
| **Total** | | **1,852,465,677 gross** | | |

The 2,612-token Phase 3 variance is immaterial but is recorded rather than smoothed, because an audit that hides a rounding difference will hide a larger one later.

**The 1.852 B is a sum of source-level measurements. It is not a unique-token count.** No cross-source deduplication has ever been run, and this phase does not change that for the existing material.

## What the 1.852 B actually consists of

| Composition | Tokens | Share | Note |
|---|---|---|---|
| Operating systems, compilers, language runtimes, application frameworks | ~1,040,000,000 | 56 % | LLVM 375.5 M, FreeBSD 292.3 M, pytorch, tensorflow, godot, vscode, spark, home-assistant, OpenSearch, kafka |
| Documentation sets (vendor and project) | ~200,000,000 | 11 % | FreeBSD-doc, Kubernetes, entra-docs, azure-docs, PowerShell-docs |
| Security tooling and security content | ~47,000,000 | 2.5 % | Phase 5 plus ghidra, capa, yara, zeek, tcpdump |
| Vulnerabilities, standards, frameworks | ~20,000,000 | 1 % | NVD, ATT&CK, CWE, CAPEC, KEV |
| Network and web infrastructure code | ~140,000,000 | 8 % | nginx, envoy, OpenSearch, kafka, salt |
| Remaining measured sources | ~405,000,000 | 21 % | spread across phases |

This is the finding that matters more than the total: **the corpus is 2.5 % security content and 56 % general systems and application code.** The Phase 5 architectural critique was correct, and the audit confirms it numerically.

## Source-level disposition

Every row is in `D1_baseline.csv` with phase, ID, source, measured tokens and disposition.

| Disposition | Count | Examples |
|---|---|---|
| Measured and counted | 76 | 16 distinct Phase 2 sources, 23 Phase 3, 27 Phase 4, 9 Phase 5 |
| Measured and excluded | 5 | osquery (policy), Cybench (evaluation), Sigma and LOLBAS (licence), MC-105d (duplicate row) |
| Measured, zero eligible | 1 | Splunk attack_data — landing page accessible, corpus itself is a Git LFS / release artefact that yielded nothing through the tar path |
| Projected, never measured | several | Tier B/C candidates in Phase 3 and 4 registers |
| Rejected | 13 in Phase 5 register plus earlier rejections | HackTricks, Chainsaw, Velociraptor, MobSF, Sigma rules, semgrep-rules, Terraform |
| Gated or unavailable | several | see Deliverable 4 rejection register |

## Overlaps already known and not counted twice

- Kubernetes website documentation sits inside `kubernetes/website`, while Phase 3 counted the Kubernetes source tree; the overlap is terminology, not text.
- FreeBSD documentation duplicates descriptions of code already counted from FreeBSD src.
- Azure documentation (Phase 2, 38.6 M) and entra-docs (Phase 4, 11.7 M) are separate repositories but overlapping product families — an unknown textual overlap.
- PowerShell-docs appears twice: Phase 2 as MC-104 (7.86 M) and Phase 6 as MC-502 (8.02 M, current HEAD). This is the same repository measured twice, five months apart in corpus time. **Only one may be counted.** The Phase 6 measurement supersedes the Phase 2 row and must not be added to it.
- Sigma appears as a rejected source in Phase 5 and as a measured-but-excluded source in Phase 2 — consistent, no double count.

That PowerShell duplication would have added 8.0 M of phantom tokens had it been treated as new. It is the clearest illustration of why Deliverable 7 exists.

## Exclusions that must persist

| Excluded | Reason |
|---|---|
| Cybench (6,815,878) | evaluation-only; Apache-2.0 permits training but using a benchmark as training data destroys the benchmark |
| SigmaHQ rules (2,009,343) | DRL 1.1, non-commercial |
| LOLBAS (169,886) | GPL-3.0 |
| osquery (2,431,242) | user-directed exclusion, Phase 4 |
| HackTricks, OWASP guides, Velociraptor, MobSF, Nishang, bettercap, AFL++, Chainsaw, semgrep-rules, Terraform, Elastic rules | licence refuses commercial corpus use |

## Accounting uncertainties that remain open

1. **Global uniqueness: unknown.** The only honest statement is that 1.852 B gross exists and that the deduplication loss is unmeasured. Phase 5 estimated 10–32 %; that estimate has no empirical basis at corpus scale and is not used as a measurement here.
2. **Within-source duplication is partly unmeasured.** The acquisition pipeline filters exact duplicates per file by path and hash, but near-duplicate detection within very large repositories (LLVM, FreeBSD) has not been run.
3. **The Splunk attack_data row is a measurement failure, not a zero.** It must be re-attempted through the release archive rather than the source tarball.
4. **Phase 3's 2,612-token variance** has no explanation in the record.
5. **Two Phase 2 source boundaries are ambiguous** — azure-docs and PowerShell-docs were measured as Markdown subsets, and the subset definition is not documented precisely enough to reproduce the count.

## Consequence for Phase 6

The baseline is 1.852 B gross, of which roughly 1.80 B is durable and 47 M is security content. Everything Phase 6 adds must clear three tests: new (not a re-measurement), incremental (not overlapping an existing source textually), and accounted in the seven-stage ladder of Deliverable 7.
