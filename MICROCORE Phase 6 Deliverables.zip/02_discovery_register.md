# Deliverable 2 — New Source Discovery Register

135 candidates are recorded in `D12_source_inventory.csv`, up from 74 at the end of Phase 5. Of those, 61 are new in this phase.

| Outcome | Count | Notes |
|---|---|---|
| APPROVED | 90 | licence permits commercial corpus use and the access route works |
| CONDITIONAL | 19 | a specific legal question is open; counted at zero |
| REJECTED | 26 | copyleft, share-alike, no licence, or inaccessible |
| **Total** | **135** | |

Only APPROVED sources appear in the acquisition list. No conditional source is silently counted, which was the failure mode the brief warns about.

## The 61 new candidates, by category

**Security detection and response (12).** Azure Sentinel, OpenBAS, caldera, tracee, tetragon, kyverno, MSRC-Security-Research, D3FEND, nuclei-templates, nuclei, oss-fuzz, google/fuzzing. This is where the phase's largest discovery sits: Sentinel's 108 M tokens of analytics rules and hunting queries is a category the project had not previously touched, and it is licence-clean.

**Cloud, container and supply chain (10).** trivy, grype, syft, cosign, scorecard, dependency-check, amass, zaproxy, osv.dev, cloudfox (rejected — no licence file).

**Vulnerability research (3).** google/security-research, RustSec advisory-db, GitHub advisory-database. The first is genuine original research; the latter two are structured advisory data that overlaps NVD and OSV and must be deduplicated record-wise.

**Firmware and hardware (2).** OP-TEE and Windows driver samples/docs. Neither was previously represented; OP-TEE is the only licence-clean TrustZone implementation available.

**Cryptography (1).** rustls. The only substantial Rust security codebase located.

**Academic and standards (10).** NIST SP 800, NIST CSF, arXiv CC-BY, PLOS, OSTI, DTIC, IETF, DISA, FIRST CVSS, OpenAlex/DOAJ indexes.

**Rejected on licence or access (23).** USENIX, NDSS, Exploit-DB, oss-security, seclists, SANS, CTFtime, VulnHub, MISP, kernel docs, man7, OSDev, DTIC, media.defense.gov, Zenodo (unconfirmed), cvedetails, grep.app, and the Phase 5 carry-overs already refused.

## What the 61 candidates add to the picture

Three things that were not visible at the end of Phase 5:

1. **Detection content is far larger than the project assumed.** Sentinel alone is 108 M and there are sibling repositories (Microsoft 365 Defender hunting queries, ASIM parsers) not yet measured.
2. **Academic CC-BY material exists in usable quantity.** 22.5 % of cs.CR is CC-BY — about 12,360 papers, roughly 150 M tokens. This is new, legally clean, and previously missed because the default arXiv licence is non-exclusive and Phase 5 stopped at that observation.
3. **The best public technical writing is systematically unlicensed.** Every high-value rejection in this phase is a beautiful source with no licence: oss-security, seclists, USENIX, NDSS, Exploit-DB. The pattern is structural, not accidental.

## Register quality

Each row carries the 30 fields the brief specifies: ID, name, publisher, URL, download route, scope, type, domains, languages, licence, licence evidence URL, commercial compatibility, obligations, access status, HTTP result, authentication requirement, size, files, content types, measured tokens, yield class, estimate, quality, duplicate risk, overlap, privacy risk, extraction difficulty, technical value, confidence, priority, decision and rationale. Fields that could not be established say `unknown` or are blank rather than containing a guess.

## The exclusion list carried forward

Seventy-four Phase 1–5 sources remain excluded or already counted, per `D1_baseline.csv`. No Phase 6 row duplicates a previously counted measurement, with one deliberate exception: PowerShell-docs was re-measured to test reproducibility and is flagged as a duplicate rather than added.
