# Deliverable 4 — Source-by-Source Access Verification

All checks performed 2026-11-27. A landing page returning 200 is not treated as access; for repositories the tarball was streamed, and for non-GitHub sources the download route was requested directly.

## Verified accessible and actually downloaded

Twenty-nine repositories were downloaded and tokenized in this phase, not merely listed. Download route in every case: `https://codeload.github.com/{owner}/{repo}/tar.gz/refs/heads/{branch}`, streamed, HTTP 200, no authentication.

| ID | Repository | Branch | Files admitted | Text MB | cl100k |
|---|---|---|---|---|---|
| MC-523 | github/advisory-database | main | 412,537 | — | 217,435,658 |
| MC-503 | Azure/Azure-Sentinel | master | 26,795 | — | 108,063,051 |
| MC-524 | OpenBAS-Platform/openbas | main | 8,425 | — | 14,814,716 |
| MC-504 | projectdiscovery/nuclei-templates | main | 14,826 | — | 10,172,711 |
| MC-529 | microsoft/Windows-driver-samples | main | 2,413 | — | 10,123,742 |
| MC-517 | OP-TEE/optee_os | master | 3,411 | — | 8,013,515 |
| MC-502 | MicrosoftDocs/powershell-docs | main | 3,218 | — | 8,019,007 |
| MC-533 | google/osv.dev | master | 1,228 | — | 7,839,311 |
| MC-509 | kyverno/kyverno | main | 5,215 | — | 6,333,669 |
| MC-520 | anchore/syft | main | — | — | 5,332,529 |
| MC-525 | google/security-research | master | 1,815 | — | 4,545,080 |
| MC-518 | aquasecurity/trivy | main | 2,596 | — | 4,308,615 |
| MC-514 | zaproxy/zaproxy | main | 1,567 | — | 4,120,373 |
| MC-521 | google/oss-fuzz | master | 5,244 | — | 2,813,065 |
| MC-508 | cilium/tetragon | main | 1,445 | — | 2,660,181 |
| MC-516 | owasp-amass/amass | master | 77 | — | 2,595,322 |
| MC-519 | anchore/grype | main | — | — | 1,969,219 |
| MC-507 | aquasecurity/tracee | main | 1,179 | — | 1,908,652 |
| MC-505 | projectdiscovery/nuclei | main | 1,137 | — | 1,530,100 |
| MC-515 | dependency-check/DependencyCheck | main | 896 | — | 1,363,639 |
| MC-512 | ossf/scorecard | main | 1,028 | — | 1,335,896 |
| MC-510 | rustls/rustls | main | 248 | — | 869,341 |
| MC-513 | sigstore/cosign | main | 446 | — | 623,521 |
| MC-511 | RustSec/advisory-db | main | — | — | 529,034 |
| MC-506 | mitre/caldera | master | 246 | — | 408,451 |
| MC-527 | trailofbits/testing-handbook | main | 196 | — | 353,463 |
| MC-528 | xairy/linux-kernel-exploitation | master | 1 | — | 81,015 |
| MC-522 | google/fuzzing | master | — | — | 47,413 |
| MC-531 | microsoft/MSRC-Security-Research | master | 6 | — | 3,075 |
| MC-530 | MicrosoftDocs/windows-driver-docs | staging | 14,479 | — | 14,536,960 |

Totals: **442,750,324 cl100k** measured across these 30 sources, of which 8,019,007 is the PowerShell-docs re-measurement and is excluded from incremental accounting.

## Verified accessible, not measured

| Source | Direct route | Status |
|---|---|---|
| NIST SP 800 series | csrc.nist.gov publication pages, PDF links | 200, public domain, extraction pending |
| NIST CSF 2.0 | nist.gov/cyberframework | 200 |
| CISA KEV | cisa.gov JSON feed, 1.9 MB | 200, application/json |
| arXiv cs.CR | arxiv.org/abs and /pdf | 200; 8 PDFs sampled |
| PLOS ONE | journals.plos.org, CC-BY full text | 200 |
| OSTI | osti.gov API | 200 |
| FIRST CVSS spec | first.org PDF | 200, application/pdf |
| D3FEND | d3fend.mitre.org + MIT repository | 200 |
| OSV | osv.dev | 200 |
| IETF RFC | rfc-editor.org/rfc/rfc8446.txt, 337 KB | 200 |
| DISA STIGs | public.cyber.mil/stigs | 200 index, 153 KB; terms unread |
| Agner Fog manuals | agner.org/optimize | 200 |

## Rejected — inaccessible

| Source | Failure | Evidence |
|---|---|---|
| DTIC | `www.dtic.mil` returned **502**; `apps.dtic.mil/sti/citations/AD1053945` returned **403** | two independent routes, both blocked |
| NSA / media.defense.gov | **403** on a direct PDF request | user-agent-based blocking |
| wiki.osdev.org | **403** | access control |
| Zenodo API | **403** to an unauthenticated client; a record URL 404'd | inconsistent, cannot confirm |
| cvedetails.com | **403** | scraping control |
| grep.app | **429** | rate limited |

DTIC deserves emphasis because it is the largest single body of public-domain technical reporting that could plausibly have added billions — millions of defence technical reports. It is not reachable from this environment on this date, and it is therefore recorded as rejected rather than projected. Anyone repeating this should retry from a different network; the finding is environmental, not necessarily permanent.

## Rejected — accessible but not reusable

USENIX Security, NDSS, Exploit-DB, seclists.org, oss-security archive, SANS Reading Room, CTFtime writeups, VulnHub, MISP taxonomies, Linux kernel docs, man7.org. Each returns 200 and each lacks a licence permitting commercial corpus use, or carries share-alike/copyleft. These are the most painful exclusions in the report: oss-security alone contains the highest-quality vulnerability discussion in public existence.

## Verification method for anyone repeating this

```bash
# repository
curl -sI https://codeload.github.com/<owner>/<repo>/tar.gz/refs/heads/<branch>
# licence file
curl -s https://raw.githubusercontent.com/<owner>/<repo>/<branch>/LICENSE | head -5
# document
curl -sIL -o /dev/null -w '%{http_code} %{content_type} %{size_download}\n' <url>
```
