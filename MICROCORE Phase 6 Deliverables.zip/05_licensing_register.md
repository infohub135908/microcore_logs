# Deliverable 5 — Licence and Legal Verification Register

Checks dated 2026-11-27. Method: fetch the licence file at the default branch and read it; where a repository carries per-file headers or multiple notices, note the conflict. A GitHub SPDX label was never accepted as clearance — three labels in this project's history disagreed with the file text.

## Outcome across 135 candidates

| Decision | Count | Meaning |
|---|---|---|
| APPROVED | 90 | clear basis for commercial corpus use |
| CONDITIONAL | 19 | a specific question is open; counted at zero |
| REJECTED | 26 | no licence, copyleft, share-alike, source-available, or inaccessible |

## Licences verified in Phase 6

| Licence | Sources | Evidence |
|---|---|---|
| MIT | Azure/Azure-Sentinel (1,162 B), nuclei, nuclei-templates (1,079 B), Windows-driver-samples, D3FEND (MIT, © 2021 MITRE) | file text read |
| Apache-2.0 | caldera, tracee, tetragon, kyverno, rustls (286 B pointer), scorecard, cosign, zaproxy, dependency-check, amass, trivy, grype, syft, oss-fuzz, fuzzing, osv.dev, OpenBAS | standard text with NOTICE obligation |
| BSD-2-Clause | OP-TEE (1,409 B) | file text read |
| CC-BY-4.0 | windows-driver-docs (18,650 B), powershell-docs (17,716 B), RustSec advisory-db (1,299 B), github/advisory-database (18,656 B), MSRC-Security-Research, testing-handbook, xairy index | attribution plus indication of changes |
| CC0 (metadata) | OpenAlex, DOAJ | metadata only |

## Rejections added this phase, with reason

| Source | Reason |
|---|---|
| MISP taxonomies | CC-BY-SA-4.0 — share-alike propagates |
| Linux kernel documentation | GPL-2.0 |
| man7.org man pages | verbatim-copy licence with restrictions |
| OSDev wiki | CC-BY-SA, and 403 |
| USENIX Security | no reuse licence; copyright USENIX |
| NDSS | no reuse licence found |
| Exploit-DB | site copyright, no reuse grant |
| oss-security, seclists.org | author copyright, no licence |
| SANS Reading Room | copyright plus registration |
| CTFtime writeups | author copyright |
| VulnHub | no licence |
| DTIC, media.defense.gov, cvedetails, grep.app | inaccessible (403/502/429) |
| nccgroup/cloudfox | no licence file at any standard path |
| TrustedFirmware-M | no top-level licence file located |

## Conditional, and what would resolve each

| Source | Open question |
|---|---|
| DISA STIGs | terms of use on public.cyber.mil unread; distribution statement could permit or forbid corpus use |
| IETF RFCs | IETF Trust legal provisions retain copyright; a corpus is arguably outside permitted reproduction |
| FIRST CVSS specification | terms not read |
| OSTI reports | per-record rights vary |
| Zenodo | API 403 to unauthenticated clients; per-deposit licences vary |
| Agner Fog manuals | permission statement is not a standard licence |
| EDK2 (carried from Phase 5) | per-file BSD-2-Clause-Patent headers; needs per-file enforcement |
| Metasploit (carried) | BSD-3-Clause at repo level, file-level variation unresolved |
| SecLists (carried) | MIT but contains real credential lists — a privacy question, not a licence one |

## Two licence subtleties that changed decisions

**OWASP is two different licensors.** OWASP prose (Cheat Sheets, WSTG, ASVS) is CC-BY-SA-4.0 and rejected. OWASP code (ZAP, Dependency-Check, Amass) is Apache-2.0 and approved. Blanket-rejecting "OWASP" would have lost 8 M tokens of scanner logic; blanket-accepting it would have imported share-alike text.

**MITRE is three different licences.** ATT&CK has a custom notice permitting commercial use; D3FEND is MIT; CWE and CAPEC carry their own terms. Treating "MITRE" as one licensor would have been wrong in both directions.

## Obligations that survive into the corpus

Apache-2.0 requires the NOTICE file to be reproduced. CC-BY-4.0 requires attribution and an indication of modifications — and tokenization, filtering and deduplication are modifications, so the corpus release must say so explicitly. MIT and BSD require the copyright notice. None of these obligations is discharged by a source list; each needs a NOTICE artefact in the build.

## Unresolved legal questions, ranked by token impact

1. IETF RFCs (~45 M projected) — the largest single question.
2. DISA STIGs (~60 M projected) — the largest if cleared.
3. EDK2 per-file enforcement — small tokens, high symbolic value for firmware coverage.
4. Whether CC-BY "indication of changes" can be satisfied by a NOTICE plus a transformation log. This affects every CC-BY source in the corpus, roughly 200 M tokens including arXiv.
5. Whether training use of a repository licensed for "research and development" (ATT&CK-style) extends to a commercial model. Assumed yes from the notice text, not from legal advice.

No conditional source contributes a token to any total in this report.
