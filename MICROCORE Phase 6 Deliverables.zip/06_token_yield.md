# Deliverable 6 — Measured and Projected Token-Yield Register

## Measured this phase (VERIFIED_MEASURED)

30 repositories, 442,750,324 cl100k tokens — a ratio of 240,368 tokens/MB, consistent with the Phase 3–5 filter (0.24 tokens/byte).

| ID | Source | cl100k | tok/MB | Yield class |
|---|---|---|---|---|
| MC-523 | github/advisory-database | 217,435,658 | — | VERIFIED_MEASURED — 412,537 files, formulaic |
| MC-503 | Azure/Azure-Sentinel | 108,063,051 | 219k | VERIFIED_MEASURED |
| MC-524 | OpenBAS | 14,814,716 | 227k | VERIFIED_MEASURED |
| MC-530 | windows-driver-docs | 14,536,960 | — | VERIFIED_MEASURED |
| MC-504 | nuclei-templates | 10,172,711 | 319k | VERIFIED_MEASURED |
| MC-529 | Windows-driver-samples | 10,123,742 | — | VERIFIED_MEASURED |
| MC-502 | powershell-docs | 8,019,007 | — | VERIFIED_MEASURED but **duplicate of Phase 2 MC-104** |
| MC-517 | OP-TEE | 8,013,515 | 310k | VERIFIED_MEASURED |
| MC-533 | osv.dev | 7,839,311 | 379k | VERIFIED_MEASURED |
| MC-509 | kyverno | 6,333,669 | — | VERIFIED_MEASURED |
| MC-520 | syft | 5,332,529 | — | VERIFIED_MEASURED |
| MC-525 | google/security-research | 4,545,080 | — | VERIFIED_MEASURED |
| MC-518 | trivy | 4,308,615 | — | VERIFIED_MEASURED |
| MC-514 | zaproxy | 4,120,373 | — | VERIFIED_MEASURED |
| MC-521 | oss-fuzz | 2,813,065 | — | VERIFIED_MEASURED |
| MC-508 | tetragon | 2,660,181 | — | VERIFIED_MEASURED |
| MC-516 | amass | 2,595,322 | 464k | VERIFIED_MEASURED — densest code source found |
| MC-519 | grype | 1,969,219 | 303k | VERIFIED_MEASURED |
| MC-507 | tracee | 1,908,652 | — | VERIFIED_MEASURED |
| MC-505 | nuclei | 1,530,100 | — | VERIFIED_MEASURED |
| MC-515 | dependency-check | 1,363,639 | — | VERIFIED_MEASURED |
| MC-512 | scorecard | 1,335,896 | — | VERIFIED_MEASURED |
| MC-510 | rustls | 869,341 | — | VERIFIED_MEASURED |
| MC-513 | cosign | 623,521 | — | VERIFIED_MEASURED |
| MC-511 | RustSec advisory-db | 529,034 | — | VERIFIED_MEASURED |
| MC-506 | caldera | 408,451 | — | VERIFIED_MEASURED — small despite reputation |
| MC-527 | testing-handbook | 353,463 | — | VERIFIED_MEASURED |
| MC-528 | linux-kernel-exploitation index | 81,015 | 329k | VERIFIED_MEASURED — one file |
| MC-522 | google/fuzzing | 47,413 | — | VERIFIED_MEASURED |
| MC-531 | MSRC-Security-Research | 3,075 | — | VERIFIED_MEASURED — repository is nearly empty |

Adjusted incremental total: **434,731,317** (442,750,324 minus the 8,019,007 PowerShell duplicate). Of that, 217,435,658 is advisory data that will be discounted heavily at record dedup — see Deliverable 10.

## The finding that matters

Two sources dominate: the GitHub advisory database (49 %) and Azure Sentinel (24 %). The distribution is extremely skewed, and the median source contributes under 2 M. Discovering more sources of the caldera/MSRC type does not move the corpus; discovering more of the Sentinel type does. That is the search heuristic Phase 6 adopts.

## Best information density

| Rank | Source | tok/MB | Why |
|---|---|---|---|
| 1 | amass | 463,507 | dense Go with heavy inline documentation |
| 2 | osv.dev | 379,326 | Markdown plus structured schema text |
| 3 | xairy index | 328,648 | pure prose links and summaries |
| 4 | nuclei-templates | 319,109 | YAML matchers, high token density per byte |
| 5 | OP-TEE | 310,302 | C with extensive comments |

Density is not value. Azure Sentinel's 219k tokens/MB is lower than amass's, yet it is worth a hundred times more because it teaches detection logic that exists nowhere else. Volume metrics must not be allowed to reorder priorities (Part 10 of the brief).

## Sample-measured: arXiv CC-BY subset

Method: 5 stratified offsets across the cs.CR listing (start = 0, 800, 1600, 2400, 3200), 40 records each, 200 total. Licence read from each abstract page.

| Licence | Count | Share |
|---|---|---|
| arXiv non-exclusive (default) | 137 | 68.5 % |
| CC-BY-4.0 | 45 | 22.5 % |
| CC-BY-NC-ND | 9 | 4.5 % |
| CC-BY-SA | 7 | 3.5 % |
| none found | 2 | 1 % |

PDF sample: 8 CC-BY papers, mean 12,168 cl100k tokens, mean 10.5 pages, 1,159 tokens/page. Two extraction failures occurred and were excluded, so the mean is conditional on successful extraction — a downward-bias risk that is noted rather than corrected.

Projection: 54,934 cs.CR papers × 22.5 % = 12,360 CC-BY papers × 12,168 = **150.4 M tokens**, classified PROJECTED. Confidence: medium. Limitations: the licence census is 200 records, not the population; PDF text extraction loses figures, tables and equations; papers overlap with conference versions and with each other.

## Projected: non-GitHub

| Source | Projection | Method | Confidence |
|---|---|---|---|
| NIST SP 800 series | 95 M | ~500 documents at 190k tokens average, from the measured doc-density range | low-medium |
| PLOS ONE security articles | 25 M | article count × 12k mean, same paper-density as arXiv | low |
| IETF RFCs | 45 M | ~9,000 RFCs, technical density ~5k each | low, and licence-blocked |
| DISA STIGs | 60 M | document count × density | very low, and terms-blocked |
| OSTI reports | 20 M | sample-free estimate | very low |
| DTIC | none | inaccessible — not projected | — |

Every row is labelled PROJECTED or UNVERIFIED_ESTIMATE. None appears in a measured total.

## What was not measured and why

Impacket, GhostPack, Mimikatz, Project Zero's older archive, Volatility, Radare2, Hashcat and other Phase 5 Tier A entries remain unmeasured. Storage and time, not licence, are the constraint: the environment has 5.1 GB free and 2 cores. Those sources were verified as licence-clean in Phase 5 and remain the first work item in Deliverable 11.
