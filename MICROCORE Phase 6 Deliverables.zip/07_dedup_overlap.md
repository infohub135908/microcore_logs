# Deliverable 7 — Global Duplication and Overlap Report

## The one measurement that exists

The 15 Phase 6 GitHub sources measured so far were deduplicated by SHA-256 across their 61,211 admitted files. Result: **1.628 % exact duplication** (2,440,752 of 149,889,054 tokens).

| Kind | Tokens | Share of duplicated total |
|---|---|---|
| Within-source exact duplicates | 2,438,259 | 99.9 % |
| Cross-source exact duplicates | 2,493 | 0.1 % |

The cross-source overlaps found were `zaproxy` ↔ `dependency-check` (2,270 tokens, shared Maven/OWASP boilerplate), `nuclei` ↔ `nuclei-templates` (221 tokens, shared licence and CI files), and two single-file collisions involving Azure-Sentinel.

**This does not mean global duplication is 1.6 %.** It means that among fifteen unrelated projects, byte-identical file duplication is small. The duplication that matters at corpus scale is of three other kinds, none of which this measurement covers:

1. **Re-measurement of the same repository** — PowerShell-docs appears as MC-104 in Phase 2 (7,864,313) and MC-502 in Phase 6 (8,019,007). A naive sum adds 8.0 M of pure phantom.
2. **Vendored and mirrored code inside measured repositories** — the pipeline's path filter drops `vendor/`, `third_party/`, `deps/`, but a re-licensed copy placed elsewhere in the tree survives.
3. **Near-duplicate prose** — the same advisory written by a vendor and republished by an aggregator; the same technique described in ten blog posts; documentation regenerated from a shared source. Exact hashing cannot see any of it.

## What is known about the shape of the loss

| Overlap class | Evidence | Estimated loss | Confidence |
|---|---|---|---|
| Phase 2 PowerShell-docs re-measurement | measured, exact repository identity | 8,019,007 avoided by exclusion | high |
| FreeBSD doc ↔ FreeBSD src | conceptual, code comments vs man pages | unknown, likely < 3 % of doc set | low |
| Azure docs ↔ entra-docs ↔ security-docs | same publisher, overlapping product text | unknown, 5–15 % of the three | low |
| Kubernetes website ↔ kubernetes source | terminology only | < 1 % | low |
| NVD ↔ GitHub Advisory ↔ OSV | same CVEs described three times | large — this is the main structured-data overlap | medium |
| ATT&CK ↔ detection content | technique IDs cited in rules | small in tokens | medium |
| Overall cross-source near-duplicate | never measured at corpus scale | 5–20 % | unverified estimate |

The NVD / GitHub Advisory / OSV triangle is the single largest known duplication risk in the whole plan, and it is the one most worth measuring: three databases describing the same vulnerabilities with different prose. A conservative treatment counts the best-structured one in full and samples the others; a naive treatment triples a 400 M-token category.

## Method for the global run

Four tiers, applied in this order, each recording its own loss.

**T1 — Identity.** Canonicalise every source to (host, repo, commit). Reject any snapshot already present. Catches re-measurement, the cheapest and most embarrassing class.

**T2 — Exact file.** SHA-256 of normalised bytes (LF, BOM stripped, trailing whitespace removed) plus a normalised-content hash with comments and string literals preserved but formatting collapsed. Code-specific: a second hash over the token stream with identifiers anonymised, which catches reformatted copies.

**T3 — Near-duplicate, MinHash/LSH.** 128 permutations, 5-word shingles for prose and 5-token shingles for code, 16 bands × 8 rows, Jaccard threshold 0.80, confirmed by exact Jaccard on candidates above 0.70. Protection against false positives: a document is only removed if it is ≥ 0.80 similar to an earlier document **and** either (a) is shorter, or (b) shares a canonical URL/publication lineage. Two independently written 0.75-similar documents about the same technique both survive, which is the correct behaviour — the brief is explicit that genuinely distinct explanations both qualify.

**T4 — Structured-record.** For JSON/CSV sources: dedupe on primary key (CVE ID, advisory ID, ATT&CK technique ID, rule UUID), then on a content fingerprint of the description field. This is where NVD/OSV/GHSA overlap is resolved.

## Reporting ladder

Every build must report these seven numbers, and no other number may be quoted as "the corpus":

| Stage | Definition |
|---|---|
| S0 | Gross source-level measured tokens |
| S1 | After within-source exact dedup |
| S2 | After within-source near dedup |
| S3 | After cross-source exact dedup |
| S4 | After cross-source near dedup |
| S5 | After licence, quality, safety and extraction exclusions |
| S6 | **Final eligible globally deduplicated count** |

Only S6 may be called unique. Today the project has S0 = 1,852,465,677 plus 149,889,054 newly measured, and no S1–S6 for the combined corpus.

## What was and was not done in this phase

Done: exact cross-source dedup over the Phase 6 measurement set (61,211 files); identity-level exclusion of the PowerShell re-measurement; per-source duplicate counts from the pipeline manifest.

Not done: near-duplicate detection at any scale; structured-record dedup across NVD/OSV/GHSA; any dedup involving the 1.85 B carried-forward corpus, whose per-file manifests exist only for the Phase 4 and 5 repositories.

The honest position: **global uniqueness remains unmeasured, and the 1.628 % figure must never be quoted as the global dedup rate** — it is the exact-duplicate rate of a fifteen-project sample that was selected, in part, for being unrelated.
