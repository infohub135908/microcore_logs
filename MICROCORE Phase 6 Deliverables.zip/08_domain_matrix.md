# Deliverable 8 — Cybersecurity Domain Coverage Matrix

Baseline = what the 1.852 B carried corpus actually contains. New = measured or projected Phase 6 additions. Grade is a judgement on the material available, not on the model that will be trained from it.

| Domain | Baseline | New in Phase 6 | Remaining gap | Final grade |
|---|---|---|---|---|
| **A. Web / API security** | Juice Shop 3.2 M, CodeQL 14.1 M | nuclei-templates 10.2 M, nuclei 1.5 M, zaproxy 4.1 M, amass 2.6 M | OWASP prose (CC-BY-SA), API abuse case studies | **strong** |
| **B. Linux security and exploitation** | kernel index 0.08 M, tcpdump, zeek | tracee 1.9 M, tetragon 2.7 M | kernel internals (GPL), heap exploitation at depth, real CVE analyses | **moderate** |
| **C. Windows / AD / enterprise identity** | entra-docs 11.7 M, Impacket (unmeasured) | windows-driver-docs 14.5 M, Windows-driver-samples 10.1 M, Powershell-docs 8.0 M (dup), MSRC 3 k | AD CS abuse procedures, Kerberos internals prose, Sysmon semantics | **strong** (was the top gap) |
| **D. Network / protocol analysis** | zeek 4.3 M, tcpdump 1.1 M, FreeBSD netinet | amass 2.6 M, osv.dev 7.8 M | packet-level traces, BGP security, TLS internals | **moderate** |
| **E. Cloud and enterprise platform** | Checkov 4.5 M, OPA 9.4 M, Falco 0.6 M, kube-bench 1.0 M, k8s docs 22.2 M | trivy 4.3 M, kyverno 6.3 M, grype 2.0 M, syft 5.3 M, cosign 0.6 M, scorecard 1.3 M, Sentinel 108 M | control-plane attack paths, IAM privilege escalation, cloud IR | **strong** |
| **F. Binary exploitation and memory safety** | how2heap (unmeasured), MBE, Ghidra 30.1 M | google/security-research 4.5 M, oss-fuzz 2.8 M, fuzzing 0.05 M | modern mitigations, heap internals across allocators, browser exploitation | **moderate** |
| **G. Reverse engineering and assembly** | Ghidra 30.1 M, Capstone/angr/pwndbg (unmeasured) | google/security-research 4.5 M | dynamic instrumentation, anti-analysis, firmware RE narratives | **strong** |
| **H. Malware analysis and threat research** | capa 0.7 M, capa-rules, OTRF 0.25 M, ATT&CK 13.7 M | MSRC 3 k (near-empty) | family-level analyses, unpacking, C2 protocol studies | **weak-moderate** |
| **I. DFIR** | Plaso, KapeFiles (unmeasured), OTRF 0.25 M | OpenBAS 14.8 M (simulation, adjacent) | real investigations, memory forensics, timeline reasoning | **weak-moderate** |
| **J. Detection engineering / CTI** | Splunk 5.0 M, Falco 0.6 M, kube-bench 1.0 M, atomic 2.2 M | **Sentinel 108 M**, OpenBAS 14.8 M, D3FEND 0.9 M projected, caldera 0.4 M | Sigma rules (DRL), Elastic (ELv2), validation methodology | **strongest** |
| **K. Firmware / embedded / hardware** | EDK2 (conditional), Zephyr, FreeRTOS, mbedTLS (unmeasured), ChipWhisperer | OP-TEE 8.0 M | side-channel measurement data, actual firmware images, JTAG/UART procedures | **weak-moderate** |
| **L. Wireless** | nothing measured | nothing found | WPA2/WPA3 internals (hostapd is BSD but unmeasured), BLE/Zigbee research | **absent** |
| **M. Mobile** | jadx, apktool (unmeasured) | nothing new | iOS internals (closed), Android malware analyses | **weak** |
| **N. Cryptography** | libsodium, BoringSSL, mbedTLS, Tink, NIST (unmeasured) | rustls 0.87 M, OP-TEE crypto 8.0 M | protocol design reasoning, side channels, formal verification | **strong** |
| **O. Supply chain / secure development** | CodeQL 14.1 M, Checkov 4.5 M | osv.dev 7.8 M, syft 5.3 M, trivy 4.3 M, grype 2.0 M, dependency-check 1.4 M, scorecard 1.3 M, cosign 0.6 M, RustSec 0.5 M, oss-fuzz 2.8 M | SLSA/attestation prose, reproducible-build practice | **strong** |

## Where the specified weaknesses now stand

| Specified weakness | Before Phase 6 | After | Verdict |
|---|---|---|---|
| Active Directory and enterprise identity | thin prose, unmeasured tooling | 24.6 M of Windows kernel/identity docs plus 10.1 M of driver code | **substantially closed** — this phase's clearest win |
| Cloud control planes | tool code only | 130 M+ including Sentinel and policy engines | **improved**, still short on attack-path reasoning |
| Wireless security | none | none | **unmoved** — no licence-clean source located |
| Firmware and embedded | conditional EDK2 only | OP-TEE 8.0 M | **improved, still thin** |
| Hardware and side-channel | ChipWhisperer (conditional) | nothing new | **unmoved** |
| DFIR and practical forensics | OTRF 0.25 M, Plaso unmeasured | OpenBAS scenarios, not forensics | **unmoved in substance** |
| Malware analysis | capa, ATT&CK | MSRC repository proved nearly empty | **unmoved** |
| Advanced exploitation and RE | Ghidra, how2heap, MBE | Project Zero research 4.5 M | **improved** |
| Realistic tool-use sequences | none | OpenBAS scenarios, caldera abilities | **marginally improved** — still the largest gap in the corpus |

## The uncomfortable summary

Detection engineering, enterprise identity, cloud/supply chain and web security are now genuinely well supplied. Wireless is empty, hardware is empty, DFIR and malware analysis are represented mostly by tools rather than investigations, and there is still no corpus of real tool-use trajectories.

Three of the twelve original domains have moved from weak to strong; one (wireless) has not moved at all; the deepest capability gaps — procedure, judgement, investigation — remain exactly where they were, because they are not published in reusable form.
