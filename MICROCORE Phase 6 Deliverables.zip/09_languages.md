# Deliverable 9 — Eleven-Language Security Programming Coverage

## Status of the canonical list

The brief instructs recovery of the canonical eleven from project records. They were searched again: the Phase 2 specification attachment, the Phase 2–5 inventories, the published microcore_logs repository, and every source register. **No document states a canonical list.** Phase 5 reconstructed one from the measured language distribution and flagged it. Phase 6 has nothing further to add and does not invent alternatives.

Working list, still unconfirmed: **C, C++, C#, Go, Rust, Python, Java, JavaScript, TypeScript, PowerShell, Shell/Bash.**

This is a question for the project owner, not for further research, and it is asked once more at the end of this report rather than buried here.

## Measured language mix (all repositories with per-file manifests)

Derived by extension over the per-file manifests of the Phase 4, 5 and 6 measurements: 443,785,005 coded tokens.

| Language | Tokens | Share | Files |
|---|---|---|---|
| Python | 124,394,780 | 28.0 % | 51,512 |
| Java | 83,175,782 | 18.7 % | 53,791 |
| C++ | 77,406,852 | 17.4 % | 20,697 |
| C | 63,093,986 | 14.2 % | 23,654 |
| TypeScript | 58,340,342 | 13.1 % | 19,149 |
| Go | 23,037,471 | 5.2 % | 11,742 |
| C# | 3,959,912 | 0.9 % | 2,376 |
| Rust | 3,860,278 | 0.9 % | 1,701 |
| JavaScript | 3,549,143 | 0.8 % | 3,465 |
| Shell | 1,944,544 | 0.4 % | 3,546 |
| PowerShell | 1,021,915 | 0.2 % | 380 |

Two warnings about this table. First, it covers only sources with file manifests — the Phase 2 and 3 sources are absent, so it is not the whole corpus. Second, Java and TypeScript are inflated by single large sources (Sentinel workbooks, OpenBAS playbooks, generated SDKs) and do not represent security-programming diversity.

## Per-language assessment

| Language | Supply | Distinct projects | Security domains covered | Weakness |
|---|---|---|---|---|
| **C** | abundant | many | kernel-adjacent, crypto (OP-TEE, libsodium, mbedTLS), firmware | little userspace exploitation code |
| **C++** | abundant | many | RE (Ghidra, Capstone), browser-adjacent, Windows drivers | dominated by two large projects |
| **Python** | abundant | many | offensive tooling, ML-security, DFIR parsers, fuzzing | much is glue code, not security logic |
| **Go** | good | many | cloud, container, supply chain, network | thin on memory-safety and exploitation |
| **Java** | good | few | appsec scanners, Android (jadx), enterprise | concentrated in three projects |
| **TypeScript** | moderate | few | web appsec, Sentinel workbooks | generated code inflates volume |
| **C#** | **thin** | ~5 | GhostPack, AD tooling | almost no modern .NET security code |
| **PowerShell** | **thin** | ~8 | offensive scripting, AD | 0.2 % of coded tokens; no narrative use |
| **Rust** | **thin** | ~4 | rustls, RustSec, some parsers | the largest genuine language gap |
| **JavaScript** | moderate | several | vulnerable-app labs, tooling | little at production quality |
| **Shell** | moderate | many | installers and one-liners | low information density |

## What would close the gaps

Rust: rustls, RustSec and `ring` are the only licence-clean candidates found; the ecosystem publishes advisory data faster than it publishes security tooling documentation. C#: GhostPack, Certify, Seatbelt and SharpUp remain unmeasured and are the whole supply. PowerShell: PowerShell-docs supplies reference material, but the scripting corpus is small and largely MIT-licensed modules rather than security logic.

No amount of further searching produced a Rust or C# security corpus of meaningful size under a permissive licence. That is a finding, not a search failure.

## Programme coverage

Part 5 asks for security-specific programming material across the eleven. Of the twenty categories listed there — scanners, protocol implementations, binary parsers, fuzzers, sandboxes, detection engines, forensic parsers, cloud tooling — the corpus now covers scanners, parsers, fuzzers, detection engines, forensic parsers and cloud tooling well; sandboxing, exploit-mitigation implementations and OS security interfaces remain thin because the best implementations (seccomp tooling, SELinux, AppArmor, sandboxfs) are GPL or kernel-internal.
