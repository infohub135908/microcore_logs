# Deliverable 11 — Acquisition Execution Roadmap

Ordered by what can be done now, not by what would be nice to know. The discovery phase is over for the sources below; each has a verified licence and a working download route.

## Immediate (week 1–2): measure what is already verified

Nineteen Phase 5 Tier A sources remain licence-verified and unmeasured. They stream from codeload with no staging disk and no new legal work.

| Source | Domain | Expected |
|---|---|---|
| Impacket | AD/Kerberos/SMB | large |
| GhostPack: Rubeus, Seatbelt, Certify, SharpUp | AD, C# | moderate |
| pwndbg, angr, Capstone | RE | large |
| FLOSS, Binwalk | malware, firmware | moderate |
| Plaso, KapeFiles | DFIR | moderate |
| Zephyr, mbedTLS, libsodium | firmware, crypto | large |
| jadx, apktool | mobile | moderate |
| how2heap, vulhub, NodeGoat, PKINITtools, adidnsdump | labs, AD, web | small |

Cost: CPU only, roughly 6–8 hours of streaming and tokenizing. Expected yield: the 200 M projection in Deliverable 10. **This is the single highest-value action available and requires no new decisions.**

## Weeks 2–5: document harvest

Three approved non-GitHub pools need a PDF/HTML pipeline rather than a repository pipeline.

| Source | Route | Volume | Effort |
|---|---|---|---|
| NIST SP 800 | csrc.nist.gov PDF links | ~500 documents | 1 week to build and validate extraction |
| arXiv CC-BY | OAI-PMH or API filter on licence, then /pdf | 12,360 papers | 2 weeks at polite rate limits (1 req/3 s) |
| PLOS ONE | API search + full text | thousands of articles | 1 week |

Extraction quality is the risk: pypdf recovered 1,159 tokens/page on the arXiv sample and dropped figures and equations. A layout-aware extractor should be evaluated before committing 150 M tokens of noisy text.

## Weeks 3–6: structured-record deduplication

The advisory cluster — GitHub advisory-database 217 M, OSV, RustSec, NVD — describes the same vulnerabilities several times. Deduplicate on advisory ID and on a description fingerprint before any of it enters a build. Expected effective yield after record dedup: roughly 130 M of the 217 M, which is already assumed in the realistic scenario.

## Weeks 6–10: global deduplication

Exact and near-duplicate across the whole corpus, including the 1.85 B carried forward. Requirements: ~300 GB scratch (not available in this environment), 200–400 CPU-hours, 16 GB RAM for the near-dedup index. Output: the first honest unique count the project has ever had.

## Weeks 8–18: generated procedure

Detection-authoring pairs, triage cases, timeline reconstructions, secure-code-review pairs. Capped at 20 % of corpus. Every item labelled `generated` in the manifest and validated mechanically (rule parses, case is internally consistent).

## Weeks 16–20: allocation and build

Sample each domain down to its quota, freeze, hash, publish manifest, NOTICE file and decontamination blocklist.

## Dependencies and gates

| Gate | Blocks | Criterion |
|---|---|---|
| G1 Tier A measurement | allocation | all nineteen sources measured or explicitly failed |
| G2 extractor validation | NIST/arXiv/PLOS | ≥ 90 % of sample pages produce clean text |
| G3 advisory record dedup | any build containing advisories | duplicate rate < 5 % on a 1,000-record audit |
| G4 legal read on IETF and DISA | their inclusion | written decision |
| G5 near-dedup run | freeze | S4 computed for the whole corpus |

## Cost table

| Work | CPU-hours | Scratch disk | Wall time |
|---|---|---|---|
| Tier A measurement | 8 | none (streamed) | 1–2 days |
| Document harvest | 60 | 40 GB | 4 weeks |
| Record dedup | 20 | 20 GB | 1 week |
| Global dedup | 200–400 | 300 GB | 4 weeks |
| Generation | 500+ (GPU or CPU) | 50 GB | 10 weeks |

## What not to do next

Do not run another discovery sweep before measuring the nineteen verified sources. The marginal value of the next hundred candidates is far below the value of the two hundred million tokens already sitting behind a verified licence and an untested download.
