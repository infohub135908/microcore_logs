# Deliverable 13 — Evidence and Reproducibility Appendix

All checks 2026-11-27 (Asia/Dubai). Working files referenced are included in this bundle under `data/`.

## Primary evidence

| Claim | Evidence | Location |
|---|---|---|
| Baseline reconciles to 1,852,465,677 | Phase 2 token register, Phase 3 token register, Phase 4 and 5 JSON measurements | `data/D1_baseline.csv`, `../out/01_baseline_audit.md` |
| Phase 2 reconciliation is exact | 109,429,097 − 5,459,909 − 2,179,229 − 51,796 = 101,738,163 | `01_baseline_audit.md` |
| 30 repositories measured, 442,750,324 cl100k | per-source JSON with files, bytes, GPT-2 counts | `data/a_MC-5xx.json` |
| 61,211 admitted files hashed | per-file manifests with SHA-256 and cl100k | `data/man_MC-5xx.jsonl` |
| Exact duplication 1.628 % | computed across the manifests | `07_dedup_overlap.md` |
| arXiv CS.CR = 54,934 papers | opensearch totalResults | `data/arxiv_census.json` |
| 22.5 % CC-BY | 200 abstract pages, 5 offsets | `data/arxiv_census.json` |
| 12,168 cl100k mean per paper | 8 CC-BY PDFs, pypdf | `data/arxiv_pdf.json` |
| Licence decisions | licence file text fetched per repository | `05_licensing_register.md`, `D12_source_inventory.csv` |
| Accessibility outcomes | HTTP status per route | `04_access_verification.md`, `data/sweep.json` |

## URLs used for licence verification

`https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{LICENSE|LICENSE.md|LICENSE.txt|COPYING}`

Examples: `Azure/Azure-Sentinel/master/LICENSE` (1,162 B, MIT), `OP-TEE/optee_os/master/LICENSE` (1,409 B, BSD-2), `MicrosoftDocs/windows-driver-docs/main/LICENSE` (18,650 B, CC-BY-4.0), `mitre/d3fend/main/LICENSE` (MIT, © 2021 MITRE), `google/osv.dev/master/LICENSE` (Apache-2.0).

## URLs used for access verification

| Source | URL | Result |
|---|---|---|
| codeload tar route | `https://codeload.github.com/{owner}/{repo}/tar.gz/refs/heads/{branch}` | 200 for all 30 measured |
| NIST SP 800-53r5 | `https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final` | 200 |
| NIST CSF | `https://www.nist.gov/cyberframework` | 200 |
| CISA KEV | `https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json` | 200, 1.9 MB |
| arXiv API | `http://export.arxiv.org/api/query?search_query=cat:cs.CR` | 200 |
| arXiv PDF | `https://arxiv.org/pdf/{id}` | 200 |
| PLOS | `https://journals.plos.org/plosone/` | 200 |
| OSTI API | `https://www.osti.gov/api/v1/records?q=cybersecurity` | 200 |
| RFC 8446 | `https://www.rfc-editor.org/rfc/rfc8446.txt` | 200, 337 KB |
| FIRST CVSS | `https://www.first.org/cvss/v3-1/cvss-v31-specification_r1.pdf` | 200 |
| DISA STIGs | `https://public.cyber.mil/stigs/` | 200 index, terms unread |
| DTIC | `https://www.dtic.mil/`, `https://apps.dtic.mil/sti/citations/AD1053945` | 502, 403 |
| media.defense.gov | direct PDF | 403 |
| Zenodo | `https://zenodo.org/api/records` | 403 |
| USENIX | `https://www.usenix.org/conference/usenixsecurity24/technical-sessions` | 200, licence rejected |
| NDSS | `https://www.ndss-symposium.org/ndss2024/accepted-papers/` | 200, licence rejected |
| OSDev | `https://wiki.osdev.org/` | 403 |
| cvedetails | `https://www.cvedetails.com/` | 403 |
| grep.app | `https://grep.app/` | 429 |

## Reproducible commands

```bash
# measure a repository (streams the tarball, no staging disk)
python3 p3/pipeline/acquire.py --repo Azure/Azure-Sentinel --branch master \
  --out data/a_MC-503.json --manifest data/man_MC-503.jsonl \
  --gpt2 --repo-licence VERIFIED_COMPATIBLE

# licence probe for a candidate
curl -s https://raw.githubusercontent.com/<owner>/<repo>/main/LICENSE | head -5

# arXiv licence census (200 papers, 5 offsets)
python3 p6/arxiv4.py

# arXiv PDF token sample
python3 p6/arxiv_pdf.py

# rebuild the register
python3 p6/reg.py
```

## Known limitations of this evidence

1. The 1.852 B baseline is a sum of source-level measurements, not a unique count.
2. Deduplication haircuts in Deliverable 10 are estimates; only exact duplication (1.628 % on a 15-repo subset) is measured.
3. arXiv projection rests on a 200-paper licence census and an 8-paper token sample; both are small and both are labelled.
4. PDF extraction loses figures, tables and equations; the token sample is conditional on successful extraction.
5. DTIC's inaccessibility is environmental; it may be reachable from another network and should be retested.
6. Advisory-database tokens are formulaic; the 40–50 % haircut is a judgement, not a measurement.
7. Phase 4 and 5 repositories measured before this phase were not re-run, so their manifests reflect earlier filter versions.

## Files in this bundle

```
00_README.md                   index
01_baseline_audit.md           Deliverable 1
02_discovery_register.md       Deliverable 2
03_top50.md                    Deliverable 3
04_access_verification.md      Deliverable 4
05_licensing_register.md       Deliverable 5
06_token_yield.md              Deliverable 6
07_dedup_overlap.md            Deliverable 7
08_domain_matrix.md            Deliverable 8
09_languages.md                Deliverable 9
10_feasibility.md              Deliverable 10
11_roadmap.md                  Deliverable 11
12 inventory                   D12_source_inventory.csv (135 rows, 34 fields)
13_evidence_appendix.md        Deliverable 13
D1_baseline.csv                per-source baseline with dispositions
data/                          measurement JSON, manifests, census outputs
reg.py, arxiv4.py, arxiv_pdf.py  scripts
```
