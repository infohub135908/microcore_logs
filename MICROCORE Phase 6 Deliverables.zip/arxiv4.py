import json,re,time,urllib.request,sys
UA={"User-Agent":"micore-audit/1.0"}
def fetch(u,t=15):
    return urllib.request.urlopen(urllib.request.Request(u,headers=UA),timeout=t).read()
ids=[]
for off in (0,800,1600,2400,3200):
    u=f"http://export.arxiv.org/api/query?search_query=cat:cs.CR&start={off}&max_results=40"
    raw=fetch(u).decode("utf-8","replace")
    got=[m.rsplit("/",1)[-1] for m in re.findall(r"<id>(http://arxiv.org/abs/[^<]+)</id>",raw)]
    print(off,len(got),flush=True); ids+=got
cnt={};cc=[]
for i,a in enumerate(ids):
    try:
        h=fetch(f"https://arxiv.org/abs/{a}").decode("utf-8","replace")
        m=re.search(r'href="[^"]*licenses/([^/"]+)/',h)
        k=m.group(1) if m else "none"
        l="CC-BY-4.0" if k.startswith("by/4.0") else ("CC0" if "zero" in k else ("CC-BY-SA" if "sa" in k else "arxiv-"+k[:20]))
    except Exception as e:
        l="ERR"
    cnt[l]=cnt.get(l,0)+1
    if l in ("CC-BY-4.0","CC0"): cc.append(a)
    if i%25==0: print(i,l,flush=True)
    time.sleep(0.8)
print("CENSUS",len(ids),cnt,len(cc),cc[:12],flush=True)
json.dump({"n":len(ids),"licences":cnt,"cc":cc,"checked":time.strftime("%Y-%m-%d")},open("data/arxiv_census.json","w"),indent=1)
