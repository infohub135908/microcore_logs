import io,json,re,time,urllib.request,tiktoken
from pypdf import PdfReader
UA={"User-Agent":"micore-audit/1.0"}
def f(u,t=60): return urllib.request.urlopen(urllib.request.Request(u,headers=UA),timeout=t).read()
ids=[]
for off in (0,800):
    raw=f(15 and f"http://export.arxiv.org/api/query?search_query=cat:cs.CR&start={off}&max_results=40").decode()
    ids+=[m.rsplit("/",1)[-1] for m in re.findall(r"<id>(http://arxiv.org/abs/[^<]+)</id>",raw)]
picks=[]
for a in ids:
    h=f(f"https://arxiv.org/abs/{a}").decode("utf-8","replace")
    m=re.search(r'href="[^"]*licenses/(by)/',h)
    if m: picks.append(a)
    if len(picks)>=10: break
    time.sleep(0.7)
print("picks",picks,flush=True)
enc=tiktoken.get_encoding("cl100k_base"); rows=[]
for a in picks:
    try:
        b=f(f"https://arxiv.org/pdf/{a}",120); r=PdfReader(io.BytesIO(b))
        t="\n".join((p.extract_text() or "") for p in r.pages)
        rows.append({"id":a,"pages":len(r.pages),"chars":len(t),"cl100k":len(enc.encode(t))})
        print(a,len(r.pages),rows[-1]["cl100k"],flush=True)
    except Exception as e: print(a,"ERR",str(e)[:80],flush=True)
    time.sleep(1.5)
ok=[r for r in rows if "cl100k" in r]
out={"n_papers":len(ok),"mean_tokens":round(sum(r["cl100k"] for r in ok)/len(ok)) if ok else None,
     "mean_pages":round(sum(r["pages"] for r in ok)/len(ok),1) if ok else None,
     "tokens_per_page":round(sum(r["cl100k"] for r in ok)/sum(r["pages"] for r in ok)) if ok else None,
     "sample":rows,"checked":time.strftime("%Y-%m-%d")}
json.dump(out,open("data/arxiv_pdf.json","w"),indent=1); print(json.dumps({k:v for k,v in out.items() if k!="sample"},indent=1))
