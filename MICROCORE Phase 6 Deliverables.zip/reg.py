#!/usr/bin/env python3
"""Build the Phase 6 source register (Deliverables 2 and 12)."""
import csv, glob, json, os

BASE = os.path.dirname(os.path.abspath(__file__))

# ---- Phase 6 GitHub candidates: id -> (domain tags, language tags, licence, url, publisher, desc, scope, decision, note)
GH = {
 "MC-501": ("enterprise-identity, os/kernel", "C++, docs", "CC-BY-4.0", "MicrosoftDocs/windows-driver-docs",
   "Microsoft", "Windows driver development and kernel security documentation: WDM/WDF, IOCTLs, DMA, driver signing, security best practice.",
   "Default branch (staging) Markdown", "APPROVED", "first attempt used branch main and returned 404; staging is the default"),
 "MC-502": ("detection-engineering, enterprise-identity", "PowerShell, docs", "CC-BY-4.0", "MicrosoftDocs/powershell-docs",
   "Microsoft", "PowerShell reference, scripting security, remoting, constrained language mode, logging.",
   "Markdown docs", "APPROVED", "RE-MEASUREMENT of Phase 2 MC-104; counts once, not twice"),
 "MC-503": ("detection-engineering, cloud", "KQL, docs", "MIT", "Azure/Azure-Sentinel",
   "Microsoft", "Sentinel analytics rules, hunting queries, workbooks, playbooks and ASIM parsers - the largest single security detection corpus found.",
   "All YAML/JSON/KQL/Markdown", "APPROVED", "largest Phase 6 yield"),
 "MC-504": ("web-appsec, offensive", "YAML, Markdown", "MIT", "projectdiscovery/nuclei-templates",
   "ProjectDiscovery", "Community vulnerability check templates: request/response pairs, matchers, CVE coverage.",
   "All templates", "APPROVED", ""),
 "MC-505": ("web-appsec, tooling", "Go", "MIT", "projectdiscovery/nuclei",
   "ProjectDiscovery", "Template-driven scanner engine: DSL, matchers, protocol clients.",
   "Source tree", "APPROVED", ""),
 "MC-506": ("offensive, detection-engineering", "Python, docs", "Apache-2.0", "mitre/caldera",
   "MITRE", "Adversary emulation platform with ability definitions mapped to ATT&CK.",
   "Source and ability YAML", "APPROVED", ""),
 "MC-507": ("linux, detection-engineering", "Go, eBPF", "Apache-2.0", "aquasecurity/tracee",
   "Aqua Security", "eBPF runtime security: syscall tracing, signatures, detection events.",
   "Source tree", "APPROVED", ""),
 "MC-508": ("linux, cloud, detection-engineering", "Go, eBPF, C", "Apache-2.0", "cilium/tetragon",
   "Isovalent", "eBPF-based security observability and policy enforcement for Kubernetes.",
   "Source tree", "APPROVED", ""),
 "MC-509": ("cloud, containers, policy", "Go, YAML", "Apache-2.0", "kyverno/kyverno",
   "Kyverno", "Kubernetes admission policy engine; large policy and test corpus.",
   "Source and policy YAML", "APPROVED", ""),
 "MC-510": ("cryptography, network", "Rust", "Apache-2.0", "rustls/rustls",
   "rustls project", "Memory-safe TLS implementation in Rust.",
   "Source tree", "APPROVED", "only substantial licence-clean Rust security codebase found"),
 "MC-511": ("supply-chain, vulnerability-intelligence", "TOML, Markdown", "CC-BY-4.0", "RustSec/advisory-db",
   "RustSec", "Rust vulnerability advisories with affected ranges and prose.",
   "All advisories", "APPROVED", "branch is main"),
 "MC-512": ("supply-chain, secure-development", "Go, docs", "Apache-2.0", "ossf/scorecard",
   "OpenSSF", "Repository security posture checks and scoring.",
   "Source tree", "APPROVED", ""),
 "MC-513": ("supply-chain, signing", "Go", "Apache-2.0", "sigstore/cosign",
   "Sigstore", "Artifact signing, attestation and verification.",
   "Source tree", "APPROVED", ""),
 "MC-514": ("web-appsec, tooling", "Java, docs", "Apache-2.0", "zaproxy/zaproxy",
   "OWASP", "ZAP proxy: active/passive scan rules, fuzzing, API scanning.",
   "Source tree", "APPROVED", "OWASP prose is CC-BY-SA, OWASP *code* is Apache-2.0 - the distinction matters"),
 "MC-515": ("supply-chain, vulnerability-intelligence", "Java", "Apache-2.0", "dependency-check/DependencyCheck",
   "OWASP", "SCA engine, CPE/CVE matching, suppression logic.",
   "Source tree", "APPROVED", ""),
 "MC-516": ("network, offensive, tooling", "Go", "Apache-2.0", "owasp-amass/amass",
   "OWASP", "Attack-surface mapping and DNS enumeration engine.",
   "Source tree", "APPROVED", ""),
 "MC-517": ("firmware, hardware, cryptography", "C", "BSD-2-Clause", "OP-TEE/optee_os",
   "Linaro", "Trusted Execution Environment OS: TrustZone TA/CA model, secure storage, crypto.",
   "Source tree", "APPROVED", "fills part of the firmware/TrustZone gap"),
 "MC-518": ("cloud, containers, supply-chain", "Go", "Apache-2.0", "aquasecurity/trivy",
   "Aqua Security", "Vulnerability, misconfiguration, secret and SBOM scanning.",
   "Source tree", "APPROVED", ""),
 "MC-519": ("containers, supply-chain", "Go", "Apache-2.0", "anchore/grype",
   "Anchore", "Vulnerability matching against SBOMs.",
   "Source tree", "APPROVED", ""),
 "MC-520": ("containers, supply-chain", "Go", "Apache-2.0", "anchore/syft",
   "Anchore", "SBOM generation across ecosystems.",
   "Source tree", "APPROVED", ""),
 "MC-521": ("fuzzing, secure-development", "Python, C++", "Apache-2.0", "google/oss-fuzz",
   "Google", "Continuous fuzzing infrastructure, build recipes, sanitizer configuration.",
   "Source tree", "APPROVED", ""),
 "MC-522": ("fuzzing, exploitation", "C, docs", "Apache-2.0", "google/fuzzing",
   "Google", "Fuzzing documentation and example harnesses.",
   "Source tree", "APPROVED", ""),
 "MC-523": ("vulnerability-intelligence, supply-chain", "JSON, Markdown", "CC-BY-4.0", "github/advisory-database",
   "GitHub", "Reviewed security advisories across package ecosystems.",
   "All advisories", "APPROVED", "overlaps OSV and NVD; structured-record dedup required"),
 "MC-524": ("offensive, detection-engineering", "Java, TypeScript", "Apache-2.0", "OpenBAS-Platform/openbas",
   "Filigran", "Breach and attack simulation platform with scenario definitions.",
   "Source tree", "APPROVED", ""),
 "MC-525": ("vulnerability-research, reverse-engineering", "C, Python, docs", "Apache-2.0", "google/security-research",
   "Google Project Zero", "Published vulnerability research, PoCs and advisories from Project Zero and Google security teams.",
   "All research directories", "APPROVED", "highest-value original research source found in Phase 6"),
 "MC-526": ("detection-engineering, malware", "Markdown, PowerShell", "CC-BY-4.0", "microsof/MSRC-Security-Research",
   "Microsoft", "MSRC security research writeups and exploit mitigation notes.",
   "Markdown", "APPROVED", "wrong repo path used in the first measurement batch; re-run pending"),
 "MC-527": ("reverse-engineering, fuzzing, labs", "Markdown, Python", "CC-BY-4.0", "trailofbits/testing-handbook",
   "Trail of Bits", "Testing handbook: fuzzing, sanitizers, harness design.",
   "Markdown", "APPROVED", ""),
 "MC-528": ("linux, exploitation", "Markdown", "CC-BY-4.0", "xairy/linux-kernel-exploitation",
   "Andrey Konovalov", "Curated index of Linux kernel exploitation techniques and writeups.",
   "Single README", "APPROVED", "1 file, 81k tokens - a bibliography, not a corpus"),
 "MC-529": ("os/kernel, enterprise-identity", "C, C++", "MIT", "microsoft/Windows-driver-samples",
   "Microsoft", "Official Windows driver samples: IOCTL handling, DMA, filter drivers.",
   "Source tree", "APPROVED", ""),
 "MC-530": ("os/kernel, enterprise-identity", "C++, docs", "CC-BY-4.0", "MicrosoftDocs/windows-driver-docs",
   "Microsoft", "As MC-501, measured on the correct branch.", "Markdown", "APPROVED", "duplicate id risk - MC-501 and MC-530 are the same source"),
 "MC-531": ("malware, detection-engineering", "Markdown, PowerShell", "CC-BY-4.0", "microsoft/MSRC-Security-Research",
   "Microsoft", "MSRC security research repository.", "Markdown", "APPROVED", "retry of MC-526"),
 "MC-532": ("detection-engineering, enterprise", "Python, RDF", "MIT", "mitre/d3fend",
   "MITRE", "Defensive technique ontology and mappings to ATT&CK.", "Ontology and docs", "APPROVED", ""),
 "MC-533": ("supply-chain, vulnerability-intelligence", "Go, docs", "Apache-2.0", "google/osv.dev",
   "Google", "OSV schema, tooling and site documentation.", "Source tree", "APPROVED", "OSV *data* licence is separate and unverified"),
}

NG = [
 # id, name, publisher, url, licence, commercial, access, decision, measured, est, domains, rationale
 ("MC-601","NIST SP 800 publication series","NIST","https://csrc.nist.gov/publications/sp800","US-Gov-PD","permitted","VERIFIED_ACCESSIBLE","APPROVED",None,95000000,"standards, cryptography, cloud, supply-chain","Largest coherent public-domain security standards body. Hundreds of documents; PDF extraction required."),
 ("MC-602","NIST Cybersecurity Framework 2.0","NIST","https://www.nist.gov/cyberframework","US-Gov-PD","permitted","VERIFIED_ACCESSIBLE","APPROVED",None,400000,"security-engineering","Small but canonical; already partially present via Phase 2 standards."),
 ("MC-603","CISA Known Exploited Vulnerabilities","CISA","https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json","US-Gov-PD","permitted","VERIFIED_ACCESSIBLE","APPROVED",454763,None,"vulnerability-intelligence","Already counted in Phase 2; listed for completeness, not incremental."),
 ("MC-604","DISA STIGs and SCAP content","DISA","https://public.cyber.mil/stigs/","unread-terms","unknown","PARTIALLY_ACCESSIBLE","CONDITIONAL",None,60000000,"hardening, os/kernel","Site reachable (153 KB index) but terms of use unread. High value if cleared."),
 ("MC-605","IETF RFC series","IETF Trust","https://www.rfc-editor.org/","IETF-TLP","restricted","VERIFIED_ACCESSIBLE","CONDITIONAL",None,45000000,"network, cryptography","RFC 8446 fetched (337 KB). Trust legal provisions retain copyright; needs written opinion."),
 ("MC-606","arXiv cs.CR CC-BY subset","arXiv / authors","https://arxiv.org/list/cs.CR/recent","CC-BY-4.0","permitted","VERIFIED_ACCESSIBLE","APPROVED",97344,150000000,"vulnerability-research, cryptography, ML-security","Licence census: 45 of 200 sampled papers CC-BY. 8-paper PDF sample: 12,168 cl100k mean."),
 ("MC-607","PLOS ONE security articles","PLOS","https://journals.plos.org/plosone/","CC-BY-4.0","permitted","VERIFIED_ACCESSIBLE","APPROVED",None,25000000,"malware, DFIR, network","Full text CC-BY; API search available; not yet measured."),
 ("MC-608","Zenodo security datasets","Zenodo / CERN","https://zenodo.org/","mixed","unknown","PARTIALLY_ACCESSIBLE","CONDITIONAL",None,None,"DFIR, malware, hardware","API returned 403 to an unauthenticated client at check time; record licences vary per deposit."),
 ("MC-609","OSTI technical reports","US DOE","https://www.osti.gov/","US-Gov","unknown","VERIFIED_ACCESSIBLE","CONDITIONAL",None,20000000,"network, cryptography, hardware","US government reports; individual record rights vary."),
 ("MC-610","DTIC technical reports","US DoD","https://discover.dtic.mil/","US-Gov","unknown","REJECTED_INACCESSIBLE","REJECTED",None,None,"offensive, hardware, DFIR","dtic.mil returned 502 and apps.dtic.mil returned 403 on 2026-11-27."),
 ("MC-611","USENIX Security proceedings","USENIX","https://www.usenix.org/conference/usenixsecurity24/technical-sessions","USENIX-copyright","no reuse licence","VERIFIED_ACCESSIBLE","REJECTED",None,None,"vulnerability-research, systems","Freely readable, but no reuse licence granted."),
 ("MC-612","NDSS proceedings","Internet Society","https://www.ndss-symposium.org/","ISOC-copyright","no reuse licence","VERIFIED_ACCESSIBLE","REJECTED",None,None,"network, mobile","Open access reading, no commercial reuse licence found."),
 ("MC-613","Exploit-DB","OffSec","https://www.exploit-db.com/","site-copyright","unclear","VERIFIED_ACCESSIBLE","REJECTED",None,None,"exploitation","No reuse licence for the archive text."),
 ("MC-614","oss-security mailing list archive","Openwall","https://www.openwall.com/lists/oss-security/","author-copyright","no licence","VERIFIED_ACCESSIBLE","REJECTED",None,None,"vulnerability-research, linux","Extremely high technical value, zero licence clarity. Archived for reference only."),
 ("MC-615","seclists.org archives","Nmap/Insecure.Org","https://seclists.org/","author-copyright","no licence","VERIFIED_ACCESSIBLE","REJECTED",None,None,"exploitation, DFIR","Same problem as oss-security."),
 ("MC-616","FIRST CVSS v3.1 specification","FIRST","https://www.first.org/cvss/v3-1/specification","FIRST-terms","unknown","VERIFIED_ACCESSIBLE","CONDITIONAL",None,120000,"vulnerability-intelligence","PDF fetched (200). Terms not read."),
 ("MC-617","MITRE D3FEND","MITRE","https://d3fend.mitre.org/","MIT","permitted","VERIFIED_ACCESSIBLE","APPROVED",None,900000,"detection-engineering","Ontology and mappings; MIT licence verified on the repository."),
 ("MC-618","OSV schema and tooling","Google","https://osv.dev/","Apache-2.0","permitted","VERIFIED_ACCESSIBLE","APPROVED",None,700000,"supply-chain","Tooling Apache-2.0; OSV vulnerability data licence separate and unverified."),
 ("MC-619","MISP taxonomies","MISP project","https://www.misp-project.org/","CC-BY-SA-4.0","share-alike","VERIFIED_ACCESSIBLE","REJECTED",None,None,"threat-intelligence","Share-alike is incompatible with the corpus licence policy."),
 ("MC-620","SANS Reading Room","SANS","https://www.sans.org/white-papers/","SANS-copyright","no reuse","VERIFIED_ACCESSIBLE","REJECTED",None,None,"DFIR, detection","Registration plus copyright; excluded."),
 ("MC-621","CTFtime writeups","CTFtime","https://ctftime.org/writeups","author-copyright","no licence","VERIFIED_ACCESSIBLE","REJECTED",None,None,"exploitation, web","Author-owned text with no licence."),
 ("MC-622","VulnHub","VulnHub","https://www.vulnhub.com/","none-found","unknown","VERIFIED_ACCESSIBLE","REJECTED",None,None,"labs","No licence; VM images are binary anyway."),
 ("MC-623","Linux kernel security documentation","kernel.org","https://www.kernel.org/doc/html/latest/security/","GPL-2.0","no","VERIFIED_ACCESSIBLE","REJECTED",None,None,"linux","Kernel docs are GPL-2.0."),
 ("MC-624","man7.org man pages","Michael Kerrisk","https://man7.org/linux/man-pages/","linux-man-pages-copyleft","no","VERIFIED_ACCESSIBLE","REJECTED",None,None,"linux, network","Verbatim-copy licence with restrictions."),
 ("MC-625","OSDev wiki","OSDev community","https://wiki.osdev.org/","CC-BY-SA","share-alike","REJECTED_INACCESSIBLE","REJECTED",None,None,"os/kernel","403 at check; share-alike regardless."),
 ("MC-626","Agner Fog optimisation manuals","Agner Fog","https://www.agner.org/optimize/","author-permission","unknown","VERIFIED_ACCESSIBLE","CONDITIONAL",None,3000000,"reverse-engineering, exploitation","Exceptional microarchitecture depth; permission statement not a standard licence."),
 ("MC-627","OpenAlex metadata","OurResearch","https://openalex.org/","CC0","permitted","VERIFIED_ACCESSIBLE","APPROVED",None,None,"research-index","Metadata only, no full text. Useful as an index, not as corpus."),
 ("MC-628","DOAJ article metadata","DOAJ","https://doaj.org/","CC0-metadata","permitted","VERIFIED_ACCESSIBLE","APPROVED",None,None,"research-index","Index of open-access articles; full text under per-article CC licences."),
]

def load_base():
    rows = list(csv.DictReader(open(os.path.join(BASE, "../p5/out/03_source_register.csv"))))
    out = []
    for r in rows:
        out.append({
            "id": r["id"], "name": r["source"], "publisher": r["publisher"],
            "url": r["url"], "download_url": r["url"], "scope": r["format"],
            "type": "repository" if "github" in r["url"] else "dataset",
            "domains": r["domains"], "languages": "", "licence": r["licence"],
            "licence_url": r["licence_evidence"], "commercial": r["commercial_use"],
            "obligations": r["attribution"], "access_status": "VERIFIED_ACCESSIBLE",
            "http": "200", "auth": "none", "size": r["size"], "files": "",
            "content_types": r["format"], "measured_cl100k": r["measured_cl100k"],
            "yield_class": "VERIFIED_MEASURED" if r["measured_cl100k"] else "UNVERIFIED_ESTIMATE",
            "est_cl100k": "", "quality": r["quality"], "dup_risk": r["dedup_risk"],
            "overlap": "see Phase 5 register", "privacy": r["pii_secret_risk"],
            "extraction": "low", "value": r["tier"], "confidence": "high",
            "priority": r["priority"], "decision": r["decision"],
            "rationale": r["note"], "checked": "2026-11-27",
            "phase": "5"})
    return out

def measured():
    m = {}
    for f in glob.glob(os.path.join(BASE, "data/a_MC-5*.json")):
        d = json.load(open(f))
        m[f.split("a_")[1][:6]] = (d.get("cl100k_eligible"), d.get("files_selected"), d.get("bytes_text"))
    return m

def main():
    rows = load_base()
    meas = measured()
    for sid, (dom, lang, lic, repo, pub, desc, scope, dec, note) in GH.items():
        t, fl, by = meas.get(sid, (None, None, None))
        rows.append({
            "id": sid, "name": repo, "publisher": pub, "url": f"https://github.com/{repo}",
            "download_url": f"https://codeload.github.com/{repo}/tar.gz/refs/heads/(default)",
            "scope": scope, "type": "repository", "domains": dom, "languages": lang,
            "licence": lic, "licence_url": f"https://github.com/{repo}/blob/HEAD/LICENSE",
            "commercial": "permitted" if lic in ("MIT","Apache-2.0","BSD-2-Clause","CC-BY-4.0") else "check",
            "obligations": "attribution; NOTICE for Apache-2.0" if lic == "Apache-2.0" else "attribution",
            "access_status": "VERIFIED_ACCESSIBLE", "http": "200", "auth": "none",
            "size": f"{by/1e6:.1f} MB text" if by else "", "files": fl or "",
            "content_types": scope, "measured_cl100k": t if t else "",
            "yield_class": "VERIFIED_MEASURED" if t else "VERIFIED_ACCESSIBLE_UNMEASURED",
            "est_cl100k": "", "quality": "", "dup_risk": "medium",
            "overlap": "none known" if sid not in ("MC-502",) else "Phase 2 MC-104 (same repository)",
            "privacy": "low", "extraction": "low", "value": "A", "confidence": "high",
            "priority": 1, "decision": dec, "rationale": desc + (" | " + note if note else ""),
            "checked": "2026-11-27", "phase": "6"})
    for (sid, name, pub, url, lic, com, acc, dec, m, est, dom, rat) in NG:
        rows.append({
            "id": sid, "name": name, "publisher": pub, "url": url, "download_url": url,
            "scope": "see rationale", "type": "dataset", "domains": dom, "languages": "",
            "licence": lic, "licence_url": url, "commercial": com,
            "obligations": "attribution" if "CC-BY" in lic else "none stated",
            "access_status": acc, "http": "", "auth": "none", "size": "", "files": "",
            "content_types": "documents", "measured_cl100k": m or "",
            "yield_class": ("SAMPLE_MEASURED" if sid == "MC-606" else
                            "VERIFIED_MEASURED" if m else
                            "PROJECTED" if est else "UNVERIFIED_ESTIMATE"),
            "est_cl100k": est or "", "quality": "", "dup_risk": "medium",
            "overlap": "none known", "privacy": "low", "extraction": "medium",
            "value": "A" if dec == "APPROVED" else "C", "confidence": "medium",
            "priority": 1 if dec == "APPROVED" else 3, "decision": dec,
            "rationale": rat, "checked": "2026-11-27", "phase": "6"})
    out = os.path.join(BASE, "out/D12_source_inventory.csv")
    fields = ["id","phase","name","publisher","url","download_url","scope","type","domains",
              "languages","licence","licence_url","commercial","obligations","access_status",
              "http","auth","size","files","content_types","measured_cl100k","yield_class",
              "est_cl100k","quality","dup_risk","overlap","privacy","extraction","value",
              "confidence","priority","decision","rationale","checked"]
    w = csv.DictWriter(open(out, "w", newline=""), fieldnames=fields, extrasaction="ignore")
    w.writeheader(); w.writerows(rows)
    n = len(rows)
    dec = {}
    for r in rows: dec[r["decision"]] = dec.get(r["decision"], 0) + 1
    tot = sum(int(r["measured_cl100k"]) for r in rows if str(r["measured_cl100k"]).isdigit())
    print(n, dec, f"measured sum {tot:,}")

if __name__ == "__main__":
    main()
