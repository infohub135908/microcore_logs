# MICROCORE Phase 7 — deliverable index

All measurements dated 2026-11-27. All 16 deliverables are present.

| ID | File | Contents |
|---|---|---|
| D1 | `01_baseline.md` | Reconstruction of the 2,287,196,994 baseline and six accounting defects |
| D2 | `02_completion.md` | 59 repositories measured, 326.3 M net, closing 28 of 31 approved-but-unmeasured Phase 5 sources |
| D3 | `03_discovery_register.md` | 116 candidates classified; approved, conditional and rejected kept separate |
| D4 | `04_top50.md` | Top 50 by incremental value, with the SecLists and Zephyr haircuts |
| D5 | `05_academic.md` | arXiv licence census, per-paper yield, Europe PMC population, PLOS withdrawal |
| D6 | `06_government.md` | NIST, CISA, NCSC, ENISA measured; six CERTs conditional; three closed |
| D7 | `07_dfir_hw_wireless.md` | DFIR and hardware strong, wireless empty, with named gaps |
| D8 | `08_languages.md` | Eleven-language roster, 86.4% coverage, freeze recommendation |
| D9 | `09_access.md` | Accessibility register with dated evidence, 99 / 6 / 11 / 0 |
| D10 | `10_licensing.md` | Licence outcomes, six corrected assumptions, the share-alike decision |
| D11 | `11_token_yield.md` | Four measurement classes, yield per document, projection arithmetic |
| D12 | `12_dedup.md` | 2.49% exact duplicate rate and why it must not be generalised |
| D13 | `13_feasibility.md` | Three scenarios, 3,241.3 M realistic, gap 1,758.7 M |
| D14 | `14_roadmap.md` | Five stages with gates, and what the roadmap does not achieve |
| D15 | `P7_source_inventory.csv` | 116 sources, 38 fields, blank where evidence is unavailable |
| D16 | `16_evidence.md` | Artefact hashes, enumeration provenance, failed retrievals |

## Headline numbers

| Figure | Value |
|---|---:|
| Phase 7 measured net new tokens | 349,287,979 |
| Of which code, 59 repositories | 326,271,927 |
| Of which documents, 4,962 documents | 23,016,052 |
| Sources assessed | 116 |
| Approved / conditional / rejected | 70 / 23 / 23 |
| Realistic corpus total after Phase 7 | 3,241.3 M |
| Gap to 5 B | 1,758.7 M |

## Reading order

Start with D13 for the conclusion, D1 for what the baseline really is, and D3 for why the ceiling is a licence problem rather than a search problem. D11 and D12 explain why no figure here should be called globally unique.

## Standing caveats

- 2,287,196,994 is measured input, not globally unique tokens.
- 2.49% is the exact duplicate rate of Phase 7 code only.
- PLOS is fully contained in Europe PMC and contributes zero incremental tokens.
- SecLists and Zephyr carry heavy quality haircuts and should not be read at face value.
- Every projection is labelled PROJECTED and every sample is labelled SAMPLE_MEASURED.
