# Deliverable 1 — Phase 1–6 baseline reconstruction

All checks dated 2026-11-27. Nothing in this document is a new measurement; it is an audit of what the earlier phases recorded.

## 1. The accounting chain

| Milestone | Gross measured tokens | Adjustment made in that phase | Carried forward |
|---|---|---|---|
| Phase 2 | 109,429,097 | −5,459,909 (duplicate row MC-105d), −2,179,229 (Sigma 2,009,343 + LOLBAS 169,886), −51,796 (MC-012 deferred) | 101,738,163 |
| Phase 3 | 1,295,372,327 | — | 1,295,372,327 |
| Phase 4 | +566,340,470 | −47,081,833 (files re-measured in the Phase 5 snapshot), −2,431,242 (osquery re-count) | 1,812,199,722 |
| Phase 5 | +47,081,833 | −6,815,878 (Cybench, evaluation-only) | 1,852,465,677 |
| Phase 6 | +442,750,324 | −8,019,007 (PowerShell-docs duplicate of MC-104) | 2,287,196,994 |

The chain reproduces the figure quoted in the Phase 7 brief to the token. Two residual variances are recorded rather than smoothed:

- Phase 3: the register implies 1,193,634,164 against a measured 1,193,631,552. **2,612 tokens (0.0002%) unexplained.** Not material, but unexplained.
- Phase 4/5: 47,081,833 tokens were counted in Phase 4 and re-measured in Phase 5. Phase 5 correctly counted only the delta, so no double count survives — but the Phase 4 line is inflated by that amount if read in isolation.

## 2. What the 2.287 B actually contains

| Component | Tokens | Share |
|---|---|---|
| General OS, compiler, application and documentation code (vscode, godot, pytorch, tensorflow, spark, opensearch, home-assistant, kubernetes-website, freebsd-doc …) | ~1,030 M | 45 % |
| CVE / advisory data (cisagov/vulnrichment 385.6 M, github/advisory-database 217.4 M) | ~603 M | 26 % |
| Vulnerability-research and security tooling code | ~340 M | 15 % |
| Detection content, cloud security documentation, driver/OS documentation | ~190 M | 8 % |
| Security reference documentation (MITRE ATT&CK, NIST, CISA KEV, MSRC, testing handbook) | ~120 M | 5 % |

Measured directly from the per-source JSON in `p2/`–`p6/`. The corpus is therefore *not* cybersecurity-first at the input level: roughly 56 % is general-purpose software and only ~3 % is security research prose. Phase 7 addresses that imbalance, not just the total.

## 3. Accounting defects found in Phases 1–6

1. **No global deduplication has ever been run.** The 2.287 B is a sum of source-level measurements. Within-source exact duplication was measured once, on a 61,211-file Phase 6 subset: 1.628 %. Cross-source duplication has never been measured.
2. **The advisory cluster is counted three times over in principle.** vulnrichment (385.6 M), advisory-database (217.4 M) and the NVD feeds approved but never measured (MC-452) all encode overlapping CVE/GHSA records. Only the first two are in the baseline; the third must never be added without record-level dedup.
3. **Re-measurement under a new ID was caught once and could recur.** PowerShell-docs appeared as MC-104 in Phase 2 and MC-502 in Phase 6. The Phase 6 net correctly removed 8.0 M. Any future phase must diff repository identity, not source ID.
4. **Projections were never separated from measurements in the running total.** Phase 6's 150 M arXiv projection, the NIST 95 M projection and the PLOS 25 M projection are all absent from the 2.287 B — correct — but the Phase 6 feasibility model then added them back as if they were acquisitions. They are not. Phase 7 measures NIST (13.46 M actual) and finds PLOS contributes zero incremental tokens.
5. **The evaluation set is inside the same storage tree.** Cybench (6.8 M) was excluded from the Phase 5 total, which is right, but it remains in `p4/data5`. It must stay excluded and must not be re-admitted by a future glob.
6. **Phase 6's own duplication figure was reported without its bound.** 1.628 % applies to fifteen repositories, not to the corpus.

## 4. What Phase 7 changes in the baseline

Nothing. The baseline remains **2,287,196,994 gross measured inputs**, with an unmeasured global-unique value. Phase 7 adds separately (§D11) and models uniqueness explicitly (§D13). For the first time the model states a measured floor for the duplicate rate instead of assuming one: 2.49 % exact duplication across 130,688 newly measured files (§D12).

## 5. Sources approved in earlier phases that were never acquired

Thirty-one Phase 5 Tier A repositories were approved and never measured. Phase 7 measured twenty-eight of them (§D2). Two failed on repository resolution, one was licence-blocked. In addition, ten Phase 6 approved sources were unmeasured at the start of this phase; Phase 7 measured NIST and closed PLOS by dedup rather than acquisition.
