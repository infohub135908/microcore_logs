# Deliverable 2 — Completion of previously approved acquisitions

Phase 5 approved 48 sources. By the end of Phase 6, 31 of them had never been measured: the register approved them, the pipeline never touched them. This is the cheapest yield in the project and closing it was the first action of Phase 7.

## Result: 28 of 31 closed, 326.3 M net new tokens

All 59 repositories below were downloaded from `codeload.github.com`, every file was licence-classified by SPDX header, tokenized with `cl100k_base`, and hashed with SHA-256. Repository licence was confirmed independently through the GitHub licence API and, for the 21 repositories it returns as `NOASSERTION` or `null`, by reading the licence file itself.

| Repository | Tokens | Files | Register ID |
|---|---:|---:|---|
| danielmiessler/SecLists | 64,285,860 | 6,079 | new |
| zephyrproject-rtos/zephyr | 59,060,597 | 45,725 | MC-439 |
| openssl/openssl | 25,712,663 | 2,926 | new |
| rapid7/metasploit-framework | 21,304,394 | 12,198 | new |
| google/boringssl | 17,522,011 | 1,593 | MC-442 |
| cilium/cilium | 15,951,985 | 7,905 | new |
| BC-SECURITY/Empire | 13,745,490 | 1,363 | new |
| OpenCTI-Platform/opencti | 12,980,922 | 6,975 | MC-419 |
| ComplianceAsCode/content | 12,833,269 | 12,797 | new |
| lowRISC/opentitan | 11,364,633 | 4,366 | new |
| Z3Prover/z3 | 10,619,676 | 3,324 | MC-433 |
| mitre-attack/attack-stix-data | 7,364,007 | 27 | MC-449 |
| tianocore/edk2 | 5,902,086 | 399 | new |
| angr/angr | 5,134,616 | 2,159 | MC-432 |
| vulhub/vulhub | 5,072,489 | 1,591 | MC-448 |
| krb5/krb5 | 4,853,946 | 1,743 | new |
| FreeRTOS/FreeRTOS-Kernel | 4,359,276 | 843 | MC-440 |
| tink-crypto/tink-java | 3,303,780 | 1,419 | MC-443 |
| juice-shop/juice-shop | 3,203,538 | 1,031 | MC-404 |
| fortra/impacket | 2,480,657 | 379 | MC-424 |
| tpm2-software/tpm2-tss | 2,461,424 | 835 | new |
| openssh/openssh-portable | 2,242,611 | 600 | new |
| log2timeline/plaso | 1,864,923 | 1,218 | MC-418 |
| capstone-engine/capstone | 1,863,141 | 584 | MC-434 |
| skylot/jadx | 1,838,269 | 2,091 | MC-445 |
| mitmproxy/mitmproxy | 1,647,334 | 928 | new |
| GhostPack/SharpDPAPI | 1,332,890 | 135 | new |
| VirusTotal/yara | 1,297,072 | 218 | new |
| PowerShellMafia/PowerSploit | 1,257,908 | 242 | MC-425 |
| jedisct1/libsodium | 1,134,300 | 508 | MC-441 |
| aquasecurity/kube-bench | 1,008,409 | 372 | MC-461 |
| mandiant/capa | 717,259 | 277 | MC-463 |
| falcosecurity/falco | 624,695 | 335 | MC-460 |
| shellphish/how2heap | 508,915 | 378 | MC-430 |
| onekey-sec/unblob | 428,981 | 1,706 | new |
| decalage2/oletools | 428,736 | 123 | new |
| GhostPack/Rubeus | 355,075 | 160 | MC-420 |
| RhinoSecurityLabs/pacu | 304,853 | 125 | MC-428 |
| gitleaks/gitleaks | 288,380 | 297 | new |
| mandiant/flare-floss | 277,344 | 162 | MC-416 |
| mandiant/capa-rules | 274,385 | 1,070 | MC-415 |
| projectdiscovery/naabu | 269,485 | 152 | new |
| projectdiscovery/httpx | 214,585 | 126 | new |
| iBotPeaches/Apktool | 206,072 | 269 | MC-444 |
| ReFirmLabs/binwalk | 197,235 | 266 | MC-446 |
| GhostPack/Seatbelt | 175,047 | 167 | new |
| NetSPI/MicroBurst | 142,762 | 67 | MC-429 |
| projectdiscovery/subfinder | 132,660 | 133 | new |
| gchq/CyberChef | 123,524 | 46 | new |
| aquasecurity/kube-hunter | 75,882 | 123 | MC-462 |
| GhostPack/Certify | 57,962 | 36 | MC-422 |
| RPISEC/MBE | 37,554 | 73 | MC-431 |
| SigmaHQ/sigma-specification | 37,452 | 30 | MC-453 |
| GhostPack/SharpUp | 13,827 | 24 | new |
| dirkjanm/PKINITtools | 12,028 | 6 | MC-423 |
| dirkjanm/adidnsdump | 6,232 | 4 | MC-427 |
| EricZimmerman/KapeFiles | 3,422 | 11 | MC-417 |
| mbedtls (Mbed-TLS/mbedtls) | 1,198,122 | 249 | new |
| open-policy-agent/gatekeeper | 2,470,608 | 1,700 | new |

**Gross 334,587,258. Exact duplicates 8,315,331 (2.49 %). Net 326,271,927** across 130,688 admitted files.

## Three sources from the approved list that could not be closed

| Source | Result | Disposition |
|---|---|---|
| hostap/hostap (802.11/WPA2-WPA3 implementation) | tarball 404 on `main` and `master` | UNVERIFIED — the most valuable remaining wireless code target |
| volatilityfoundation/volatility3 | licence is the Volatility Software License, not an OSI permissive licence | REJECTED on licence, not on access |
| PowerShellMafia/Empire | repository archived; `main` 404 | SUPERSEDED — BC-SECURITY/Empire acquired instead (13.7 M) |

## Why these numbers are trustworthy

Each `a_MC-*.json` carries the source URL, branch, timestamp and per-class token split; each manifest line carries path, bytes, cl100k count, SPDX string and SHA-256. The duplication figure is computed by hashing those 130,688 files, not estimated. Vendored, generated, minified and binary files were excluded by the pipeline's path and extension filters before tokenization.

## What is still open from phases 1–6

- NVD CVE 2.0 feeds (MC-452): approved, never measured, and structurally overlapping with vulnrichment. Must be measured against vulnrichment by CVE ID before any tokens are added.
- MITRE D3FEND (MC-617, MC-532): two source IDs for the same ontology. One must be retired. The RDF/OWL distribution was not counted because the pipeline does not parse RDF literals.
- OSV schema/tooling (MC-618): unmeasured; small.
- DISA STIGs: terms of use unread; conditional, counted at zero.
