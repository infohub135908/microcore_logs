# Deliverable 3 — Discovery register

116 distinct candidates were assessed in Phase 7 and recorded in `P7_source_inventory.csv`. Each one carries an access probe dated 2026-11-27, a licence outcome, and a decision. The register is deliberately complete: rejected and inaccessible candidates stay in it, because the negative result is evidence.

## 1. Decisions

| Decision | Count | Meaning |
|---|---:|---|
| APPROVED | 70 | Licence permits training use and the material is accessible; may enter the acquisition queue |
| CONDITIONAL | 23 | Accessible but the licence needs a case-by-case or per-document review, or overlaps an existing source |
| REJECTED | 23 | Licence forbids reuse, or the source cannot be reached without circumventing a control |

## 2. By class

| Class | Count | Examples |
|---|---:|---|
| Code repositories measured | 59 | SecLists, zephyr, openssl, metasploit, boringssl, cilium |
| Document corpora measured | 6 | NIST nvlpubs, CISA ICS, NCSC UK, ENISA, PLOS, Europe PMC |
| Academic populations assessed | 5 | arXiv, DOAJ, CORE, HAL, OpenReview, Semantic Scholar |
| Government / CERT bodies probed | 14 | DTIC, NSA, ACSC, CCCS, ANSSI, BSI, NCSC-NL, CERT-EU, JPCERT, CSA Singapore |
| Vulnerability / taxonomy data | 5 | NVD CVE 2.0, CWE, CAPEC, ATT&CK, KEV-adjacent |
| Practitioner documentation | 8 | Microsoft Learn, AWS, Google Cloud, HackTricks, PayloadsAllTheThings, CTF Wiki, OWASP WSTG |
| Conference proceedings | 5 | USENIX Security, NDSS, IEEE Xplore, ACM DL, Springer LNCS |

## 3. The rejections that matter

These are the sources a less careful register would have listed as wins.

| Candidate | What it looks like | Why it is rejected |
|---|---|---|
| USENIX Security proceedings | Open PDFs, hundreds of papers | Authors retain copyright; no blanket reuse grant. Access is not permission. |
| NDSS symposium | Open PDFs | Same. ISOC/NDSS papers are not openly licensed by default. |
| HackTricks | 8,000+ pages of offensive technique | Licence file is CC BY-NC-SA 4.0. Non-commercial clause blocks it (verified by reading the file). |
| CTF Wiki | Large, well-structured, security-specific | CC BY-NC-SA 4.0, verified by reading the licence file. |
| OWASP WSTG | Canonical web-security testing guide | CC BY-SA 4.0. Share-alike would propagate to the corpus. |
| PayloadsAllTheThings | 60k+ stars, highly relevant | No licence file at all. Default copyright applies. |
| Exploit-DB, Packet Storm, SANS Reading Room | Huge security corpora | Publisher copyright; SANS material is member-restricted. |
| ACM DL, IEEE Xplore, Springer LNCS | The bulk of peer-reviewed security research | Paywalls and publisher copyright. 403/202 on probe. |
| volatility3 | Leading memory-forensics framework | Licence is the Volatility Software License, not an OSI licence; redistribution terms are restrictive. |
| ACSC (Australia) | Large advisory corpus | 403 on every route tried, including RSS. Access control not bypassed. |
| BSI (Germany) | Large German-language guidance | Published listing route returns 404; no working enumeration found. |
| NSA / media.defense.gov | Cyber advisories, GHIDRA docs | 403 from both hostnames. |

## 4. What the register proves about the ceiling

Of 46 non-code candidates probed, 5 were measurable without further work, 14 need per-document licence review, and 27 are closed. The pattern is consistent: the material with the highest security density — conference proceedings, exploit archives, practitioner wikis — is precisely the material that is not openly licensed. The material that is openly licensed — government guidance, standards, open-access journals — is thinner per document and partly duplicative of what earlier phases already hold.

This is the central finding of Phase 7 discovery. The 5 B token target is not blocked by search effort. It is blocked by licence.
