# Deliverable 5 — Academic sources

Academic literature is the only category where Phase 7 found a large, licensed, measurable population that the corpus does not already hold. It is also the category where careless arithmetic is most tempting, because the difference between "papers that exist" and "papers we may use" is a factor of three.

## 1. arXiv: the licence is the binding constraint

A stratified census of 55 papers in each of ten categories (550 papers total) captured the article-level licence field from the arXiv API. Every paper was classified, none extrapolated from a single sample.

| Category | Papers in 55-paper sample | CC BY share |
|---|---:|---:|
| cs.CR (cryptography and security) | 54,934 | 23.6% |
| cs.SE | 4,489 | 41.8% |
| cs.NI | 4,998 | 18.2% |
| cs.DC | 3,465 | 27.3% |
| cs.PL | 1,991 | 29.1% |
| cs.OS | 1,606 | 36.4% |
| cs.LG | 20,648 | 32.7% |
| eess.SP | 533 | 20.0% |
| cs.CY | 4,273 | 34.5% |
| cs.IR | 1,437 | 34.5% |

Pooled: 164 of 550 papers are CC BY, 29.8%. The remaining 70.2% carry arXiv's non-exclusive licence, which permits arXiv to distribute the paper and does not grant a training corpus any reuse right.

The number in the second column is the total token count of that 55-paper sample, not a population count. It is useful as a density check — cs.CR papers are markedly longer than cs.PL papers — but it must not be multiplied by anything.

## 2. Per-paper yield

89 CC-BY PDFs were downloaded and tokenized: mean 18,745 cl100k tokens, mean 19.5 pages, 959 tokens per page. Category means ranged from cs.NI at 10,464 to eess.SP at 28,741.

## 3. The unique pool

A cs.CR-centric pool must deduplicate cross-listings, because a paper cross-listed in cs.CR and cs.LG appears in both category feeds.

| Cross-listed category | Overlap with cs.CR |
|---|---:|
| cs.LG | 13,200 |
| cs.NI | 2,642 |
| cs.SE | 2,508 |
| cs.DC | 2,394 |
| cs.CY | 2,308 |
| cs.PL | 517 |
| cs.IR | 498 |
| cs.OS | 281 |

After removing cross-listings the unique pool is approximately 73,973 papers.

Applying the measured 29.8% CC BY rate: 73,973 × 0.298 ≈ 22,044 licensed papers. At the measured mean of 18,745 tokens: 413.2 M gross tokens. This is a projection from a measured rate and a measured mean, and it is labelled PROJECTED, not measured.

## 4. Europe PMC: the larger licensed population

Europe PMC holds 32,518 records matching a CC-BY-restricted, security-relevant query. A 300-record sample was retrieved through NCBI efetch and tokenized: 299 succeeded, mean 13,773 tokens. Projected population: 32,518 × 13,773 ≈ 447.9 M gross.

Two audits were run against this population rather than assuming it was usable:

- Relevance: 49 of 60 sampled titles and abstracts (81.7%) pass a security keyword filter. The rest are incidental keyword collisions — papers about "security" in the sense of food security, social security, or national security policy.
- Overlap: every one of 100 sampled PLOS DOIs had a PMC identifier. PLOS is therefore fully contained in Europe PMC.

## 5. PLOS: measured, then withdrawn

350 PLOS security articles were measured at 3,939,166 tokens. Because PLOS publishes into PMC, that entire figure is a subset of Europe PMC. PLOS appears in the CSV with its measurement recorded and its incremental estimate set to zero. It must not be added to any total.

## 6. The aggregators that did not deliver

| Service | Probe | Outcome |
|---|---|---|
| DOAJ | 200 | Metadata index only. No full text. Not a token source. |
| CORE | 200 | API key required for bulk access; not pursued. |
| HAL | 200 | Per-record licence varies; French-language bias; not enumerated. |
| OpenReview | 403 | Blocked. |
| Semantic Scholar | 429 | Rate-limited and the API terms restrict bulk text use. |
| OpenAlex | 429 | Metadata only in any case. |

## 7. What academic sources actually add

Measured and projected together, academic literature contributes roughly 860 M gross tokens at the population level — far more than any other Phase 7 category. But it arrives with three costs that must be priced in:

- Relevance haircut on Europe PMC (81.7% at the title level, worse at full text).
- Restriction haircut on arXiv (70.2% of papers are unusable, already excluded by the 29.8% figure).
- Retrieval cost: arXiv PDFs run ~1.8 MB each and NCBI efetch throttles. 22,044 arXiv PDFs is roughly 40 GB of transfer; 32,518 PMC full texts at ~33 s per document on the EBI route is impractical, which is why the NCBI route was adopted.
