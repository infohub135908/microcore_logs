# Deliverable 6 — Government and CERT sources

Government material is the highest-quality block Phase 7 found. It is also the block where the assumption "government means public domain" fails most often, because authorship is frequently shared with contractors or with foreign partners.

## 1. Measured

| Source | Documents | Tokens | Licence basis |
|---|---:|---:|---|
| NIST SP 800 / SP 1800 / FIPS (nvlpubs) | 240 of 242 | 13,464,872 | US Government work, 17 U.S.C. 105 |
| CISA ICS advisories | 3,203 of 3,203 | 7,658,591 | US Government work |
| NCSC UK guidance | 1,281 of 1,281 | 1,760,927 | Open Government Licence v3.0 |
| ENISA publication pages | 238 of 599 | 131,662 | EU reuse decision 2011/833/EU |
| Total | 4,962 | 23,016,052 | |

The NIST enumeration probed 1,910 candidate URL patterns (SP 800-1 to 800-260 with revisions r1–r5, SP 1800-1 to 1800-45, Legacy SP 500-1 to 500-100, FIPS 1 to 205) with HTTP Range requests. 242 returned 200; every miss returned a clean 404. The 240 successfully parsed represent 28,573 pages, 1.10 GB, and average 1,118 tokens per page — the densest per-page yield of any source in the phase, which is what a standards document should look like.

The CISA enumeration walked the advisory listing pagination to 3,203 URLs. All 3,203 returned content. Average 2,391 tokens per advisory.

## 2. Accessible but not usable without per-document review

| Body | Probe | Blocker |
|---|---|---|
| Canadian Centre for Cyber Security | listing 200 | OGL-Canada 2.0 applies to some publications, not all; no bulk route |
| ANSSI (France) | 200 | Licence Ouverte 2.0 claimed at site level; individual guides carry third-party notices |
| NCSC-NL | 200 | Licence not verified at document level |
| CERT-EU | 200 | EU reuse decision applies, contractor-authored content excepted |
| JPCERT/CC | 200 | Terms of use not verified |
| Singapore CSA | 200 | Licence not verified |
| OSTI (DOE) | API 200 | API caps at 50 records per query and ignores the offset parameter; further requests return 403/429. PARTIALLY_ACCESSIBLE. |
| DTIC | search 200, documents 403 | Discovery works, retrieval does not |

## 3. Closed

| Body | Status | Evidence |
|---|---|---|
| NSA / media.defense.gov | 403 | Both hostnames refuse the request |
| ACSC (Australia) | 403 | Advisories, resources and RSS all refused |
| BSI (Germany) | 404 | Published listing route does not exist at the probed path |

No access control was circumvented. A 403 is recorded as REJECTED_INACCESSIBLE and the source stops there.

## 4. The public-domain question, answered honestly

Three claims in this area are commonly made and only one survives:

- NIST publications are US Government works and carry no copyright in the United States. This holds, and NIST states it. It is the strongest licence position in the entire corpus.
- CISA advisories are likewise US Government works. This holds for the advisory text; embedded vendor logos and quoted third-party material do not transfer.
- NCSC UK output is not public domain. It is Crown copyright under OGL v3.0, which grants broad reuse including commercial, on condition of attribution. That is an APPROVED outcome but it is a licence, not a waiver, and the attribution obligation is real.

## 5. Marginal value

23.0 M tokens from 4,962 documents. That is 6.6% of the Phase 7 code yield from 25× fewer documents. Government material is dense and clean and should be weighted accordingly in the quality model — NIST scores 95 on the Phase 7 scale, the highest of any source assessed.

The remaining government headroom is modest. The unmeasured CERT bodies (CCCS, ANSSI, NCSC-NL, CERT-EU, JPCERT, CSA) together plausibly hold 15–30 M tokens, but each needs document-level licence review before it can enter the queue, and several are multilingual, which the frozen roster does not cover.
