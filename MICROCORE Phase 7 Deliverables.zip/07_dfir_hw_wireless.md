# Deliverable 7 — DFIR, hardware and wireless

Phase 7 targeted three areas the earlier phases under-covered. DFIR improved substantially. Hardware is now the best-covered niche in the entire corpus. Wireless remains almost empty, and that is a finding, not an omission.

## 1. Digital forensics and incident response

| Repository | Tokens | What it contributes |
|---|---:|---|
| log2timeline/plaso | 1,864,923 | Timeline reconstruction engine, parsers for hundreds of artefact formats |
| capstone-engine/capstone | 1,863,141 | Disassembly framework |
| skylot/jadx | 1,838,269 | Android decompiler |
| VirusTotal/yara | 1,297,072 | Pattern-matching engine for malware rules |
| mandiant/capa | 717,259 | Capability detection in executables |
| shellphish/how2heap | 508,915 | Heap exploitation technique corpus |
| nlpaueb/unblob | 428,981 | Firmware extraction |
| decalage2/oletools | 428,736 | Malicious Office document analysis |
| mandiant/flare-floss | 277,344 | Obfuscated string extraction |
| mandiant/capa-rules | 274,385 | Detection rule corpus |
| iBotPeaches/Apktool | 206,072 | Android package reverse engineering |
| ReFirmLabs/binwalk | 197,235 | Firmware signature scanning |
| EricZimmerman/KapeFiles | 3,422 | Forensic artefact definitions |
| angr/angr | 5,134,616 | Binary analysis and symbolic execution |
| Total | 15,036,370 | |

15.0 M tokens across 14 tools. This is the strongest DFIR block the project has assembled, and unlike SecLists it is genuinely dense: parsers, rule languages and format specifications rather than lists of words.

## 2. Hardware and firmware security

| Repository | Tokens | What it contributes |
|---|---:|---|
| lowRISC/opentitan | 11,364,633 | Open hardware root of trust, silicon-to-software |
| tianocore/edk2 | 5,902,086 | UEFI reference implementation |
| tpm2-software/tpm2-tss | 2,461,424 | TPM 2.0 software stack |
| zephyrproject-rtos/zephyr | 59,060,597 | RTOS with MPU, secure boot and TLS subsystems |
| microsoft/msr-tools adjacent (MBE) | 37,554 | Modern binary exploitation course material |
| Total | 78,826,294 | |

## 3. Wireless

This is the gap. Probing found no wireless-specific corpus that is both openly licensed and non-trivial:

| Target | Result |
|---|---|
| hostap/hostap (wpa_supplicant, hostapd) | tarball 404 on both branches — download route unavailable |
| 802.11 frame corpora / pcap collections | none found with a reuse licence |
| SDR, Bluetooth, Zigbee, LoRa tooling | no licensed repository identified in Phase 7 |
| What exists instead | network scanning tools (naabu 269,485; httpx 214,585; subfinder 132,660) and eBPF networking in cilium (15,951,985) |

Calling cilium a wireless source would be false. It is a cloud-native networking and security project. The honest statement is: wireless protocol security is represented in the corpus only through standards documents (NIST SP 800-153, SP 800-48 on legacy wireless) and through general exploitation material, not through protocol implementations.

## 4. Gap analysis

| Area | Coverage | Assessment |
|---|---|---|
| Disk and memory forensics | Good | plaso, volatility3 rejected on licence, MBE, unblob |
| Malware analysis | Good | yara, capa, capa-rules, floss, oletools, how2heap |
| Binary exploitation | Good | angr, capstone, how2heap, MBE |
| Mobile | Adequate | jadx, Apktool, one vulnerable Android app |
| Firmware and UEFI | Strong | edk2, opentitan, binwalk, unblob |
| Hardware root of trust | Strong | opentitan, tpm2-tss |
| Wireless (802.11, BT, Zigbee, SDR) | Very weak | no licensed implementation corpus |
| Automotive (CAN, UDS, AUTOSAR) | Very weak | not addressed in Phase 7 |
| ICS protocol implementations | Weak | CISA advisories cover the threat, not the protocol code |
| Telecom (5G, SS7, Diameter) | None | no licensed source identified |

Three of these — automotive, ICS protocol code, telecom — are large enough to matter and are named in Deliverable 14 as open work rather than quietly dropped.
