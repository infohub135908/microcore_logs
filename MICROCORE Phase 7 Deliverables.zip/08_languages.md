# Deliverable 8 — The eleven-language roster

## 1. Recommendation: freeze the roster as-is

The Phase 7 working roster is C, C++, C#, Go, Rust, Python, Java, JavaScript, TypeScript, PowerShell, Shell/Bash. Phase 7 measured 182,648,610 tokens of language-attributed code and the evidence supports freezing this list without amendment.

Reasons:

1. It maps to real labour-market and threat-surface demand: memory-unsafe systems languages, the two dominant scripting families, the two dominant web languages, and the enterprise pair.
2. It excludes languages that enter the corpus only as side effects of tooling — Ruby (Metasploit), Perl, Assembly — which together are 13.6% of measured code and would otherwise dominate the C-family share.
3. It is small enough to enforce. A roster of 25 languages is a preference; a roster of 11 is a filter.

## 2. Measured distribution

Of 182,648,610 attributed tokens, 157,851,482 (86.4%) fall inside the roster.

| Language | Tokens | Share of roster |
|---|---:|---:|
| C | 81,179,928 | 51.4% |
| Python | 17,666,397 | 11.2% |
| PowerShell | 14,270,093 | 9.0% |
| Go | 10,763,633 | 6.8% |
| C++ | 10,442,370 | 6.6% |
| TypeScript | 9,350,476 | 5.9% |
| Java | 5,200,617 | 3.3% |
| C# | 2,593,585 | 1.6% |
| JavaScript | 2,290,035 | 1.5% |
| Shell | 2,102,950 | 1.3% |
| Rust | 1,991,398 | 1.3% |

Outside the roster: Ruby 13,487,593, Assembly 6,621,718, Perl 4,622,904, plus negligible Lua, PHP, Objective-C and Kotlin (64,913 combined).

## 3. Where the distribution is distorted

The C share is not evidence of C expertise. It is evidence of five large repositories.

| Driver | Tokens | Effect |
|---|---:|---|
| zephyr | 59,060,597 | Alone is 73% of all measured C |
| openssl + boringssl | 43,234,674 | Crypto-specific C, genuinely relevant |
| opentitan + edk2 | 17,266,719 | Firmware C |
| SecLists | 64,285,860 | Mostly not code at all — wordlists in plain text |

Remove Zephyr and the C share drops from 51.4% to roughly 27%. Remove SecLists and the Python share collapses, because a large part of SecLists' payload sits in Python and text files.

The same distortion appears in PowerShell: 14.3 M of which Empire contributes 13.7 M and PowerSploit 1.26 M. Two offensive frameworks constitute the entire PowerShell representation. There is no defensive PowerShell corpus, no DSC configuration corpus, no enterprise administration corpus.

## 4. Per-language adequacy

| Language | Verdict | Evidence |
|---|---|---|
| C | Oversupplied but concentrated | 81.2 M, of which 73% is one RTOS |
| C++ | Adequate | 10.4 M across cilium, z3, tink, capstone, mitmproxy |
| Python | Adequate | 17.7 M across metasploit, angr, plaso, impacket, capa |
| Go | Good | 10.8 M across cilium, naabu, httpx, subfinder, gitleaks, falco |
| TypeScript | Good | 9.4 M, mostly opencti and juice-shop |
| Java | Thin | 5.2 M, dominated by tink and jadx |
| PowerShell | Biased | 14.3 M, 96% offensive tooling |
| JavaScript | Thin | 2.3 M |
| Shell | Thin | 2.1 M despite being the glue language of every tool here |
| Rust | Thin | 2.0 M for a language that is now the default for new security tooling |
| C# | Thin | 2.6 M, mostly SharpDPAPI, Rubeus, Seatbelt, Certify, SharpUp |

## 5. What would fix it

Rust and C# are the two clearest deficits, and both are fixable with licensed sources: Rust has an unusually permissive ecosystem (most crates are MIT or Apache-2.0 dual) and modern security tooling in Rust is abundant. C# has a large .NET security surface. Shell is thin because tooling repositories keep their install scripts short; that is structural and not worth chasing.

The roster should be frozen, and the language balance should be corrected by adding sources, not by reweighting.
