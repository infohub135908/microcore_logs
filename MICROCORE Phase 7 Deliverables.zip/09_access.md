# Deliverable 9 — Accessibility register

Every candidate in Phase 7 was probed directly. No candidate carries an accessibility status inferred from a search result, a citation, or a directory listing. All probes are dated 2026-11-27.

## 1. Status distribution

| Status | Count | Definition applied |
|---|---:|---|
| VERIFIED_ACCESSIBLE | 99 | A direct request returned document content that was parsed and, where in the acquisition queue, measured |
| PARTIALLY_ACCESSIBLE | 6 | Reachable, but only under restrictive conditions: bulk enumeration blocked, authentication required, or per-record access only |
| REJECTED_INACCESSIBLE | 11 | 403, or a route that does not exist. Not attempted further. |
| UNVERIFIED | 0 | Every candidate was probed |

The absence of UNVERIFIED entries is deliberate. A register full of UNVERIFIED rows is not a register; it is a to-do list. Anything that could not be established was closed rather than left open.

## 2. Rejected as inaccessible

| ID | Target | Status | Route tried |
|---|---|---|---|
| P7-001 | DTIC technical reports | 403 | public search and document routes |
| P7-003 | media.defense.gov | 403 | direct |
| P7-004 | NSA cybersecurity guidance | 403 | index and document routes |
| P7-005 | ACSC advisories | 403 | listing, document, RSS |
| P7-006 | ACSC resources | 403 | listing |
| P7-010 | BSI publications | 404 | published path does not exist |
| P7-040 | ACM Digital Library | 403 | direct |
| P7-041 | Springer LNCS | 404 | direct |
| P7-043 | MicrosoftDocs security docs | 404 | repository retired |
| P7-044 | AWS docs licence | 404 | direct |
| P7-046 | HackTricks | 404 | probe path; site reachable elsewhere but licence blocks use |

HackTricks is listed here for completeness of the probe record. Its real status is REJECTED on licence (CC BY-NC-SA 4.0), which is the binding reason.

## 3. Partially accessible

| ID | Target | Status | Restriction |
|---|---|---|---|
| P7-017 | OSTI API | 200 | Caps at 50 records per query and ignores the offset parameter; subsequent paging returns 403/429 |
| P7-019 | OpenAlex | 429 | Polite-pool rate limit; metadata only in any case |
| P7-021 | CORE | 200 | API key required for bulk |
| P7-023 | OpenReview | 403 | Blocked despite public-facing content |
| P7-032 | Semantic Scholar | 429 | Rate-limited; terms restrict bulk text use |
| P7-039 | IEEE Xplore | 202 | Challenge response; paywall behind it |

## 4. Enumeration methods that actually worked

Where a listing existed, it was walked exhaustively rather than sampled.

| Source | Method | Yield |
|---|---|---|
| NIST | Pattern construction with HTTP Range probes: 1,910 candidate URLs across four series and revision suffixes | 242 hits, all misses clean 404 |
| CISA ICS | Listing pagination `?page=N` | 3,203 of 3,203 |
| NCSC UK | `sitemap.xml` | 1,281 pages |
| ENISA | `sitemap.xml` | 599 pages, 238 with extractable text |
| arXiv | API with `max_results=2000`, no date sort | 10 categories, 550-paper census, 89 PDFs |
| Europe PMC | REST search then NCBI efetch per PMCID | 32,518 hits, 299 of 300 sampled retrieved |
| PLOS | Search API | 5,647 DOIs, 350 sampled |
| GitHub | `codeload.github.com` tarball per repository and branch | 59 repositories, 130,688 files |

## 5. Routes that failed and were replaced

| Failure | Symptom | Replacement |
|---|---|---|
| arXiv API with `sortBy=submittedDate` | Hangs and returns truncated result sets | Removed the sort; `max_results=2000` |
| EBI fullTextXML | Throttled to ~33 s per document | NCBI efetch `db=pmc&retmode=xml` |
| hostap tarball | 404 on `main` and `master` | None. Source abandoned. |
| OSTI paging | Offset ignored, then 403 | Sample only, marked PARTIALLY_ACCESSIBLE |
| OpenAlex without mailto | 429 | Not pursued; metadata has no token value |

## 6. What "verified" means here, precisely

VERIFIED_ACCESSIBLE means: a request was made on 2026-11-27, it returned 200, the payload was retrieved in full, and it was parsed. For the 59 repositories that also means every file was extracted, licence-classified, tokenized and hashed.

It does not mean the source will be accessible tomorrow. Accessibility is a dated observation, not a property. Every row carries `checked_at = 2026-11-27` for that reason, and the register should be re-probed before any large acquisition run.
