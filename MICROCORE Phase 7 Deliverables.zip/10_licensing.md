# Deliverable 10 — Legal and licensing

## 1. Outcomes

| Outcome | Count | Share |
|---|---:|---:|
| APPROVED | 70 | 60.3% |
| CONDITIONAL | 23 | 19.8% |
| REJECTED | 23 | 19.8% |

APPROVED means a licence that permits commercial and non-commercial reuse with at most an attribution obligation, verified by reading the licence text rather than trusting a badge. CONDITIONAL means the licence varies per document or per record and has not been resolved at that granularity. REJECTED means the licence forbids the use.

## 2. Licence distribution across the 59 measured repositories

| Licence | Repositories |
|---|---:|
| Apache-2.0 | 22 |
| MIT | 18 |
| BSD-2-Clause | 9 |
| BSD-3-Clause | 5 |
| ISC | 1 |
| No licence file | 2 |
| Unclassified licence text | 2 |

## 3. Six licence facts that were established by reading the file

These matter because the popular assumption was wrong in each case.

| Repository | Assumed | Actual | Evidence |
|---|---|---|---|
| fortra/impacket | BSD-3-Clause | Apache-2.0 | GitHub licence API plus file read |
| GhostPack/SharpDPAPI, Rubeus, Seatbelt | GPL or unlicensed | BSD-2-Clause | licence file read |
| rapid7/metasploit-framework | BSD-3-Clause | Apache-2.0 | 67,914-byte licence file, classified |
| openssh/openssh-portable | Public domain | MIT-style | 21,137-byte LICENCE file |
| capstone-engine/capstone | BSD-3-Clause | No licence file at repository root | API returns null |
| krb5/krb5 | MIT | No licence file at repository root | API returns null |

Capstone and krb5 are flagged in the CSV. Absence of a licence file is not permission; both are retained only with a low confidence flag and a recommendation to re-verify against their source distributions, which do carry notices.

Two repositories returned licence text that could not be classified automatically: SigmaHQ/sigma-specification and mitre/attack-stix-data. ATT&CK's terms are MITRE's own, which permit use with attribution but are not an OSI licence. Both are marked CONDITIONAL in effect.

## 4. Rejected licences, by clause

| Clause | Sources | Consequence |
|---|---|---|
| Non-commercial | HackTricks (CC BY-NC-SA 4.0), CTF Wiki (CC BY-NC-SA 4.0) | Excluded outright |
| Share-alike | OWASP WSTG (CC BY-SA 4.0), AWS docs (CC BY-SA 4.0) | Excluded; SA would propagate to derived corpora |
| Publisher copyright | USENIX, NDSS, ACM, IEEE, Springer, SANS, Exploit-DB, Packet Storm | Excluded; open PDFs are not open licences |
| Bespoke restrictive | volatility3 (Volatility Software License) | Excluded; redistribution terms incompatible |
| No licence | PayloadsAllTheThings | Excluded; default copyright |

The share-alike decision is a judgement call and should be stated as one. CC BY-SA material could legally be included, but the resulting corpus would inherit the SA obligation, which conflicts with the project's intent to distribute a model. That is a policy choice, not a legal impossibility, and it is recorded as such rather than as "not permitted".

## 5. Third-party content inside approved sources

An approved repository licence does not cover every file inside it. Three cases were handled:

- Vendored dependencies: boringssl contains an OpenSSL fork; the pipeline's path filter excludes vendored trees, and boringssl's own licence is a mix of ISC and OpenSSL terms. Both are permissive, so the file is safe, but the accounting must not claim the OpenSSL content twice — which is exactly what the cross-repository duplicate measurement checks.
- Rule and data files: capa-rules and sigma-specification carry their own notices separate from the code licence.
- Government documents: NIST and CISA text is a US Government work, but embedded vendor diagrams and quoted third-party tables are not. This is recorded as a residual risk rather than resolved, because it cannot be resolved at corpus scale without per-figure review.

## 6. The obligation ledger

Attribution is the dominant obligation and it is manageable: every approved source can be attributed by publisher, title and URL. A `NOTICE` file generated from the CSV's `publisher`, `source_name` and `official_url` fields satisfies the requirement for the entire approved set.

The obligations that cannot be discharged by a NOTICE file are the share-alike ones, which is why those sources are excluded rather than tracked.

## 7. Legal position summary

The corpus can be built lawfully from the 70 approved sources. It cannot reach 5 B tokens from them. The gap is not a licensing failure on the project's part; it is that the highest-density security material in the world sits behind publisher copyright and the openly licensed material is thinner. Deliverable 13 prices that gap.
