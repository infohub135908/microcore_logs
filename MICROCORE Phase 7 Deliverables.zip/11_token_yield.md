# Deliverable 11 — Token yield and measurement classes

## 1. The four classes, with no mixing between them

| Class | Tokens | What it covers |
|---|---:|---|
| VERIFIED_MEASURED (acquired in full) | 349,287,979 net | 59 repositories plus NIST, CISA, NCSC and ENISA |
| SAMPLE_MEASURED (acquired as a sample) | 8,057,435 | Europe PMC 299 documents, PLOS 350 documents, arXiv 89 PDFs |
| PROJECTED | 861,085,194 | arXiv population 413.2 M, Europe PMC population 447.9 M |
| VERIFIED_ACCESSIBLE_UNMEASURED | 0 tokens | 14 sources await per-document licence review |

The 349,287,979 figure is the only number in this deliverable that should be added to the corpus baseline. It is gross 365,660,745 minus 8,315,331 duplicate tokens in code, minus the two sampled corpora which are not counted as acquired.

## 2. Measurement arithmetic

| Block | Gross tokens | Deduplication | Net |
|---|---:|---:|---:|
| Code, 59 repositories | 334,587,258 | −8,315,331 | 326,271,927 |
| NIST | 13,464,872 | — | 13,464,872 |
| CISA ICS | 7,658,591 | — | 7,658,591 |
| NCSC UK | 1,760,927 | — | 1,760,927 |
| ENISA | 131,662 | — | 131,662 |
| Subtotal, counted | 357,603,310 | −8,315,331 | 349,287,979 |
| Europe PMC sample | 4,118,269 | not acquired | excluded |
| PLOS sample | 3,939,166 | 100% in PMC | excluded |
| arXiv sample | 1,668,305 | not acquired | excluded |

## 3. Yield per unit

| Source type | Tokens per document or file | Tokens per kB | Notes |
|---|---:|---:|---|
| Code and data repositories | 2,560 per file | 318.7 | 130,688 files, 1.05 GB |
| NIST standards | 56,104 per document | 12.2 | 240 documents, 1.10 GB, 28,573 pages |
| CISA advisories | 2,391 per advisory | 37.0 | 3,203 advisories, 207 MB |
| NCSC guidance | 1,374 per page | — | 1,281 pages |
| ENISA landing pages | 553 per page | — | 238 pages with extractable text |
| arXiv papers | 18,745 per paper | 10.4 | 89 PDFs, 1.8 MB average, 19.5 pages |
| Europe PMC articles | 13,773 per article | 13.8 | 299 XML documents |

The pattern is consistent across every document corpus: roughly 10–14 tokens per kilobyte for PDF and XML. That is a property of natural-language prose with markup. Code sits at 319 tokens per kilobyte because it is dense in short tokens — punctuation, identifiers, and repeated keywords tokenize efficiently under `cl100k_base` but each token carries little semantic content.

This is why token count and knowledge value diverge, and why the quality dimension exists at all.

## 4. The density problem, quantified

| Source | Tokens | Tokens per file | Verdict |
|---|---:|---:|---|
| SecLists | 64,285,860 | 10,576 | 6,079 wordlist files. High token count, minimal knowledge. |
| zephyr | 59,060,597 | 1,292 | 45,725 files, mostly drivers and board definitions. |
| NIST | 13,464,872 | 56,104 | Every document is a substantive standard. |
| CISA ICS | 7,658,591 | 2,391 | Every advisory is a dated, structured vulnerability record. |

A corpus built to hit a token target will over-collect the first two and under-collect the last two. Phase 7 deliberately did the opposite: 240 NIST documents were worth enumerating across 1,910 probes because each is dense, while DTIC was abandoned after two 403s because a source that will not serve one document will not serve twenty thousand.

## 5. Projection method for the two populations

Both projections multiply a measured population count by a measured per-document mean. Neither uses bytes-per-token conversion, file counts, or an assumed compression ratio.

arXiv: 73,973 unique papers after cross-listing removal × 0.298 CC BY rate (measured on 550 papers) = 22,044 licensed papers × 18,745 tokens (measured on 89 PDFs) = 413,214,780.

Europe PMC: 32,518 records × 13,773 tokens (measured on 299) = 447,870,414.

Confidence intervals are carried in Deliverable 13, not asserted here. The point estimate is a mechanical product of two measured inputs and nothing else.

## 6. What is explicitly not counted

- File counts as a proxy for tokens.
- Compressed archive sizes.
- Metadata records from OpenAlex, DOAJ or CORE as document text.
- PLOS as an independent source.
- The 14 unmeasured CERT and government bodies at any assumed yield.
- Anything requiring authentication to reach.
