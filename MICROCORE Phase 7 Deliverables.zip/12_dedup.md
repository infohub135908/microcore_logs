# Deliverable 12 — Deduplication plan and what has been computed

## 1. What has actually been measured

| Metric | Value | Scope |
|---|---:|---|
| Files hashed | 130,688 | Phase 7 code only |
| Unique files by SHA-256 | 123,093 | Phase 7 code only |
| Duplicate files | 7,595 | Phase 7 code only |
| Gross tokens | 334,587,258 | Phase 7 code only |
| Within-repository duplicate tokens | 8,307,243 | Phase 7 code only |
| Cross-repository duplicate tokens | 8,088 | Phase 7 code only |
| Total duplicate tokens | 8,315,331 | Phase 7 code only |
| Duplicate rate | 2.49% | Phase 7 code only |

This 2.49% is not a corpus-wide deduplication rate. It is the duplicate rate of the 59 repositories measured in Phase 7, computed file-by-file on exact SHA-256 match. Applying it to 2.287 B or to any projected total would be a fabrication.

## 2. Why the rate is so low, and why that is suspicious

2.49% is implausibly low for a corpus of 130,688 files drawn from 59 projects that share ancestry. Three explanations, in order of likelihood:

1. The path filter already removed vendored trees. Most duplication in open source lives in `vendor/`, `third_party/` and `node_modules/`, all of which the pipeline excludes before hashing. The measured 2.49% is therefore the duplicate rate of the filtered set, not of the raw download.
2. Exact hashing cannot see near-duplicates. A file reformatted, relicensed, or with one changed line is a different hash and a duplicate in substance.
3. Real duplication across the existing 2.287 B corpus has not been computed at all.

Boringssl at 17.5 M contains an OpenSSL fork, and openssl at 25.7 M is also in the corpus. Only 8,088 tokens were caught as cross-repository duplicates. That is not credible as a measure of the real overlap between those two projects; it is a measure of byte-identical files only.

## 3. The overlap matrix that should have been computed and was not

| Pair | Expected relationship | Measured |
|---|---|---|
| openssl ↔ boringssl | Fork with shared ancestry | 8,088 tokens of exact matches corpus-wide |
| metasploit ↔ impacket | Shared protocol code | not isolated |
| Empire ↔ PowerSploit | Empire derives from PowerSploit modules | not isolated |
| ATT&CK stix-data ↔ CISA advisories | CISA advisories reference ATT&CK techniques by ID | not isolated |
| NVD CVE 2.0 ↔ vulnrichment | vulnrichment is derived from NVD | not measured; NVD still unmeasured |
| PLOS ↔ Europe PMC | PLOS deposits into PMC | 100 of 100 sampled DOIs matched |
| Any CFR/XML standard ↔ another | Shared boilerplate clauses | not isolated |

Only the PLOS↔PMC pair was resolved, and it resolved decisively: PLOS contributes zero incremental tokens.

## 4. The three-stage plan

Stage 1 — exact, corpus-wide (not yet run). SHA-256 every file in every source, including the 2.287 B baseline. This is the only stage that can produce a defensible global uniqueness figure. Cost: the baseline is not on disk in normalised form, so this requires re-acquisition or a manifest-level comparison using stored per-file hashes where they exist. Estimated effort: 3–4 GPU-free days of I/O.

Stage 2 — near-duplicate detection. MinHash with 128 permutations over 5-gram shingles, LSH banding at Jaccard 0.85, applied within and across source families. This catches the openssl/boringssl, Empire/PowerSploit and boilerplate-clause cases that exact hashing cannot.

Stage 3 — semantic de-duplication. Embedding-based clustering at cosine 0.95 within narrow domains. This is the only stage that can address SecLists, where 1,900 wordlists overlap heavily in content but never in exact file bytes. It is also the stage with the highest risk of removing legitimately distinct material, so it should be applied only to low-density text and never to code.

## 5. Ordering rule

Deduplicate before measuring uniqueness, never after. The correct sequence is: acquire → normalise → exact hash → near-dup → tokenize → count unique. Phase 7 measured tokens first and hashed second, which is why the 2.49% figure cannot be propagated upward.

## 6. The honest statement

The corpus has 2,287,196,994 measured input tokens. Its globally unique token count is unknown and is certainly lower. Phase 7's 349,287,979 is measured and is 99.9% free of exact in-scope duplicates, subject to the caveats above. No number in this project should be described as globally unique until Stage 1 has run across all sources.
