# Deliverable 14 — Roadmap

Sequenced by yield per unit of effort, with an explicit gate before each stage. Nothing in stage 2 starts until stage 1's deduplication is complete, because acquiring before deduplicating is how a corpus reaches a number that is not real.

## Stage 0 — Close the accounting (1 day, no GPU)

| Task | Output |
|---|---|
| Run exact SHA-256 deduplication across all 2.287 B baseline sources | First defensible global uniqueness figure |
| Re-probe the 14 CONDITIONAL access rows | Refreshed accessibility status with new dates |
| Resolve capstone and krb5 licence position from upstream distributions | Two rows move from low confidence to verified |
| Measure NVD CVE 2.0 and compare ID-by-ID with vulnrichment | Either a real increment or a documented near-zero |

Gate: no acquisition starts until the baseline uniqueness multiplier is replaced by a measured value. The 0.90–0.98 range in Deliverable 13 is a placeholder and should not survive stage 0.

## Stage 1 — Acquire the two licensed academic populations (2–3 weeks)

| Target | Volume | Route | Risk |
|---|---:|---|---|
| arXiv CC-BY, 22,044 papers | ~40 GB, 413 M gross | arXiv API plus PDF fetch, 4 workers, resumable | Rate limits; PDFs must be re-licensed at article level |
| Europe PMC, 32,518 records | ~450 MB XML, 448 M gross | NCBI efetch, batched | Relevance haircut of 20–35% must be applied at retrieval, not later |

Expected net after deduplication against the existing 3.2 B: 600–720 M.

Gate: sample 500 acquired documents, re-run the relevance filter, and confirm the haircut assumptions in Deliverable 13. If precision falls below 0.70, stop and re-scope.

## Stage 2 — Expand code coverage to ~250 repositories (4–6 weeks)

Priority order, chosen to fix the language deficits named in Deliverable 8 rather than to maximise tokens:

| Batch | Target | Rationale | Est. yield |
|---|---|---|---:|
| Rust security tooling | 40 repositories | Rust is the clearest deficit at 1.99 M | 60–100 M |
| C# / .NET security | 30 repositories | 2.59 M is thin and offensive-biased | 40–80 M |
| Defensive PowerShell and DSC | 15 repositories | Current PowerShell is 96% offensive | 30–60 M |
| Java enterprise security | 25 repositories | 5.2 M, dominated by two projects | 40–70 M |
| ICS and automotive protocol implementations | 20 repositories | Named gap in Deliverable 7 | 30–60 M |
| Wireless implementations | 15 repositories | Named gap; hostap route failed and must be replaced | 20–50 M |

Expected net: 220–420 M, falling per repository as coverage widens.

Gate: measure marginal duplicate rate after each batch. If it exceeds 8%, stop the batch — the remaining repositories are restatements of what is already held.

## Stage 3 — Licensed document expansion (2 weeks)

| Target | Est. yield | Condition |
|---|---:|---|
| IETF RFC and draft corpus | 80–120 M | IETF Trust licence permits reproduction with conditions; confirm before use |
| Remaining CERT bodies | 15–30 M | Per-document licence review; multilingual content needs a policy decision |
| DOAJ CC-BY security journals | 50–150 M | Must be checked against PMC to avoid double counting |

Gate: any source that cannot be licence-verified at document level does not enter.

## Stage 4 — Final measurement and delivery (1 week)

Run the three-stage deduplication of Deliverable 12 across the whole corpus, produce the unique token count, and publish the number with its confidence interval and its method.

## What this roadmap does not do

It does not reach 5 B. Stages 0–4 total an expected 850 M–1.27 B on top of 3.24 B, landing near 4.1–4.5 B in the realistic case. Reaching 5 B requires one of: a licensed corpus nobody has found, a publisher agreement, or widening the definition of security material to include generic systems code. The first is unlikely, the second is procurement, and the third is a decision for the project owner, not for this roadmap.

## Sequencing rule

Deduplicate, then acquire, then deduplicate again. The corpus has already been measured once before being globally deduplicated, and that ordering is the root of the accounting defects in Deliverable 1. It should not be repeated.
