# Deliverable 16 — Evidence appendix

Everything below was produced on 2026-11-27. Hashes are SHA-256 truncated to 16 characters for readability; full digests are in the archive.

## 1. Measurement artefacts

| File | SHA-256 (first 16) | Contents |
|---|---|---|
| `data/summary_p7.json` | 06debf4228ad2e0c | Aggregate of all measured blocks |
| `data/exact_dedup_p7.json` | be1bb633071e8765 | Per-file hash results, 130,688 files |
| `data/sweep2.json` | eda9ffec508074f2 | 50 candidate probes with HTTP status, bytes, content type |
| `data/arxiv7_census.json` | e1db4cc0133e0952 | 550-paper stratified licence census |
| `data/lang_mix_p7.json` | 3fa38d5ae28947f4 | Language attribution over 182,648,610 tokens |
| `out/P7_source_inventory.csv` | 49ebf92a240fc1e7 | 116 sources, 34 fields |

## 2. Per-repository measurement records

59 files `data/a_MC-*.json`, each recording repository, branch, download URL, files seen, files selected, files excluded by path, files excluded by extension, binary files, oversized files, eligible bytes, eligible tokens, restricted tokens, per-class and per-category breakdowns, SPDX licences observed, manifest row count and elapsed seconds.

Manifests: 59 files `data/man_MC-*.jsonl`, one row per admitted file with path, byte count, token count and SHA-256.

## 3. Enumeration provenance

| Corpus | Enumeration artefact | Method |
|---|---|---|
| NIST | `data/nist_enum.json` | 1,910 Range probes over four series with revision suffixes |
| CISA | `data/cisa_urls.json` | Listing pagination, 3,203 URLs |
| NCSC UK | `data/ncsc_urls.json` | Sitemap, 1,281 URLs |
| ENISA | `data/enisa_urls.json` | Sitemap, 599 URLs |
| PLOS | `data/plos_ids.json` | Search API, 5,647 DOIs |
| Europe PMC | `data/epmc_list.tsv` | REST search, 300-record sample of 32,518 |
| arXiv | `data/arxiv7_census.json`, `data/arxiv7_pdf.json` | API census plus 89 PDF measurements |
| GitHub | `data/github_licences.json`, `data/licence_files.json` | Licence API plus raw file reads |

## 4. Scripts

| Script | Purpose |
|---|---|
| `q7.sh` | Single-repository acquisition and measurement wrapper |
| `docs.py` | Document measurement: PDF via PyMuPDF, HTML via bs4, XML with back-matter stripping, text passthrough |
| `nist_enum.py` | NIST URL pattern enumeration with Range requests |
| `osti_harvest.py` | OSTI API probe |
| `arxiv7.py`, `arxiv7_pdf7.py` | arXiv census and PDF yield |
| `epmc.py`, `plos.py` | Europe PMC and PLOS harvest |
| `overlap.py` | Cross-source overlap checks |
| `sweep2.py` | 50-candidate access and licence probe |
| `build_csv.py` | Inventory assembly |

## 5. Primary sources for licence determinations

| Determination | Source read |
|---|---|
| HackTricks is CC BY-NC-SA 4.0 | `raw.githubusercontent.com/trickest/...` licence file, read 2026-11-27 |
| CTF Wiki is CC BY-NC-SA 4.0 | `raw.githubusercontent.com/ctf-wiki/ctf-wiki/master/LICENSE` |
| OWASP WSTG is CC BY-SA 4.0 | `raw.githubusercontent.com/OWASP/wstg/master/LICENSE` |
| PayloadsAllTheThings has no licence | Repository root listing and README inspection |
| azure-docs is CC BY 4.0 | `raw.githubusercontent.com/MicrosoftDocs/azure-docs/main/LICENSE` |
| impacket is Apache-2.0 | GitHub licence API plus licence file |
| openssh is MIT-style | 21,137-byte LICENCE file |
| metasploit is Apache-2.0 | 67,914-byte licence file |
| volatility3 is not OSI-licensed | Volatility Software License text |

## 6. Failed retrievals, retained as evidence

| Target | Symptom | Date |
|---|---|---|
| hostap tarball on `main` and `master` | 404 | 2026-11-27 |
| DTIC document routes | 403 | 2026-11-27 |
| NSA and media.defense.gov | 403 | 2026-11-27 |
| ACSC advisories, resources, RSS | 403 | 2026-11-27 |
| BSI publication listing | 404 | 2026-11-27 |
| OSTI paging beyond 50 records | 403 / 429 | 2026-11-27 |
| OpenAlex without polite pool | 429 | 2026-11-27 |
| Semantic Scholar | 429 | 2026-11-27 |
| OpenReview | 403 | 2026-11-27 |
| ACM DL | 403 | 2026-11-27 |
| EBI fullTextXML | ~33 s per document throttle | 2026-11-27 |
| arXiv API with `sortBy=submittedDate` | Hangs and truncates | 2026-11-27 |

## 7. Reproduction

The 59 repositories reproduce from `q7.sh` given the queues in `queue7.txt` through `queue10.txt`. The document corpora reproduce from the stored URL lists and `docs.py --job`. The measurement environment is a Kaggle notebook with two NVIDIA T4 GPUs; no GPU was used for tokenization, which is CPU-bound.

## 8. What this appendix cannot show

No audited third party has verified these measurements. They are self-reported by the pipeline that produced them. The hashes allow a reviewer to confirm the artefacts have not changed since delivery, but they do not confirm the artefacts are correct. That gap is closed only by an independent re-measurement of a random sample, which has not been performed.
